#include <stdio.h>
#include <stdlib.h>

int main()
{
    int size = 10;
    int arr[10];
    printf("Enter array elements\n");
    for (int i = 0; i < size; i++)
    {
        scanf("%d", &arr[i]);
    }

    int magical;
    printf("Enter magical number :\n");
    scanf("%d", &magical);

    int left[10] = {};
    int leftindex = 0;

    int index = -1;
    for (int i = 0; i < 10; i++)
    {
        if (arr[i] < magical)
        {
            left[leftindex] = arr[i];
            leftindex += 1;
        }
    }

    for (int i = 0; i < 10; i++)
    {
        if (arr[i] == magical)
        {
            left[leftindex] = arr[i];
            leftindex += 1;
        }
    }

    for (int i = 0; i < 10; i++)
    {
        if (arr[i] > magical)
        {
            left[leftindex] = arr[i];
            leftindex += 1;
        }
    }

    for (int i = 0; i < 10; i++)
    {
        printf("%d ", left[i]);
        if (left[i] == magical)
        {
            index = i;
        }
    }
    printf("\n");
    if (index >= 0)
    {
        printf("New index of %d is %d \n", magical, index);
    }
    else
    {
        printf("%d\n", -1);
    }

    return 0;
}