// Header files
#include <stdio.h>
#include <stdlib.h>
#include "header.h"

int main()
{
    int number;
    // Dynamically size allocation to structure
    struct SymbolDecoder *s1 = (struct SymbolDecoder *)malloc(10 * sizeof(struct SymbolDecoder));
    while (1)
    {

        printf("Enter the number of symbols in the magical Symbol Translater: ");
        scanf("%d", &number);

        if (number <= 10)
        {
            int res = decodeSymbol(s1, number); // calling decodeSymbol() function
            if (res == -1)
            {
                printf("%d\n", -1);
            }
            break;
        }
    }
    free(s1);//Free a block allocated by malloc

    return 0;
}