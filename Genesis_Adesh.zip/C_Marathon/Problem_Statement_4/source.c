// Header files
#include <stdio.h>
#include <stdlib.h>
#include "header.h"

// struct SymbolDecoder s1[10]; 

int check_dupicate(struct SymbolDecoder *s1, int i, char symbol)
{
    for (int index = 0; index < i; index++)
    {
        if (symbol == s1[index].symbol)
        {
            return 0;
        }
    }
    return 1;
}

int decodeSymbol(struct SymbolDecoder *s1, int number)
{
    int i = 0;
    char ch;
    printf("Enter the mystical symbols and their corresponding numeric values:\n");
    while (i < number)
    {
        getchar();

        printf("Mystical Symbol:\n");
        scanf("%c", &s1[i].symbol);
        if (check_dupicate(s1, i, s1[i].symbol))
        {

            while (1)
            {
                printf("Numeric Value:\n");
                scanf("%d", &s1[i].value);
                if (s1[i].value > 0)
                {
                    break;
                }
            }

            i++;
        }
    }

    getchar();
    printf("Enter the mystical symbol to decode: ");
    scanf("%c", &ch);

    for (int j = 0; j <= i - 1; j++)
    {
        if (s1[j].symbol == ch)
        {
            printf("The numeric value of the mystical symbol %c is %d\n", ch, s1[j].value);
            return 0;
        }
    }

    return -1;
}