#include <stdlib.h>

// creating struture SymbolDecoder 

struct SymbolDecoder
{
    char symbol;
    int value;
};

// Function Declaration
int decodeSymbol(struct SymbolDecoder *,int);