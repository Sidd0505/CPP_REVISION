#include<stdio.h>
#include"Header.h"

int main()
{
    int arr[4];
    int size=4;
    int target;
    printf("Enter 4 array elemet\n");
    scanf("%d %d %d %d\n",&arr[0],&arr[1],&arr[2],&arr[3]);
    printf("Enter Elemet you want to search\n");
    scanf("%d",&target);
    printf("Output: %d\n",fndcoin(arr,size,target));
    return 0;
}