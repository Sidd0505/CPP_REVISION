#include <stdio.h>
#include"Header.h"
int main()
{
    int size = 10, k = 0;
    int arr[10];
    printf("Enter array elements\n");
    for(int i=0;i<size;i++)
    {
        scanf("%d",&arr[i]);
    }
    int magical_number;
    printf("Enter magical number :\n");
    scanf("%d",&magical_number);
    int flag = 0;
    int index = 0;

    bubble_sort(arr,magical_number,size);

    for (k = 0; k < size; k++)
    {
        if (arr[k]==magical_number && flag==0)
        {
            flag = 1;
            index = k;
        }
        printf("%d ", arr[k]);
    }
    printf("\n");
    if(index==0 && flag==0)
    {
        printf("%d\n",-1);
    }
    else
    {
        printf("New index of magical number is %d\n",index);
    }
    

    return 0;
}