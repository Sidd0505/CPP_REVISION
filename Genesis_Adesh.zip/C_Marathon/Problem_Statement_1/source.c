#include <stdio.h>
#include "Header.h"

// function to count number of pizzas
void countPizzas(int Budget)
{
    int Non_Veg_Pizza = 0, Veg_Pizza = 0, cost, initial_budget = Budget;
    while (Budget != 0)
    {

        printf("(Note: Enter 5 for Veg_pizza or 10 for Non_veg_pizza..)\n");
        printf("Enter your pizza choice: \n");
        scanf("%d", &cost);
        printf("\n");
        if (cost == 10)
        {
            Non_Veg_Pizza += 1;
            Budget -= 10;
        }

        if (cost == 5)
        {
            Veg_Pizza += 1;
            Budget -= 5;
        }
    }

    printf("Summary\n");
    printf("Pizza Party Budget : %d Rs\nNon Veg Pizza : %d\nVeg Pizza : %d\n", initial_budget, Non_Veg_Pizza, Veg_Pizza);
}