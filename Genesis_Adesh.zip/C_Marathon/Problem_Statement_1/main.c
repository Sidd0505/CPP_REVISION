#include <stdio.h>
#include <stdlib.h>
#include "Header.h"

int main()
{
    int Budget;
    while (1)
    {
        printf("Enter your Budget:\n");
        scanf("%d", &Budget);
        if (Budget % 5 == 0)
        {
            countPizzas(Budget); // callng function countPizzas()
            exit(0);
        }
        printf("(Note: Your Budget should be multiple of 5..)\n");
    }

    return 0;
}