#include <stdio.h>
#include <stdlib.h>
#include "Header.h"

int main()
{
    int number;
    while (1)
    {
        printf("Enter positive number\n");
        scanf("%d", &number);
        if (number >= 1)
        {
            printf("output is: %d\n", crack_code_have_fun(number));//calling function
            exit(0);
        }
    }

    return 0;
}