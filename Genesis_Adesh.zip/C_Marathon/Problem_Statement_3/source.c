#include<stdio.h>
#include<stdlib.h>
#include"Header.h"

// function crack_code_have_fun() to solve the puzzle
int crack_code_have_fun(int number)
{
    int cas;
    int original=number;
    int rem=0,sum=0,rev=0;
    
    //---Deciding case value

    if(number>=1 && number<=9)
    {
        cas=1;
    }
    if(number<100 && number>9)
    {
        cas=2;
    }
    if(number>=100 && number<=999)
    {
        cas=3;
    }
    if(number>=1000)
    {
        cas=4;
    }

    //-----------------------
    
    switch(cas)
    {
        case 1:
        return number*number;
        break;

        case 2:
       
        while(number!=0)
        {
            int rem=number%10;
            sum=sum+rem;
            number=number/10;
        }
        return original-sum;
        break;

        case 3:
       
        while(number!=0)
        {
           rem=number%10;
            rev=rev*10+rem;
            number=number/10;
        }
        return rev;
        break;

        case 4:
        
        while(number!=0)
        {
            rem=number%10;
            sum=sum+rem;
            number=number/10;
        }

        return original%sum;
        break;

        default:
        break;

        

    }
}