#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>

std::mutex glock;

int Amount=1000;

void Withdraw()
{
    glock.lock();
    Amount-=10;
    glock.unlock();
}

void Deposit()
{
    glock.lock();
    Amount-=10;
    glock.lock();
}

int main()
{
    std::thread t1(Deposit);
    std::thread t2(Withdraw);
    
    t1.join();
    t2.join();

    std::cout<<Amount<<std::endl;
    return 0;
}
