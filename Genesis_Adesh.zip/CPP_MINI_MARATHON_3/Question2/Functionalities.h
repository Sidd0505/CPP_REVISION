
#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "Automobile.h"
#include "EvCar.h"
#include <vector>
#include <memory>
#include <variant>

using EvCarPointer = std::shared_ptr<EvCar>;
using AutomobilePointer = std::shared_ptr<Automobile>;
using VType = std::variant<EvCarPointer, AutomobilePointer>;
using Container = std::vector<VType>;

void CreateObjects(Container &data);

int DisplaySeatCont(Container &data, int id);

void DisplayCountOfInstances(Container &data);

void AveragePrice(Container &data);

void TotalGSTAmmont(Container &data);

#endif // FUNCTIONALITIES_H
