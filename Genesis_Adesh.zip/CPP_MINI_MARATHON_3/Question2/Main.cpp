#include <iostream>
#include "Functionalities.h"
#include <future>
#include <thread>
int main()
{
    Container data;
    CreateObjects(data);

    std::future<int> result = std::async(std::launch::async, DisplaySeatCont, std::ref(data), 101);
    std::cout << "Seat Count :" << result.get() << std::endl;

    std::thread t1(DisplayCountOfInstances, std::ref(data));

    std::thread t2(AveragePrice, std::ref(data));

    std::thread t3(TotalGSTAmmont, std::ref(data));

    t2.join();
    t1.join();
    t3.join();

    return 0;
}