#include "Automobile.h"

Automobile::Automobile(int _id, AutomobileType _type, float _price, int _seat_count, int _engine_horsepower)
:_id(_id),_type(_type),_price(_price),_seat_count(_seat_count),_engine_horsepower(_engine_horsepower)
{
}

float Automobile::CalculateGst()
{
   return price()*0.10;
}

std::ostream &operator<<(std::ostream &os, const Automobile &rhs) {
    os << "_id: " << rhs._id
       << " _type: " <<(int) rhs._type
       << " _price: " << rhs._price
       << " _seat_count: " << rhs._seat_count
       << " _engine_horsepower: " << rhs._engine_horsepower;
    return os;
}
