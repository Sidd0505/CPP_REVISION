#include "Functionalities.h"

void CreateObjects(Container &data)
{

    data.emplace_back(std::make_shared<Automobile>(101, AutomobileType::REGULAR, 80000.0f, 10, 100));
    data.emplace_back(std::make_shared<EvCar>(102, AutomobileType::TRANSPORT, 90000.0f, 10, 99, 100));
    data.emplace_back(std::make_shared<EvCar>(103, AutomobileType::REGULAR, 100000.0f, 9, 99, 80));
}

int DisplaySeatCont(Container &data, int id)
{
    if (data.empty())
    {
        throw std::runtime_error("Empty Data");
    }

    int result = -1;
    for (const VType &ptr : data)
    {

        if (std::holds_alternative<AutomobilePointer>(ptr))
        {
            std::visit([&](auto &&val)
                       { result = val->seatCount(); },
                       ptr);
        }
    }
    return result;
}

void DisplayCountOfInstances(Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("Empty Data");
    }
    int count = 0;
    for (const VType &ptr : data)
    {

        if (std::holds_alternative<AutomobilePointer>(ptr))
        {
            std::visit([&](auto &&val)
                       {if(val->engineHorsepower()<600)
            {
                count+=1;
            } },
                       ptr);
        }
    }
    std::cout << "Cont of Automobile Instances whose enginehorsepower is below 600 " << count << std::endl;
}

void AveragePrice(Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("Empty Data");
    }
    int count = 0;
    int total = 0;
    for (const VType &ptr : data)
    {

        if (std::holds_alternative<EvCarPointer>(ptr))
        {
            std::visit([&](auto &&val)
                       {

                total+=val->price();
                count+=1; },
                       ptr);
        }
    }

    std::cout << "Average price of all instances of EvCar : " << total / count << std::endl;
}

void TotalGSTAmmont(Container &data)
{

    if (data.empty())
    {
        throw std::runtime_error("Empty Data");
    }
    int total = 0;
    for (const VType &ptr : data)
    {

        std::visit([&](auto &&val)
                   { total += val->CalculateGst(); },
                   ptr);
    }

    std::cout << "Total GST Ammount : " << total << std::endl;
}
