#ifndef AUTOMOBILE_H
#define AUTOMOBILE_H

#include <iostream>
#include "AutomobileType.h"
class Automobile
{
private:
    int _id;
    AutomobileType _type;
    float _price;
    int _seat_count;
    int _engine_horsepower;

public:
    Automobile(int _id,
               AutomobileType _type,
               float _price,
               int _seat_count,
               int _engine_horsepower);
    Automobile() = default;
    Automobile(const Automobile &) = delete;
    Automobile(Automobile &&) = delete;
    Automobile &operator=(const Automobile &) = delete;
    Automobile &operator=(Automobile &&) = delete;
    ~Automobile() = default;

    float CalculateGst();

    int id() const { return _id; }

    AutomobileType type() const { return _type; }

    float price() const { return _price; }

    int seatCount() const { return _seat_count; }

    int engineHorsepower() const { return _engine_horsepower; }

    friend std::ostream &operator<<(std::ostream &os, const Automobile &rhs);
};

#endif // AUTOMOBILE_H
