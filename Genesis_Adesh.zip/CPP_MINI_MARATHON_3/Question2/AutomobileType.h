#ifndef AUTOMOBILETYPE_H
#define AUTOMOBILETYPE_H

enum class AutomobileType
{
    REGULAR,
    TRANSPORT
};

#endif // AUTOMOBILETYPE_H
