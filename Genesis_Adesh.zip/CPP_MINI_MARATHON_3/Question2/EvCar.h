#ifndef EVCAR_H
#define EVCAR_H
#include"Automobile.h"
#include <ostream>

class EvCar: public Automobile
{
private:
        float _battery_capacity;


public:

    EvCar(int _id,
               AutomobileType _type,
               float _price,
               int _seat_count,
               int _engine_horsepower,float _battery_capacity);
    EvCar() = default;
    EvCar(const EvCar &) = delete;
    EvCar(EvCar &&) = delete;
    EvCar &operator=(const EvCar &) = delete;
    EvCar &operator=(EvCar &&) = delete;
    ~EvCar() = default;

    float CalculateGst();

    float batteryCapacity() const { return _battery_capacity; }

    friend std::ostream &operator<<(std::ostream &os, const EvCar &rhs);
};

#endif // EVCAR_H
