#include "EvCar.h"

EvCar::EvCar(int _id, AutomobileType _type, float _price, int _seat_count, int _engine_horsepower, float _battery_capacity)
:Automobile(_id,_type,_price,_seat_count,_engine_horsepower),_battery_capacity(_battery_capacity)
{
}

std::ostream &operator<<(std::ostream &os, const EvCar &rhs) {
    os << static_cast<const Automobile &>(rhs)
       << " _battery_capacity: " << rhs._battery_capacity;
    return os;
}

float EvCar::CalculateGst()
{
    
    return price()*0.10;
}
