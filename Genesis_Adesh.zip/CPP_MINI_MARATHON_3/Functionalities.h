#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H



void SumOfGlobal();

#endif // FUNCTIONALITIES_H
