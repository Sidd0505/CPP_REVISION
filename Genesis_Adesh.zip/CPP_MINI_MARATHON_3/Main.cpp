#include<iostream>
#include<future>
#include<thread>
#include<vector>
int Number1=0;
int Number2=0;
std::mutex mt;
bool notify=false;
std::condition_variable condition;
int SumOfGlobel()
{
    std::unique_lock<std::mutex> lock(mt);
    if(!notify)
    {
        condition.wait(lock);
    }
    
    return Number1+Number2;
}

void SumOfNNumbers(int N)
{
    int sum=0;
    int val;

    for(int i=0;i<N;i++)
    {
        std::cout<<"Enter Number "<<std::endl;
        std::cin>>val;
        sum=sum+val;
    }
    std::cout<<"Sum is : "<<sum<<std::endl;

}

void DisplayOddNumbers(std::vector<int> data)
{
    
if(data.empty())
{
    throw std::runtime_error("Data is empty ");
}

std::cout<<"Odd number is : ";
for(int val : data)
{
    if(val%2==1)
    {
        std::cout<<val <<" ";
    }
}

}

int main()
{
    std::future <int> Result=std::async(std::launch::async,SumOfGlobel);
    
    std::cout<<"Enter Number1 : "<<std::endl;
    std::cin>>Number1;

    std::cout<<"Enter Number2 : "<<std::endl;
    std::cin>>Number2;

    std::unique_lock<std::mutex>lock(mt);
    notify=true;
    condition.notify_one();
    std::cout<<"Sum of Globel : "<<Result.get();

    std::array<std::thread,2>ThreadArray;

    ThreadArray[0]=std::thread (SumOfNNumbers,3);
    ThreadArray[0].join();

    ThreadArray[1]=std::thread(DisplayOddNumbers,std::vector<int>{10,11,23});
    ThreadArray[1].join();


    // std::thread t1(SumOfNNumbers,3);




    return 0;
}