#ifndef TICKETTYPE_H
#define TICKETTYPE_H

enum class TicketType
{
    RESERVED,
    GENERAL
};

#endif // TICKETTYPE_H
