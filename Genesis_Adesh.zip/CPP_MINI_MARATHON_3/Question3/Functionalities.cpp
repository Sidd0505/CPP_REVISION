#include "Functionalities.h"
#include <algorithm>
void CreateObjects(Container &data)
{
    data.emplace_back(std::make_shared<Passenger>(101, "Adesh", 20, std::make_shared<Ticket>(9.0f, TicketType::GENERAL), 10.0f));
    data.emplace_back(std::make_shared<Passenger>("A102", "Aniket", 21, std::make_shared<Ticket>(10.0f, TicketType::GENERAL), 20.0f));
    data.emplace_back(std::make_shared<Passenger>(103, "Ankit", 22, std::make_shared<Ticket>(11.0f, TicketType::GENERAL), 30.0f));
    data.emplace_back(std::make_shared<Passenger>("A104", "Parth", 23, std::make_shared<Ticket>(21.0f, TicketType::GENERAL), 40.0f));
}

void HighestFareName(Container &data)
{
    float highest = data[0]->fare();
    std::string name = data[0]->name();
    for (Pointer &ptr : data)
    {
        if (ptr->fare() > highest)
        {
            highest = ptr->fare();
            name = ptr->name();
        }
    }

    std::cout << "Name of highest fare is : " << name << std::endl;
}

void AverageOfAge(Container &data, const std::vector<int>& age)
{
    if (data.empty() || age.empty())
    {
        throw std::runtime_error("Empty data");
    }
    float count = 0;
    float total = 0;

        for (Pointer &dval : data)
        {
            for (int val : age)
            {
                if(dval->age()==val)
                {
                count++;
                total+=dval->age();
                }
            }
        }

    std::cout<<"Average of age is : "<<total/count<<std::endl;
}
