#include "Passenger.h"

Passenger::Passenger(const std::variant<int, std::string>& _id, std::string _name, int _age, std::shared_ptr<Ticket> _ticket, float _fare)
    : _id(_id), _name(_name), _age(_age), _ticket(_ticket), _fare(_fare)
{
}
std::ostream &operator<<(std::ostream &os, const Passenger &rhs)
{
    std::visit([&](const auto& val){os<<val;},rhs._id);
      os << " _name: " << rhs._name
       << " _age: " << rhs._age
       << " _ticket: " << *rhs._ticket
       << " _fare: " << rhs._fare;
    return os;
}
