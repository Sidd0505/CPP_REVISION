
#ifndef PASSENGER_H
#define PASSENGER_H

#include <iostream>
#include <variant>
#include "Ticket.h"
#include <memory>

class Passenger
{
private:
    std::variant<int, std::string> _id;
    // int _id;
    std::string _name;
    int _age;
    std::shared_ptr<Ticket> _ticket;
    float _fare;

public:
    Passenger(const std::variant<int, std::string>& _id,
              std::string _name,
              int _age,
              std::shared_ptr<Ticket> _ticket,
              float _fare);

    Passenger() = default;
    Passenger(const Passenger &) = delete;
    Passenger(Passenger &&) = delete;
    Passenger &operator=(const Passenger &) = delete;
    Passenger &operator=(Passenger &&) = delete;
    ~Passenger() = default;

    

    std::string name() const { return _name; }

    int age() const { return _age; }

    float fare() const { return _fare; }

    std::shared_ptr<Ticket> ticket() const { return _ticket; }

    std::variant<int, std::string> id() const { return _id; }

    friend std::ostream &operator<<(std::ostream &os, const Passenger &rhs);
};

#endif // PASSENGER_H
