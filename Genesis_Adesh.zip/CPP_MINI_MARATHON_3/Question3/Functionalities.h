#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include"Passenger.h"
#include"Ticket.h"
#include<vector>

using Pointer=std::shared_ptr<Passenger>;
using Container=std::vector<Pointer>;

void CreateObjects(Container& data);
void AverageOfAge(Container &data, const std::vector<int>& age);
void HighestFareName(Container& data);



#endif // FUNCTIONALITIES_H
