#include<iostream>
#include"Functionalities.h"


int main()
{
    Container data;
    CreateObjects(data);
    std::cout<<*data[0]<<std::endl;
    std::cout<<*data[1]<<std::endl;
    AverageOfAge(data,std::vector<int>{20,21,23});
    HighestFareName(data);
    return 0;
}