#include "Ticket.h"

Ticket::Ticket(float _tax, TicketType _type)
:_tax(_tax),_type(_type)
{

}
std::ostream &operator<<(std::ostream &os, const Ticket &rhs) {
    os << "_tax: " << rhs._tax
       << " _type: " << (int)rhs._type;
    return os;
}
