#include "header.h"

int search(Inventory *obj)
{
    int search;
    std::cout << "Enter product code" << std::endl;
    std::cin >> search;
    for (int i = 0; i < 3; i++)
    {
        if (search == obj[i].getProductcode())
        {
            return 1;
        }
    }
    return 0;
}

int main()
{
    Inventory *obj = new Inventory[3];
    int index = 0;
    int choice, n;

    while (1)
    {
        std::cout << "MENU \n1> Accept() all obj \n2> Display all obj \n3> purchase() \n4> sale() \n5> search() \n6> exit()" << std::endl;
        std::cout << "Enter your choice : " << std::endl;
        std::cin >> choice;
        switch (choice)
        {
        case 1:
            for(int i=0;i<3;i++)
            {
                 obj[i].accept();
            }
           
            break;
        case 2:
            for (int i = 0; i < 3; i++)
            {
                std::cout<<obj[i]<<std::endl;
            }

            break;
        case 3:
            try
            {
                if (index >= 3)
                {
                    throw "Index out of range";
                }
                else
                {
                    obj[index].purchase();
                    index++;
                    break;
                }
            }
            catch (const std::string msg)
            {
                std::cout << msg << std::endl;
                break;
            }
            break;
        case 4:
            obj[index].sale();
            std::cout << obj[index];
            break;
        case 5:
            n = search(obj);

            if (n == 1)
            {
                std::cout << "Product Found" << std::endl;
            }
            else
            {
                std::cout << "Produt Not found" << std::endl;
            }
            break;
        case 6:
            std::cout << "Thank you.. Exited.." << std::endl;
            exit(0);
            break;
        default:
            std::cout << "Wrong choice\n"
                      << std::endl;
            break;
        }
    }

    delete[] obj;
    return 0;
}
