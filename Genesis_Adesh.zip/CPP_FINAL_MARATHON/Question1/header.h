#ifndef HEADER_H
#define HEADER_H

#include <iostream>

class Inventory
{
    std::string description_of_profuct;
    int balancestock;
    int productcode;

public:
    Inventory()
    {
        description_of_profuct = "NA";
        balancestock = 21;
        productcode = 0001;
    }
    Inventory(std::string desc, int bstock, int pcode) : description_of_profuct(desc), balancestock(bstock),
                                                         productcode(pcode)
    {
    }

    std::string getdescriptionOfProfuct() const { return description_of_profuct; }
    void setDescriptionOfProfuct(const std::string &descriptionOfProfuct) { description_of_profuct = descriptionOfProfuct; }

    int getBalancestock() const { return balancestock; }
    void setBalancestock(int balancestock_) { balancestock = balancestock_; }

    int getProductcode() const { return productcode; }
    void setProductcode(int productcode_) { productcode = productcode_; }
    void accept();
    void purchase();
    void sale();
    friend std::ostream &operator<<(std::ostream &os, const Inventory &I);
};

#endif // HEADER_H
