#include "header.h"

void Inventory::accept()
{
    std::string d;
    int bstock;
    int pcode;
    
        std::cout << "Enter description: " << std::endl;
        std::cin >> d;
        setDescriptionOfProfuct(d);

        std::cout << "Enter balance stock: " << std::endl;
        std::cin >> bstock;
        setBalancestock(bstock);

        std::cout << "Enter Product code: " << std::endl;
        std::cin >> pcode;
        setProductcode(pcode);
        std::cout<<"---------------------------"<<std::endl;
    
}

void Inventory::purchase()
{
    std::string d;
    int bstock;
    int pcode;

    std::cout << "Enter description " << std::endl;
    std::cin >> d;
    setDescriptionOfProfuct(d);

    std::cout << "Enter stock " << std::endl;
    std::cin >> bstock;
    setBalancestock(getBalancestock() + bstock);

    std::cout << "Enter Product code " << std::endl;
    std::cin >> pcode;
    setProductcode(pcode);
}

void Inventory::sale()
{
    int pcode;
    int sale;
    std::cout << "Enter product code : " << std::endl;
    std::cin >> pcode;
    std::cout << "Enter number of stock to sale : " << std::endl;
    std::cin >> sale;

    int rem = getBalancestock() - sale;
    if (rem <= 20 && pcode!=getProductcode())
    {
        std::cout << "Cannot sale stock ";
    }
    else
    {
        setBalancestock(rem);
        std::cout << "Sucess\n";
    }
}

std::ostream &operator<<(std::ostream &os, const Inventory &I)
{
    os << I.getdescriptionOfProfuct();
    os << " ";
    os << I.getBalancestock();
    os << " ";
    os << I.getProductcode()<<std::endl;

    return os;
}