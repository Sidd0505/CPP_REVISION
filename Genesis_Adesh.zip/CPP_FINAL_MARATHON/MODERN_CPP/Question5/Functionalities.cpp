#include "Functionalities.h"

void CreateObject(container & data)
{

data.emplace_back(std::make_shared<IndividualTrip>("101CAB","RAJ",29,4,RIDE::COMFORT,58));

data.emplace_back(std::make_shared<IndividualTrip>("102CAB","JAY",29,4,RIDE::PREMIUM,50));

data.emplace_back(std::make_shared<IndividualTrip>("103CAB","RAJESH",29,4,RIDE::PREMIUM,60));
}