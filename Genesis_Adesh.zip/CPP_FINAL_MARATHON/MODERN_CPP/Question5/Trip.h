#ifndef TRIP_H
#define TRIP_H

#include<iostream>
#include"RIDE.h"

class Trip
{
    private:
    
    std::string tripId{""};
    std::string tripDriver{""};
    int tripDistance=0;
    int tripRating=0;
    RIDE tripVehicleType{RIDE::COMFORT};

    public:

    
    Trip()=default;

    Trip(Trip&)=delete;

    Trip& operator=(Trip&)=delete;

    Trip(Trip&&)=delete;

    Trip& operator=(Trip&&)=delete;

    Trip(std::string _tripId,std::string _tripDriver,int _tripDistance,int _tripRating,RIDE type);

   

    friend std::ostream &operator<<(std::ostream &os, const Trip &rhs);
    virtual float calculatefare()=0;

    std::string getTripId() const { return tripId; }
    void setTripId(const std::string &tripId_) { tripId = tripId_; }

    std::string getTripDriver() const { return tripDriver; }
    void setTripDriver(const std::string &tripDriver_) { tripDriver = tripDriver_; }

    int getTripDistance() const { return tripDistance; }
    void setTripDistance(int tripDistance_) { tripDistance = tripDistance_; }

    int getTripRating() const { return tripRating; }
    void setTripRating(int tripRating_) { tripRating = tripRating_; }

    RIDE getTripVehicleType() const { return tripVehicleType; }
    void setTripVehicleType(const RIDE &tripVehicleType_) { tripVehicleType = tripVehicleType_; }
 ~Trip()=default;
};

#endif // TRIP_H
