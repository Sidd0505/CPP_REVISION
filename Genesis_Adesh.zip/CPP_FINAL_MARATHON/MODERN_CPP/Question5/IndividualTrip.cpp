#include "IndividualTrip.h"
#include"Trip.h"
IndividualTrip::IndividualTrip(std::string _tripId, std::string _tripDriver, int _tripDistance, int _tripRating,RIDE type,int itd)
:Trip(_tripId,_tripDriver,_tripDistance,_tripRating,type),IndividualTripDuration(itd)
{
}

float IndividualTrip::calculatefare()
{
    float fare;
    float tax;
    if (getTripVehicleType() == REGULAR)
    {
        fare = getTripDistance() * 25;
        tax = fare * 0.18;
        return fare + tax;
    }
    if (getTripVehicleType() == COMFORT)
    {
        fare = getTripDistance() * 30;
        tax = fare * 0.18;
        return fare + tax;
    }
    if (getTripVehicleType() == PREMIUM)
    {
        fare = getTripDistance() * 50;
        tax = fare * 0.18;
        return fare + tax;
    }
    return 0;
}

float IndividualTrip::calculatefare(float charge)
{
    return calculatefare() + charge * IndividualTripDuration;
}

bool IndividualTrip::istripasperstandard()
{
    if (getTripVehicleType() == REGULAR)
    {
        return getTripRating() >= 3 && IndividualTripDuration <= 3 * getTripDistance();
    }
    if (getTripVehicleType() == COMFORT)
    {
        return getTripRating() >= 4 && IndividualTripDuration <= 3 * getTripDistance();
    }
    if (getTripVehicleType() == PREMIUM)
    {
        return getTripRating() >= 4 && IndividualTripDuration <= 4 * getTripDistance();
    }
    return false;
}
