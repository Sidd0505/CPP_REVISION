#ifndef INDIVIDUALTRIP_H
#define INDIVIDUALTRIP_H

#include"Trip.h"

class IndividualTrip:public Trip
{
private:
    int IndividualTripDuration{0};
public:
    IndividualTrip(std::string _tripId,std::string _tripDriver,int _tripDistance,int _tripRating,RIDE type,int itd);
    IndividualTrip()=default;
    IndividualTrip(IndividualTrip&)=delete;
    IndividualTrip& operator=(IndividualTrip&)=delete;
    IndividualTrip(IndividualTrip&&)=delete;
    IndividualTrip& operator=(IndividualTrip&&)=delete;
    ~IndividualTrip()=default;

    float calculatefare()override;
    float calculatefare(float charge);
    bool istripasperstandard();

    int individualTripDuration() const { return IndividualTripDuration; }
    void setIndividualTripDuration(int individualTripDuration) { IndividualTripDuration = individualTripDuration; }
};

#endif // INDIVIDUALTRIP_H
