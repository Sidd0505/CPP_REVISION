#ifndef SHAREDTRIP_H
#define SHAREDTRIP_H

#include<iostream>
#include"Trip.h"

class SharedTrip:public Trip
{
private:
    int Shared_Trip_Passangers{0};
public:

    SharedTrip(std::string _tripId,std::string _tripDriver,int _tripDistance,int _tripRating,RIDE type);
    SharedTrip()=default;
    SharedTrip(SharedTrip&)=delete;
    SharedTrip& operator=(SharedTrip&)=delete;
    SharedTrip(SharedTrip&&)=delete;
    SharedTrip& operator=(SharedTrip&&)=delete;
    

    int sharedTrip_Passangers() const { return Shared_Trip_Passangers; }
    void setShared_Trip_Passangers(int sharedTrip_Passangers) { Shared_Trip_Passangers = sharedTrip_Passangers; }

    float calculatefare() override;
    bool isTripasperstandard();
    ~SharedTrip()=default;
};

#endif // SHAREDTRIP_H
