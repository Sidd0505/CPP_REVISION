#include<iostream>
#include"Functionalities.h"
int main()
{
    container obj;
    // std::shared_ptr<IndividualTrip>obj1;
    CreateObject(obj);
    
    std::cout << "-------------------TEST CASE 1---------------------" << std::endl;
  
    // std::cout<<"Individual Trip Fare : "<<obj[0].calculatefare()<<std::endl;
     std::cout << "Standard Trip : " << (obj[0]->istripasperstandard() ? "YES" : "NO") << std::endl;

    std::cout << "-------------------TEST CASE 2---------------------" << std::endl;

    // std::cout<<"Individual Trip Fare : "<<obj[1].calculatefare()<<std::endl;
    std::cout << "Standard Trip : " << (obj[1]->istripasperstandard() ? "YES" : "NO") << std::endl;

    std::cout << "-------------------TEST CASE 3---------------------" << std::endl;
   
    std::cout << "Individual Trip Fare : " << obj[2]->calculatefare() << std::endl;

    std::cout << "-------------------TEST CASE 4---------------------" << std::endl;
    
    std::cout << "Individual Trip Fare : " << obj[2]->calculatefare(12.0) << std::endl;

    std::cout << "-------------------TEST CASE 5---------------------" << std::endl;
    
    std::cout << "Individual Trip Fare : " << obj[1]->calculatefare() << std::endl;
    return 0;

}