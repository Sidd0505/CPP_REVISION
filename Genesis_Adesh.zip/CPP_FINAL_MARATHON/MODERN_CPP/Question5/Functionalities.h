#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include"Trip.h"
#include"IndividualTrip.h"
#include"SharedTrip.h"

#include<memory>
#include<vector>

using pointer=std::shared_ptr<IndividualTrip>;
using container=std::vector<pointer>;
void CreateObject(container& data);

#endif // FUNCTIONALITIES_H
