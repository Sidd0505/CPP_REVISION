#ifndef RIDE_H
#define RIDE_H

#include<iostream>
enum RIDE
{
    REGULAR,
    COMFORT,
    PREMIUM
};

#endif // RIDE_H
