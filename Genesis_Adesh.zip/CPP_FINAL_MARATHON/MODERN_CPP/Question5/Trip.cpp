#include "Trip.h"

Trip::Trip(std::string _tripId, std::string _tripDriver, int _tripDistance, int _tripRating,RIDE type)
:tripId(_tripId),tripDriver(_tripDriver),tripDistance(_tripDistance),tripRating(_tripRating),tripVehicleType(type)
{
}
std::ostream &operator<<(std::ostream &os, const Trip &rhs) {
    os << "tripId: " << rhs.tripId
       << " tripDriver: " << rhs.tripDriver
       << " tripDistance: " << rhs.tripDistance
       << " tripRating: " << rhs.tripRating
       << " tripVehicleType: " << rhs.tripVehicleType;
    return os;
}
