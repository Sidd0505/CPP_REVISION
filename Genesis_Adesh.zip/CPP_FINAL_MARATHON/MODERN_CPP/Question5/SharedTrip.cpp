#include "SharedTrip.h"

SharedTrip::SharedTrip(std::string _tripId, std::string _tripDriver, int _tripDistance, int _tripRating,RIDE type)
:Trip(_tripId,_tripDriver,_tripDistance,_tripRating,type)
{
}

float SharedTrip::calculatefare()
{
     float basefare;
    float fare;
    float sharedcost;
    float tax;
    if (getTripVehicleType() == REGULAR)
    {
        basefare = getTripDistance() * 25;
        tax = 0.18 * basefare;
        sharedcost = 5 * sharedTrip_Passangers();
        fare = basefare + sharedcost + tax;

        return fare;
    }
    else if (getTripVehicleType() == COMFORT)
    {
        basefare = getTripDistance() * 30;
        tax = 0.18 * basefare;
        sharedcost = 10 * sharedTrip_Passangers();
        fare = basefare + sharedcost + tax;
        return fare;
    }
    else if (getTripVehicleType() == PREMIUM)
    {
        basefare = getTripDistance() * 50;
        tax = 0.18 * basefare;
        sharedcost = 20 * sharedTrip_Passangers();
        fare = basefare + sharedcost + tax;
        return fare;
    }
    else
    {
        return false;
    }

}

bool SharedTrip::isTripasperstandard()
{
     if (getTripVehicleType() == REGULAR)
    {
        return getTripRating() >= 3;
    }

    else if (getTripVehicleType() == COMFORT)
    {
        return getTripRating() >= 4;
    }

    else if (getTripVehicleType() == PREMIUM)
    {
        return getTripRating() >= 4;
    }
    return false;
}
