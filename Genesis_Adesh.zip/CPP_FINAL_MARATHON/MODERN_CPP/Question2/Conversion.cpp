#include"Conversion.h"

Conversion::Conversion(float _xDistance,float _yDistance,std::vector<int> arr)
:xDistance(_xDistance),yDistance(_yDistance),arr(arr)
{

}

std::ostream &operator<<(std::ostream &os, const Conversion &rhs) {
    os << "xDistance: " << rhs.xDistance
       << " yDistance: " << rhs.yDistance
       << " arr: " << rhs.arr[0]<< rhs.arr[1]<< rhs.arr[2];
    return os;
}


