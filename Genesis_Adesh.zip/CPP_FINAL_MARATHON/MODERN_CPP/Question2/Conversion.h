#ifndef CONVERSION_H
#define CONVERSION_H

#include<iostream>
#include<vector>
class Conversion
{
    private:
    
    float xDistance{0.0f};
    float yDistance{0.0f};
    std::vector<int> arr;

    public:

    Conversion(float _xDistance,float _yDistance,std::vector<int> arr);
    Conversion()=default;
    Conversion(Conversion&)=delete;
    Conversion operator=(Conversion&)=delete;
    Conversion(Conversion&&)=delete;
    Conversion operator=(Conversion&&)=delete;
    ~Conversion()=default;

    friend std::ostream &operator<<(std::ostream &os, const Conversion &rhs);


};

#endif // CONVERSION_H
