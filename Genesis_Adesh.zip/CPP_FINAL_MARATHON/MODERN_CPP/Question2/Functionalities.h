#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include"Conversion.h"
#include<vector>
#include<memory>

using pointer=std::shared_ptr<Conversion>;
using container=std::vector<pointer>;

void CreateObject(container &data);
void DisplayDetails(Conversion &data);
#endif // FUNCTIONALITIES_H
