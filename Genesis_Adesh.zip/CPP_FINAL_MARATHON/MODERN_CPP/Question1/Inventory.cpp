#include"Inventory.h"

Inventory::Inventory(std::string _description_of_product,int _balance_stock,int _product_code)
:description_of_product(_description_of_product),balance_stock(_balance_stock),product_code(_product_code)
{

}

std::ostream &operator<<(std::ostream &os, const Inventory &rhs) {
    os << "description_of_product: " << rhs.description_of_product
       << " balance_stock: " << rhs.balance_stock
       << " product_code: " << rhs.product_code;
    return os;
}
