#include <iostream>
#include "Inventory.h"
#include "Functionalities.h"

int main()
{
    container data;
    CreateObject(data);
    DisplayDetails(data);
    std::cout << "-----------PURCHASE()-------------->" << std::endl;
    try
    {
        Purchase(data, 1001, 200);
    }
    catch (std::runtime_error e)
    {
        std::cerr << e.what() << '\n';
    }
    DisplayDetails(data);
    std::cout << "------------SELL()------------->" << std::endl;
    try
    {
        Sale(data, 1002, 100);
    }
    catch (std::runtime_error e)
    {
        std::cerr << e.what() << '\n';
    }

    DisplayDetails(data);
    return 0;
}