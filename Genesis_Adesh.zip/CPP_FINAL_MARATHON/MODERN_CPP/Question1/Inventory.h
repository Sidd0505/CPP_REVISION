#ifndef INVENTORY_H
#define INVENTORY_H

#include<iostream>

class Inventory
{
    private:
    std::string description_of_product{" "};
    int balance_stock{0};
    int product_code{0};
    
    public:
    Inventory(std::string _description_of_product,int _balance_stock,int _product_code);
    Inventory()=default;
    Inventory(Inventory& )=delete;
    Inventory& operator=(Inventory&)=delete;
    Inventory(Inventory&& )=delete;
    Inventory& operator=(Inventory&&)=delete;
    ~Inventory()=default;

    std::string descriptionOfProduct() const { return description_of_product; }

    int balanceStock() const { return balance_stock; }

    int productCode() const { return product_code; }

    void setDescriptionOfProduct(const std::string &descriptionOfProduct) { description_of_product = descriptionOfProduct; }

    void setBalanceStock(int balanceStock) { balance_stock = balanceStock; }

    void setProductCode(int productCode) { product_code = productCode; }

    friend std::ostream &operator<<(std::ostream &os, const Inventory &rhs);
};

#endif // INVENTORY_H
