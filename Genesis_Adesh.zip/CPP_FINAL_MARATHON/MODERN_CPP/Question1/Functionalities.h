#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include"Inventory.h"
#include<vector>
#include<memory>

using pointer=std::shared_ptr<Inventory>;
using container=std::vector<pointer>;

void CreateObject(container& data);
void DisplayDetails(container& data);
void Purchase(container& data,int product_code,int Stock);
void Sale(container& data,int product_code,int Number_Of_Stock);

#endif // FUNCTIONALITIES_H
