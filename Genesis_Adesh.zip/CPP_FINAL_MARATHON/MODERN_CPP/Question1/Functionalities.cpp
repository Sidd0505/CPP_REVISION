#include "Functionalities.h"

void CreateObject(container &data)
{
    data.emplace_back(std::make_shared<Inventory>("ABC", 100, 1001));
    data.emplace_back(std::make_shared<Inventory>("PQR", 200, 1002));
    data.emplace_back(std::make_shared<Inventory>("XYZ", 300, 1003));
}

void DisplayDetails(container &data)
{
    for (pointer &ptr : data)
    {
        std::cout << *ptr << std::endl;
    }
}

void Purchase(container &data, int product_code,int Stocks)
{
    if(data.empty())
    {
        throw std::runtime_error("EMPTY_DATA");
    }

    for(pointer & ptr:data)
    {
        if(ptr->productCode()==product_code)
        {
            ptr->setBalanceStock(ptr->balanceStock()+Stocks);
            return;
        }
    }
    
    throw std::runtime_error("NO DATA FOUND");
}

void Sale(container &data, int product_code, int Number_Of_Stock)
{
     if(data.empty())
    {
        throw std::runtime_error("EMPTY_DATA");
    }

    for(pointer & ptr:data)
    {
        if(ptr->productCode()==product_code)
        {
            ptr->setBalanceStock(ptr->balanceStock()-Number_Of_Stock);
            return;
        }
    }
    
    throw std::runtime_error("NO DATA FOUND");
}
