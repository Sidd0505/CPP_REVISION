#include <iostream>

class base
{
    int id;

public:
    base()
    {
    }
    base(int id) : id(id)
    {
    }
    int devision(int num1, int num2);
    int getId() const { return id; }
    void setId(int id_) { id = id_; }
};
class derived : public base
{
    std::string name;

public:
    derived()
    {
    }
    derived(int id, std::string name) : base(id), name(name)
    {
    }

    std::string getName() const { return name; }
    void setName(const std::string &name_) { name = name_; }
};

int main()
{
    derived obj[3] = {{101, "Adesh"}};
    std::cout << obj[0].getId() << std::endl;
    std::cout << obj[0].getName() << std::endl;
    obj[0].devision(10,2);

    return 0;
}

int base::devision(int num1, int num2)
{
    try
    {
        if (num2 == 0)
        {
            throw "Cannot devide by zero";
        }
        std::cout<<num1/num2<<std::endl;
        return 1;
    }
    catch (const char *error)
    {
        std::cout << error;
    }
    return 0;
}
