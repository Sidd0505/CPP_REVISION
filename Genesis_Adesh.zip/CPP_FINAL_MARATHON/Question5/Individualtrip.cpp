#include<iostream>
#include"Individualtrip.h"
float Individualtrip::calculatefare()
{
    float fare;
    float tax;
    if (getTripvehicaltype() == REGULAR)
    {
        fare = getTripdistance() * 25;
        tax = fare * 0.18;
        return fare + tax;
    }
    if (getTripvehicaltype() == COMFORT)
    {
        fare = getTripdistance() * 30;
        tax = fare * 0.18;
        return fare + tax;
    }
    if (getTripvehicaltype() == PREMIUM)
    {
        fare = getTripdistance() * 50;
        tax = fare * 0.18;
        return fare + tax;
    }
    return 0;
}

float Individualtrip::calculatefare(float surcharge)
{
    return calculatefare() + surcharge * individualtripduration;
}

bool Individualtrip::istripasperstandard()
{
    if (getTripvehicaltype() == REGULAR)
    {
        return getTriprating() >= 3 && individualtripduration <= 3 * getTripdistance();
    }
    if (getTripvehicaltype() == COMFORT)
    {
        return getTriprating() >= 4 && individualtripduration <= 3 * getTripdistance();
    }
    if (getTripvehicaltype() == PREMIUM)
    {
        return getTriprating() >= 4 && individualtripduration <= 4 * getTripdistance();
    }
    return false;
}