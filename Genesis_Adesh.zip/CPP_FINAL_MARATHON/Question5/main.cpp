#include <iostream>
#include <cstring>
#include"trip.h"
#include"Individualtrip.h"
#include"sharedtrip.h"

int main()
{
    Individualtrip obj[5];
    std::cout << "-------------------TEST CASE 1---------------------" << std::endl;
    obj[0].setTripid("101CAB");
    obj[0].setTripdriver("RAM");
    obj[0].setTripdistance(20);
    obj[0].setTriprating(3);
    obj[0].setTripvehicaltype(REGULAR);
    obj[0].setIndividualtripduration(30);

    // std::cout<<"Individual Trip Fare : "<<obj[0].calculatefare()<<std::endl;
    std::cout << "Standard Trip : " << (obj[0].istripasperstandard() ? "YES" : "NO") << std::endl;

    std::cout << "-------------------TEST CASE 2---------------------" << std::endl;
    obj[1].setTripid("101CAB");
    obj[1].setTripdriver("RAJ");
    obj[1].setTripdistance(29);
    obj[1].setTriprating(3);
    obj[1].setTripvehicaltype(REGULAR);
    obj[1].setIndividualtripduration(3);

    // std::cout<<"Individual Trip Fare : "<<obj[1].calculatefare()<<std::endl;
    std::cout << "Standard Trip : " << (obj[1].istripasperstandard() ? "YES" : "NO") << std::endl;

    std::cout << "-------------------TEST CASE 3---------------------" << std::endl;
    obj[2].setTripid("101CAB");
    obj[2].setTripdriver("JAY");
    obj[2].setTripdistance(29);
    obj[2].setTriprating(3);
    obj[2].setTripvehicaltype(REGULAR);
    obj[2].setIndividualtripduration(58);
    std::cout << "Individual Trip Fare : " << obj[2].calculatefare() << std::endl;

    std::cout << "-------------------TEST CASE 4---------------------" << std::endl;
    obj[3].setTripid("101CAB");
    obj[3].setTripdriver("REJESH");
    obj[3].setTripdistance(29);
    obj[3].setTriprating(3);
    obj[3].setTripvehicaltype(REGULAR);
    obj[3].setIndividualtripduration(58);
    std::cout << "Individual Trip Fare : " << obj[3].calculatefare(12.0) << std::endl;

    std::cout << "-------------------TEST CASE 5---------------------" << std::endl;
    sharedtrip obj1;
    obj1.setTripid("101CAB");
    obj1.setTripdriver("REJESH");
    obj1.setTripdistance(29);
    obj1.setTriprating(3);
    obj1.setTripvehicaltype(REGULAR);
    obj1.setSharedtrippassangers(3);
    std::cout << "Individual Trip Fare : " << obj1.calculatefare() << std::endl;
}
