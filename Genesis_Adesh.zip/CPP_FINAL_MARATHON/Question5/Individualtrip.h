#ifndef INDIVIDUALTRIP_H
#define INDIVIDUALTRIP_H

#include<iostream>
#include"trip.h"
class Individualtrip : public trip
{
    int individualtripduration;

public:
    Individualtrip()
    {
    }
    float calculatefare();
    float calculatefare(float surcharge);
    bool istripasperstandard();
    int getIndividualtripduration() const { return individualtripduration; }
    void setIndividualtripduration(int individualtripduration_) { individualtripduration = individualtripduration_; }
};

#endif // INDIVIDUALTRIP_H
