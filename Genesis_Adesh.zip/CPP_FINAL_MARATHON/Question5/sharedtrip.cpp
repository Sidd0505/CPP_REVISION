#include<iostream>
#include"sharedtrip.h"
float sharedtrip::calculatefare()
{
    float basefare;
    float fare;
    float sharedcost;
    float tax;
    if (getTripvehicaltype() == REGULAR)
    {
        basefare = getTripdistance() * 25;
        tax = 0.18 * basefare;
        sharedcost = 5 * getSharedtrippassangers();
        fare = basefare + sharedcost + tax;

        return fare;
    }
    else if (getTripvehicaltype() == COMFORT)
    {
        basefare = getTripdistance() * 30;
        tax = 0.18 * basefare;
        sharedcost = 10 * getSharedtrippassangers();
        fare = basefare + sharedcost + tax;
        return fare;
    }
    else if (getTripvehicaltype() == PREMIUM)
    {
        basefare = getTripdistance() * 50;
        tax = 0.18 * basefare;
        sharedcost = 20 * getSharedtrippassangers();
        fare = basefare + sharedcost + tax;
        return fare;
    }
    else
    {
        return false;
    }
}

bool sharedtrip::istripasperstandard()
{
    if (getTripvehicaltype() == REGULAR)
    {
        return getTriprating() >= 3;
    }

    else if (getTripvehicaltype() == COMFORT)
    {
        return getTriprating() >= 4;
    }

    else if (getTripvehicaltype() == PREMIUM)
    {
        return getTriprating() >= 4;
    }
    return false;
}
