#ifndef TRIP_H
#define TRIP_H

#include<iostream>
enum RIDE
{
    REGULAR,
    COMFORT,
    PREMIUM
};

class trip
{
    std::string tripid;
    std::string tripdriver;
    int tripdistance;
    int triprating;
    RIDE tripvehicaltype;

public:
    trip()
    {
    }

    virtual float calculatefare() = 0;

    std::string getTripid() const { return tripid; }
    void setTripid(const std::string &tripid_) { tripid = tripid_; }

    std::string getTripdriver() const { return tripdriver; }
    void setTripdriver(const std::string &tripdriver_) { tripdriver = tripdriver_; }

    int getTripdistance() const { return tripdistance; }
    void setTripdistance(int tripdistance_) { tripdistance = tripdistance_; }

    int getTriprating() const { return triprating; }
    void setTriprating(int triprating_) { triprating = triprating_; }

    RIDE getTripvehicaltype() const { return tripvehicaltype; }
    void setTripvehicaltype(const RIDE &tripvehicaltype_) { tripvehicaltype = tripvehicaltype_; }
};

#endif // TRIP_H
