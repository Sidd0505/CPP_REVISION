#ifndef SHAREDTRIP_H
#define SHAREDTRIP_H

#include<iostream>
#include"Individualtrip.h"
class sharedtrip : public trip
{
    int sharedtrippassangers;

public:
    sharedtrip()
    {
    }

    int getSharedtrippassangers() const { return sharedtrippassangers; }
    void setSharedtrippassangers(int sharedtrippassangers_) { sharedtrippassangers = sharedtrippassangers_; }
    float calculatefare();
    bool istripasperstandard();
};

#endif // SHAREDTRIP_H
