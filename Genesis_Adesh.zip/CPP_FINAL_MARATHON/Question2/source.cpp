#include "header.h"
Conversion operator+(int x, Conversion &o)
{
    Conversion obj;
    o.xdistance = x + o.xdistance;
    return obj;
}
Conversion &Conversion::operator++()
{
    ++this->xdistance;
    ++this->ydistance;
    return *this;
}

Conversion Conversion::operator++(int)
{
    Conversion obj = *this;
    this->xdistance++;
    this->ydistance++;
    return obj;
}

int &Conversion::operator[](int index)
{
    static int i=-1;

        if (index >= 5 && index < 0)
        {
            return i;
        }
        else
        {
            return arr[index];
        }
        
    
}

bool Conversion::operator==(Conversion &c)
{
    return (this->xdistance == c.xdistance && this->ydistance == this->ydistance);
}

void Conversion::operator()()
{
    int avg = 0, sum = 0;
    for (int i = 0; i < 5; i++)
    {
        sum += arr[i];
    }
    avg = sum / 5;
    std::cout << "Average is : "<<avg<<std::endl;
}

// void Conversion::operator=(Conversion &o){
//     this->xdistance = o.xdistance;
//     this->ydistance = o.ydistance;

// }
std::ostream &operator<<(std::ostream &os, Conversion &obj)
{
    os << obj.xdistance << " " << obj.ydistance << " ";
    std::cout << "{ ";
    for (int i = 0; i < 5; i++)
    {
        os << obj.arr[i] << " ";
    }
    std::cout << " }";
    return os;
}
