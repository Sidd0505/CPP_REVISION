#ifndef HEADER_H
#define HEADER_H
#include <iostream>
class Conversion
{
    float xdistance;
    float ydistance;
    int *arr;

public:
    Conversion() // Default constructor
    {
        // std::cout<<"cons ...\n";
        xdistance = 0.0;
        ydistance = 0.0;
        arr = new int[5];
    }

    Conversion(float xd, float yd, int *ar) : xdistance(xd), ydistance(yd)
    {
       // std::cout << "para cons ...\n";

        arr = new int[5];
        for (int i = 0; i < 5; i++)
        {
            arr[i] = ar[i];
        }
    }
    Conversion(Conversion &o)
    {
        this->xdistance = o.xdistance;
        this->ydistance = o.ydistance;
        arr = new int[5];
        for (int i = 0; i < 5; i++)
        {
            this->arr[i]=o.arr[i];
        }
    }
    ~Conversion()
    {
        //std::cout << "Destructor Called..\n";
        delete[] arr;
    }

    //    void operator=(Conversion &obj);

    float getXdistance() const { return xdistance; }
    void setXdistance(float xdistance_) { xdistance = xdistance_; }

    float getYdistance() const { return ydistance; }
    void setYdistance(float ydistance_) { ydistance = ydistance_; }

    int *getArr() const { return arr; }
    void setArr(int *arr_) { arr = arr_; }

    friend Conversion operator+(int x, Conversion &obj);
    friend std::ostream &operator<<(std::ostream &os, Conversion &obj);

    Conversion &operator++();
    Conversion operator++(int);
    int &operator[](int index);
    bool operator==(Conversion &r3);
    void operator()();
};

#endif // HEADER_H
