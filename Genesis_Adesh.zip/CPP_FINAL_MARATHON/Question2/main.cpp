#include "header.h"
int main()
{
    int arr[5] = {1000, 2000, 3030, 4090, 5099};

    Conversion obj1(10.00, 20.00, arr);
    Conversion obj2(11.00, 10.00, arr);

    std::cout << "obj1 : " << obj1 << std::endl;
    std::cout << "obj2 : " << obj2 << std::endl;
    std::cout<<"----------------------------------------------------------"<<std::endl;
    Conversion obj3(obj1);

    std::cout << "copy const obj3 : " << obj3 << std::endl;
    std::cout<<"----------------------------------------------------------"<<std::endl;
    std::cout << "Before: " << std::endl;
    std::cout << "post increment x " << obj3.getXdistance() << std::endl;
    std::cout << "post increment y " << obj3.getYdistance() << std::endl;
    obj3++; // post increment
    std::cout << "After: " << std::endl;
    std::cout << "post increment x " << obj3.getXdistance() << std::endl;
    std::cout << "post increment y " << obj3.getYdistance() << std::endl;
    std::cout<<"----------------------------------------------------------"<<std::endl;
    std::cout << "Before: " << std::endl;
    std::cout << "pre increment x " << obj3.getXdistance() << std::endl;
    std::cout << "pre increment y " << obj3.getYdistance() << std::endl;
    ++obj3; // pre increment
    std::cout << "After: " << std::endl;
    std::cout << "pre increment x " << obj3.getXdistance() << std::endl;
    std::cout << "pre increment y " << obj3.getYdistance() << std::endl;
    std::cout<<"----------------------------------------------------------"<<std::endl;

    std::cout << "value of x distance before : " << obj3.getXdistance() << std::endl;
    10 + obj3;
    std::cout << "value of x distance after : " << obj3.getXdistance() << std::endl;
    std::cout<<"----------------------------------------------------------"<<std::endl;
    

    std::cout<<"Meter : "<<obj3[4]/100<<std::endl;
    std::cout<<"----------------------------------------------------------"<<std::endl;



    if(obj3==obj2)
    {
        std::cout<<"Same object"<<std::endl;
    }
    else
    {
        std::cout<<"Not same object"<<std::endl;
    }
std::cout<<"----------------------------------------------------------"<<std::endl;
    obj3();

    return 0;
}
