#include "Bill.h"
 void Bill::accept()
{
    int bn, ba;
    std::cout << "Enter bill number " << std::endl;
    std::cin >> bn;
    setBillnumber(bn);
    customerinfo.accept();
    billdate.accept();
    std::cout << "Enter bill amount " << std::endl;
    std::cin >> ba;
    setbillamount(ba);
}
std::ostream &operator<<(std::ostream &os, const Bill &d)
{
    os << "bill number " << d.getBillnumber() << std::endl;
    os << "bill amount " << d.getbillamount() << std::endl;
    return os;
}

