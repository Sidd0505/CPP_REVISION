#include "Customer.h"


void Customer::accept()
{
    char *n;
    n = new char[30];
    std::cout << "Enter custome name : " << std::endl;
    std::cin >> n;
    strcpy(customername, n);
}

std::ostream &operator<<(std::ostream &os, const Customer &I)
{
    os << I.customername;
    return os;
}