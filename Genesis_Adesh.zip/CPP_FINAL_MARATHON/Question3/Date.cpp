#include "Date.h"

void Date::accept()
{
     int d, m, y;
    std::cout << "Enter day : " << std::endl;
    std::cin >> d;
    std::cout << "Enter month : " << std::endl;
    std::cin >> m;
    std::cout << "Enter year : " << std::endl;
    std::cin>>y;

    try
    {
        if (m > 12 && m < 1)
        {
            throw "Month is out of range";
        }
        if (month == 2)
        {
            if (day > 28 && day < 1)
            {
                throw "Day is out of range";
            }
        }
        if (month == 1 || month == 3 || month == 5 || month == 8 || month == 10 || month == 12)
        {
            if (day > 31 && day < 1)
            {
                throw "Day is out of range";
            }
        }
        setYear(y);
        setDay(d);
        setMonth(m);
    }
    catch (const char *msg)
    {
        std::cout << msg;
    }
}
std::ostream &operator<<(std::ostream &os, const Date &d)
{
    os << "Day " << d.getDay();
    os << "Month " << d.getMonth();
    os << "Year " << d.getYear();
        return os;
}