#ifndef CUSTOMER_H
#define CUSTOMER_H

#include<iostream>
#include<cstring>
class Customer
{
    char *customername;

public:
    Customer()
    {
        customername = new char[30];
        strcpy(customername, "ABC");
    }
    Customer(char *name)
    {
        int length = strlen(name) + 1;
        customername = new char[length];
        strcpy(customername, name);
    }
    Customer(Customer &ob)
    {
        int length = strlen(ob.customername) + 1;
        customername = new char[length];
        strcpy(customername, ob.customername);
    }

    char *getCustomername()  { return customername; }
    void setCustomername(char *customername_) { customername = customername_; }
    void accept();
    friend std::ostream &operator<<(std::ostream &os, const Customer &I);
    ~Customer()
    {
        // delete[] customername;
    }
};

#endif // CUSTOMER_H
