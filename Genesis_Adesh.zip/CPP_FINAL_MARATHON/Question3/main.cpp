#include <iostream>
#include <cstring>
#include "Bill.h"
void search(Bill obj[])
{
    int search;
    std::cout << "Enter bill name : " << std::endl;
    char nm[20];
    std::cin >> nm;
    for (int i = 0; i < 3; i++)
    {
        if (strcmp(nm, obj[i].getCustomerinfo().getCustomername()))
        {
            std::cout << obj[i];
            break;
        }
    }
}
void calculate_total_bill(Bill obj[])
{
    int total_amount = 0;
    for (int i = 0; i < 3; i++)
    {
        if (obj[i].getbillamount() != 0)
        {
            total_amount += obj[i].getbillamount();
        }
    }
    std::cout << "Total bill Amount " << total_amount;
}
int main()
{
    Bill obj[3];

    int index = 0;
    int ch;

    while (1)
    {
        std::cout << "Menu\n1> Accept\n2> Display\n3> Calculate total bill ammount\n4> Display bill details\n5>exit\n";
        std::cout << "Enter choice : " << std::endl;
        std::cin >> ch;
        switch (ch)
        {
        case 1:
            obj[index].accept();
            index++;
            break;

        case 2:
            std::cout << "Customers Details:-- " << std::endl;
            for (int i = 0; i < index; i++)
            {
                std::cout << obj[i];
            }
            break;
        case 3:
            calculate_total_bill(obj);
            break;
        case 4:
            search(obj);
            break;
        case 5:
            exit(0);
            break;
        }
    }
    
    return 0;
}