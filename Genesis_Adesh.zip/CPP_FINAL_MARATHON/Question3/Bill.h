#ifndef BILL_H
#define BILL_H

//#include<iostream>
#include"Customer.h"
#include"Date.h"
class Bill
{
    int billnumber;
    Customer customerinfo;
    Date billdate;
    int billamount;

public:
    Bill()
    {
        billnumber = 0;
        customerinfo = Customer();
        billdate = Date();
        billamount = 0;
    }

    Bill(int number, Customer Customer, Date date, int amount)
    {

        billnumber = number;
        customerinfo = Customer;
        billdate = date;
        billamount = amount;
    }
    int getBillnumber() const { return billnumber; }
    void setBillnumber(int bn_) { billnumber = bn_; }
    int getbillamount() const { return billamount; }
    void setbillamount(int month_) { billamount = month_; }
    void accept();

    Customer getCustomerinfo()  { return customerinfo; }
    void setCustomerinfo(const Customer &customerinfo_) { customerinfo = customerinfo_; }

    friend std::ostream &operator<<(std::ostream &os, const Bill &d);
};
#endif // BILL_H
