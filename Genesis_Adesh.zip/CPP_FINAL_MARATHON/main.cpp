#include <iostream>
#include <cstring>
class Customer
{
    char *customername;

public:
    Customer()
    {
        customername = new char[30];
        strcpy(customername, "ABC");
    }
    Customer(char *name)
    {
        int length = strlen(name) + 1;
        customername = new char[length];
        strcpy(customername, name);
    }
    Customer(Customer &ob)
    {
        int length = strlen(ob.customername) + 1;
        customername = new char[length];
        strcpy(customername, ob.customername);
    }

    char *getCustomername() const { return customername; }
    void setCustomername(char *customername_) { customername = customername_; }
    void accept();
    friend std::ostream &operator<<(std::ostream &os, const Customer &I);
    ~Customer()
    {
        // delete[] customername;
    }
};

void Customer::accept()
{
    char *n;
    n = new char[30];
    std::cout << "Enter custome name : " << std::endl;
    std::cin >> n;
    strcpy(customername, n);
}

std::ostream &operator<<(std::ostream &os, const Customer &I)
{
    os << I.customername;
    return os;
}

class Date
{
    int day;
    int month;
    int year;

public:
    Date()
    {
        day = 0;
        month = 0;
        year = 0;
    }
    Date(int d, int m, int y) : day(d), month(m), year(y)
    {
    }
    void accept();
    int getDay() const { return day; }
    void setDay(int day_) { day = day_; }
    int getMonth() const { return month; }
    void setMonth(int month_) { month = month_; }
    int getYear() const { return year; }
    void setYear(int year_) { year = year_; }
    friend std::ostream &operator<<(std::ostream &os, const Date &d);
};

void Date::accept()
{
    int d, m, y;
    std::cout << "Enter day : " << std::endl;
    std::cin >> d;
    std::cout << "Enter month : " << std::endl;
    std::cin >> m;
    std::cout << "Enter year : " << std::endl;
    std::cin >> y;

    try
    {
        if (m > 12 && m < 1)
        {
            throw "Month is out of range";
        }
        if (month == 2)
        {
            if (day > 28 && day < 1)
            {
                throw "Day is out of range";
            }
        }
        if (month == 1 || month == 3 || month == 5 || month == 8 || month == 10 || month == 12)
        {
            if (day > 31 && day < 1)
            {
                throw "Day is out of range";
            }
        }

        setDay(d);
        setYear(y);
        setMonth(m);
    }
    catch (const char *msg)
    {
        std::cout << msg;
    }
}
std::ostream &operator<<(std::ostream &os, const Date &d)
{
    os << "Day " << d.getDay();
    os << "Month " << d.getMonth();
    os << "Year " << d.getYear();
    return os;
}

class Bill
{
    int billnumber;
    Customer customerinfo;
    Date billdate;
    int billamount;

public:
    Bill()
    {
        billnumber = 0;
        customerinfo = Customer();
        billdate = Date();
        billamount = 0;
    }

    Bill(int number, Customer Customer, Date date, int amount)
    {

        billnumber = number;
        customerinfo = Customer;
        billdate = date;
        billamount = amount;
    }
    int getBillnumber() const { return billnumber; }
    void setBillnumber(int bn_) { billnumber = bn_; }
    int getbillamount() const { return billamount; }
    void setbillamount(int month_) { billamount = month_; }
    void accept();

    friend std::ostream &operator<<(std::ostream &os, const Bill &d);
};

void Bill::accept()
{
    int bn, ba;
    std::cout << "Enter bill number " << std::endl;
    std::cin >> bn;
    setBillnumber(bn);
    customerinfo.accept();
    billdate.accept();
    std::cout << "Enter bill amount " << std::endl;
    std::cin >> ba;
    setbillamount(ba);
}
std::ostream &operator<<(std::ostream &os, const Bill &d)
{
    os << "bill number " << d.getBillnumber() << std::endl;
    os << "bill amount " << d.getbillamount() << std::endl;
    return os;
}

void search(Bill obj[])
{
    int search;
    std::cout << "Enter bill no : " << std::endl;
    std::cin >> search;
    for (int i = 0; i < 3; i++)
    {
        if (search == obj[i].getBillnumber())
        {
            std::cout << obj[i];
            break;
        }
    }
}
void calculate_total_bill(Bill obj[])
{
    int total_amount = 0;
    for (int i = 0; i < 3; i++)
    {
        if (obj[i].getbillamount() != 0)
        {
            total_amount += obj[i].getbillamount();
        }
    }
    std::cout << "Total bill Amount " << total_amount;
}
int main()
{
    Bill obj[3];
    // obj->accept();
    // obj->getbillamount();
    // search(obj);
    // calculate_total_bill(obj);

    int index = 0;
    int ch;
    std::cout << "Menu\n 1> Accept\n 2> Display\n 3> Calculate total bill ammount\n 4> Display bill details\n 5>exit\n";
    std::cout << "Enter choice : " << std::endl;
    std::cin >> ch;

    while (1)
    {
        switch (ch)
        {
        case 1:
            obj[index].accept();
            index++;
            break;

        case 2:
            std::cout<<"Customers Details:-- "<<std::endl;
            for(int i=0;i<index;i++)
            {
                std::cout << obj[i];
            }
            
            break;
        case 3:
            calculate_total_bill(obj);
            break;
        case 4:
            search(obj);
            break;
        case 5:
            exit(0);
            break;
        }
    }

    return 0;
}
