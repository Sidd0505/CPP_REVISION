#include <iostream>
#include "Functionalities.h"
#include <thread>
#include <future>
Container input_data;
void user_input()
{
    for(int i=0;i<5;i++)
    {
        int val;
        std::cin>>val;
        input_data.push_back(val);
    }
}

int main()
{
   
    user_input();
    /* ------------FUNCTIONALITY 1-------------- */

    try
    {
        find_non_vowels("Adesh");
    }
    catch (const std::string *msg)
    {
        std::cerr << msg << '\n';
    }

    /* ------------FUNCTIONALITY 2-------------- */
    try
    {
        if (sum_of_odd_numbers(input_data) == 0)
        {
            std::cout << "No odd number present in the list " << std::endl;
        }
        else
        {
            std::cout << "Sum of odd numbers from given list is : " << sum_of_odd_numbers(input_data) << std::endl;
        }
    }
    catch (const std::string *msg)
    {
        std::cerr << msg << '\n';
    }

    /* ------------FUNCTIONALITY 3-------------- */

    try
    {
        if (average_of_even_numbers(input_data) == 0)
        {
            std::cout << "No even number present in the list " << std::endl;
        }
        else
        {
            std::cout << "Average of even numbers from given list is : " << average_of_even_numbers(input_data) << std::endl;
        }
    }
    catch (const std::string *msg)
    {
        std::cerr << msg << '\n';
    }

    /* ------------FUNCTIONALITY 4-------------- */

    try
    {
        if (sum_of_square_of_even_numbers(input_data) == 0)
        {
            std::cout << "No even number present in the list " << std::endl;
        }
        else

        {
            std::cout << "Sum of squares of all numbers is : " << sum_of_square_of_even_numbers(input_data) << std::endl;
        }
    }
    catch (const std::string *msg)
    {
        std::cerr << msg << '\n';
    }

    /* ------------FUNCTIONALITY 5-------------- */

    try
    {
        Container odd_numbers_list = odd_number_divisible_by_7();
        if (odd_numbers_list.size() == 0)
        {
            std::cout << "Such number not exists " << std::endl;
        }
        else
        {
            std::cout << "List of odd numbers devisible by 7 is : ";
            for (int val : odd_numbers_list)
            {
                std::cout << val << " ";
            }
        }
        std::cout << "\n";
    }
    catch (const std::string *msg)
    {
        std::cerr << msg << '\n';
    }

    return 0;
}