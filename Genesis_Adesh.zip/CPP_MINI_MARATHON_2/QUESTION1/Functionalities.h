#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include <functional>
#include <list>

using Container = std::list<int>;

/*A function to find non vowels character from list */
extern std::function<void(std::string)> find_non_vowels;


/* A function to find sum of all odd numbers from list  */
extern std::function<int(Container &)> sum_of_odd_numbers;


/* A function to find the average of all even number from list */
extern std::function<float(Container &)> average_of_even_numbers;


/* A function to find and return sum of squares of all even numbers */
extern std::function<int(Container &)> sum_of_square_of_even_numbers;


/* A function to take N integers as input and return list of all odd numbers divisible by 7 */
extern std::function<Container()> odd_number_divisible_by_7;

#endif // FUNCTIONALITIES_H
