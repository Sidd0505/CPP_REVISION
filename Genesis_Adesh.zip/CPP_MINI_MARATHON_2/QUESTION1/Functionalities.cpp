#include "Functionalities.h"
#include <cstring>

std::function<void(std::string)> find_non_vowels = [](std::string user_string)
{
    if (user_string.empty())
    {
        throw std::runtime_error("USER STRING IS EMPTY");
    }

    std::cout << "Non vowels characters are : ";
    for (char val : user_string)
    {
        if (val != 'a' && val != 'e' && val != 'i' && val != 'o' && val != 'u' &&
            val != 'A' && val != 'E' && val != 'I' && val != 'O' && val != 'U')
        {
            std::cout << val << " ";
        }
    }
    std::cout<<"\n";
};

std::function<int(Container &)> sum_of_odd_numbers = [](Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("DATA IS EMPTY");
    }

    int sum = 0;
    for (int val : data)
    {
        if (val % 2 != 0)
        {
            sum = sum + val;
        }
    }
    return sum;
};

std::function<float(Container &)> average_of_even_numbers = [](Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("DATA IS EMPTY");
    }

    int sum = 0;
    for (int val : data)
    {
        if (val % 2 == 0)
        {
            sum = sum + val;
        }
    }
    return sum/data.size();
    
};

std::function<int(Container &)> sum_of_square_of_even_numbers = [](Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("DATA IS EMPTY");
    }

    int sum=0;
    for (int val : data)
    {
        if(val%2==0)
        {
            sum+=val*val;
        }
        
    }
    return sum;
};

std::function<Container()> odd_number_divisible_by_7 = []()
{
    Container result;
    int N = -1;
    int val;
    std::cout << "Enter count : ";
    std::cin>>N;
    for (int i = 0; i < N; i++)
    {
        std::cout << "Enter Number : ";
        std::cin >> val;
        if (val % 7 == 0 && val % 2 == 1)
        {
            result.push_back(val);
        }
    }

    return result;
};