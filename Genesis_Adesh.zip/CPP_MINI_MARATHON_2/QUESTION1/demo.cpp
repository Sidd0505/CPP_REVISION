#include<iostream>
#include<array>

// int main()
// {
//     std::array<int,5> arr{};
//     for(int i=0;i<5;i++)
//     {
//         std::cin>>arr[i];
//     }

//     for(int val:arr)
//     {
//         std::cout<<val*val<<" ";
//     }

//     return 0;
// }