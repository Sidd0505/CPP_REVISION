#ifndef MANUFACTURER_H
#define MANUFACTURER_H

enum class Manufacturer
{
Acura,
BMW,
Audi,
Cadillac,
Chevrolet
};

#endif // MANUFACTURER_H
