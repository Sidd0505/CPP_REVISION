#include "Functionalities.h"
#include "Car.h"
#include "EvTruck.h"

void CreateObject(Container &obj)
{
    int ch;
    std::string _id;
    std::string _name;
    int price;
    int category;
    int Capacity;
    std::cout << "Enter choice 1) Car 2) EvTruck";

    switch (ch)
    {
    case 1:
        std::cout << "Enter id : ";
        std::cin >> _id;
        std::cout << "Enter name : ";
        std::cin >> _name;
        std::cout << "Enter price : ";
        std::cin >> price;
        std::cout << "Enter category : ";
        std::cin >> category;
        obj.emplace_back(std::make_shared<Car>("101", "Name", 10000, CarCategory::HATCHBACK));
        break;

    case 2:
        std::cout << "Enter id : ";
        std::cin >> _id;
        std::cout << "Enter name : ";
        std::cin >> _name;
        std::cout << "Enter price : ";
        std::cin >> price;
        std::cout << "Enter capacity : ";
        std::cin >> Capacity;
        obj.emplace_back(std::make_shared<EvTruck>("101", "Name", 10000,Capacity));
        break;

    }
}



void SearchObjectById(Container &obj, std::string id)
{
    if(obj.empty())
    {
        throw std::runtime_error("EMPTY");
    }
    for (Pointer &ptr : obj)
    {
        if (ptr->id() == id)
        {
            std::cout<<*ptr;
        }
    }

}

