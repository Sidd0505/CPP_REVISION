#ifndef VEHICLE_H
#define VEHICLE_H
#include<iostream>
#include"VehicleType.h"

class Vehicle
{
private:

std::string _id;
std::string _name;
int price;

public:

    Vehicle(std::string _id,std::string _name,int price);

    Vehicle() = default;

    Vehicle(Vehicle &) = delete;

    Vehicle &operator=(Vehicle &) = delete;

    Vehicle &operator=(Vehicle &&) = delete;

    Vehicle(Vehicle &&) = delete;

    ~Vehicle() {}

    std::string id() const { return _id; }

    std::string name() const { return _name; }

    friend std::ostream &operator<<(std::ostream &os, const Vehicle &rhs);

    virtual void CalculateRegistrationCharges()=0;
   
};


#endif // VEHICLE_H
