#ifndef EVTRUCK_H
#define EVTRUCK_H
#include<iostream>
#include"Vehicle.h"

class EvTruck:public Vehicle
{
private:
    int battery_capacitry;
public:

    EvTruck(std::string _id,std::string _name,int price,int battery_capacitry);

    EvTruck() = default;

    EvTruck(EvTruck &) = delete;

    EvTruck &operator=(EvTruck &) = delete;

    EvTruck &operator=(EvTruck &&) = delete;

    EvTruck(EvTruck &&) = delete;

    ~EvTruck() {}

void CalculateRegistrationCharges() override;

    friend std::ostream &operator<<(std::ostream &os, const EvTruck &rhs);

  
};

#endif // EVTRUCK_H
