#include<iostream>
#include"Functionalities.h"

int main()
{
    Container obj;
    CreateObject(obj);
    std::cout<<*obj[0]<<std::endl;
    try
    {
         SearchObjectById(obj,"101");
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
   
   
    return 0;
}