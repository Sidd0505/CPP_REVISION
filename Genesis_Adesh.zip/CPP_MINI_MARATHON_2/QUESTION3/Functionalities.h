#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H
#include<vector>
#include<memory>
#include"Vehicle.h"

using Pointer=std::shared_ptr<Vehicle>;
using Container=std::vector<Pointer>;

void CreateObject(Container& obj);

void SearchObjectById(Container& obj,std::string id);

#endif // FUNCTIONALITIES_H
