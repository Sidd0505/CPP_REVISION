#ifndef VEHICLETYPE_H
#define VEHICLETYPE_H

enum class VehicleType
{
Car,
EvTruck
};

#endif // VEHICLETYPE_H
