#include "EvTruck.h"

EvTruck::EvTruck(std::string _id, std::string _name, int price, int battery_capacitry)
:Vehicle(_id,_name,price),battery_capacitry(battery_capacitry)
{
}
void EvTruck::CalculateRegistrationCharges()
{
    std::cout<<" ";
}
std::ostream &operator<<(std::ostream &os, const EvTruck &rhs)
{
    os << static_cast<const Vehicle &>(rhs)
       << " battery_capacitry: " << rhs.battery_capacitry;
    return os;
}
