#ifndef CARCATEGORY_H
#define CARCATEGORY_H

enum class CarCategory
{
SEDAN,SUV,HATCHBACK
};

#endif // CARCATEGORY_H
