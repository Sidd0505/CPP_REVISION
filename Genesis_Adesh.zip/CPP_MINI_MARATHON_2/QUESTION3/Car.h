#ifndef CAR_H
#define CAR_H
#include"Vehicle.h"
#include"CarCategory.h"
#include <ostream>

class Car:public Vehicle
{
private:
    CarCategory _category;
public:

    Car(std::string _id,std::string _name,int price,CarCategory category);

    Car() = default;

    Car(Car &) = delete;

    Car &operator=(Car &) = delete;

    Car &operator=(Car &&) = delete;

    Car(Car &&) = delete;

    ~Car() {}
    void CalculateRegistrationCharges() override;
    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);
};

#endif // CAR_H
