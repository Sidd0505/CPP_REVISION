#include"Vehicle.h"

Vehicle::Vehicle(std::string _id,std::string _name,int price):
_id(_id),_name(_name),price(price)
{

}
std::ostream &operator<<(std::ostream &os, const Vehicle &rhs) {
    os 
       << " _id: " << rhs._id
       << " _name: " << rhs._name
       << " price: " << rhs.price;
    return os;
}
