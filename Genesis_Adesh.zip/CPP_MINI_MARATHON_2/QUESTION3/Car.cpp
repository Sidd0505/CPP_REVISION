#include "Car.h"

Car::Car(std::string _id, std::string _name, int price, CarCategory category)
:Vehicle(_id,_name,price),_category(category)
{
}
void Car::CalculateRegistrationCharges()
{
}
std::ostream &operator<<(std::ostream &os, const Car &rhs)
{
    os << static_cast<const Vehicle &>(rhs)
       << " _category: " <<(int) rhs._category;
    return os;
}
