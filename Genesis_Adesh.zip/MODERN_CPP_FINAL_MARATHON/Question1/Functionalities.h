#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "Engine.h"
#include <iostream>
#include <memory>
#include <array>
#include <vector>
#include <optional>
using Pointer = std::shared_ptr<Engine>;
using Container = std::array<Pointer, 5>;

/* In functionality 1 we created objects and stored it into std::array of fixed size 5 */
void CreateObjects(Container &data);

/* 
In functionality 2 we need to return a container of _engine_type with matching criteria 
a) housepower should be >1000
b) enginecapacity < 2.0f
 */
std::vector<EngineType> ReturnContainerOfEngineTypeByCriteria(const Container &data);

/* Check _engineTorque value for all instances is above 10 or not */
bool CheckAllInstances(const Container& data);

/* A function to count instances whose enginecapacity is over a parameter set by user */

int InstanceCountForEngineCapacity(const Container& data,float threshold);

#endif // FUNCTIONALITIES_H
