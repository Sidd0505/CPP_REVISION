#include <iostream>
#include "Functionalities.h"
#include <optional>

int main()
{
    Container data;

    CreateObjects(data);

        try
    {
        std::vector<EngineType> result = ReturnContainerOfEngineTypeByCriteria(data);
        if (result.empty())
        {
            std::cout << "No matching data found .." << std::endl;
        }
        else
        {
            for (auto val : result)
            {
                if ((int)val == 0)
                {
                    std::cout << "PETROL, ";
                }

                if ((int)val == 1)
                {
                    std::cout << "DIESEL, ";
                }

                if ((int)val == 2)
                {
                    std::cout << "HYBRID, ";
                }
            }
        }
        std::cout<<std::endl;
    }
    catch (const std::string *msg)
    {
        std::cerr << msg << '\n';
    }

    try
    {
        bool result = CheckAllInstances(data);
        if (result)
        {
            std::cout << "Check All Instances : TRUE" << std::endl;
        }
        else
        {
            std::cout << "Check All Instances : FALSE" << std::endl;
        }
    }
    catch (const std::string *msg)
    {
        std::cerr << msg << '\n';
    }

    try
    {
        int result2 = InstanceCountForEngineCapacity(data, 1.5);
        std::cout << "Instance Count For Engine Capacity : " << result2 << std::endl;
    }
    catch (const std::string *msg)
    {
        std::cerr << msg << '\n';
    }
}