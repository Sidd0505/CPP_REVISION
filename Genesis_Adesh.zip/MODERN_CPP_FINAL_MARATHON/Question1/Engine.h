#ifndef ENGINE_H
#define ENGINE_H

#include<iostream>
#include"EngineType.h"

class Engine
{
private:
    std::string _engineid;
    int _horsepower;
    EngineType _engineType;
    float _engineCapacity;
    float _engineTorque;

public:

    
    Engine(std::string engineid,int horsepower,EngineType engineType,float engineCapacity,float engineTorque);
    Engine()=default;
    Engine(Engine&)=delete;
    Engine(Engine&&)=delete;
    Engine& operator=(Engine&)=delete;
    Engine& operator=(Engine&&)=delete;
    ~Engine()=default;

    std::string engineid() const { return _engineid; }

    int horsepower() const { return _horsepower; }

    EngineType engineType() const { return _engineType; }

    float engineCapacity() const { return _engineCapacity; }

    float engineTorque() const { return _engineTorque; }

    friend std::ostream &operator<<(std::ostream &os, const Engine &rhs);
};

#endif // ENGINE_H
