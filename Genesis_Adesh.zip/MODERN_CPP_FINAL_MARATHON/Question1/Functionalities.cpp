#include "Functionalities.h"
#include <algorithm>
void CreateObjects(Container &data)
{
    data[0] = std::make_shared<Engine>("E101", 1000, EngineType::PETROL, 1.0f, 90.0f);
    data[1] = std::make_shared<Engine>("E102", 1100, EngineType::DIESEL, 1.5f, 110.0f);
    data[2] = std::make_shared<Engine>("E103", 900, EngineType::DIESEL, 2.0f, 70.0f);
    data[3] = std::make_shared<Engine>("E104", 1500, EngineType::PETROL, 3.0f, 90.0f);
    data[4] = std::make_shared<Engine>("E105", 2000, EngineType::HYBRID, 5.0f, 80.0f);
}

std::vector<EngineType> ReturnContainerOfEngineTypeByCriteria(const Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("Data Empty");
    }
    std::vector<EngineType> Result;

    for (const Pointer &ptr : data)
    {
        if (ptr->horsepower() > 1000 && ptr->engineCapacity() < 2.0f)
        {
            Result.emplace_back(ptr->engineType());
        }
    }

    return Result;
}

bool CheckAllInstances(const Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("Data Empty");
    }
    return std::all_of(data.begin(),data.end(),[](const Pointer &ptr){return ptr->engineTorque()<110;});
  
}

int InstanceCountForEngineCapacity(const Container &data, float threshold)
{
    if (data.empty())
    {
        throw std::runtime_error("Data Empty");
    }
    // STL count_if algorithm is used to count instances 

    int count = std::count_if(data.begin(), data.end(), [&](const Pointer &ptr)
                              { return ptr->engineCapacity() > threshold; });
    return count;
}
