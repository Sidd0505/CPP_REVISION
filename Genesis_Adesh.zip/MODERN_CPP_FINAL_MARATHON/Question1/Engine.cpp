#include "Engine.h"

Engine::Engine(std::string engineid, int horsepower, EngineType engineType, float engineCapacity, float engineTorque)
    : _engineid(engineid), _horsepower(horsepower), _engineType(engineType), _engineCapacity(engineCapacity), _engineTorque(engineTorque)
{
}
std::ostream &operator<<(std::ostream &os, const Engine &rhs)
{
    os << "_engineid: " << rhs._engineid
       << " _horsepower: " << rhs._horsepower;
    switch (static_cast<int>(rhs._engineType))
    {
    case 0:
        os << " _engineType: PETROL";
        break;
    case 1:
        os << " _engineType: DIESEL";
        break;
    case 2:
        os << " _engineType: HYBRID";
        break;
    default:
        os << "Type not found";
        break;
    }

    os << " _engineCapacity: " << rhs._engineCapacity
       << " _engineTorque: " << rhs._engineTorque;
    return os;
}
