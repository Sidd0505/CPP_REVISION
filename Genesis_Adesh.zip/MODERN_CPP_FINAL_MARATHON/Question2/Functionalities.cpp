#include "Functionalities.h"
#include <algorithm>

void OddNumbersFromContainer(Container data)
{
    if (data.empty())
    {
        throw std::runtime_error("Empty data");
    }
    std::cout << "Odd numbers are : ";
    for (int val : data)
    {
        if (val % 2 == 1)
        {
            std::cout << val << " ";
        }
    }
    std::cout << "\n";
}

void CountOfElementDivisibleBy4(Container data)
{
    if (data.empty())
    {
        throw std::runtime_error("Empty data");
    }

    int count = std::count_if(data.begin(), data.end(), [](int val)
                              { return val % 4 == 0; });
    std::cout << "Count of Element Divisible By 4 is : " << count << std::endl;
}


void Operation(FnContainer fn, Container data)
{
    
    for (std::function<void(const Container &)> function : fn)
    {
        try
        {
            function(data);
        }
        catch(const std::string *msg)
        {
            std::cerr << msg << '\n';
        }
        
    }
}
