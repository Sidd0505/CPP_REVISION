#include <iostream>
#include "Functionalities.h"

int main()
{
    Container data{1, 2, 4, 7, 12};
    FnContainer fnData;

    fnData.emplace_back(OddNumbersFromContainer);

    fnData.emplace_back(CountOfElementDivisibleBy4);

    /* passed a temprorary lambda function to find largest and second largest element from container and print sum of them  */
    fnData.emplace_back([](Container data)
                        {
                            if (data.empty())
                            {
                                throw std::runtime_error("Empty data");
                            }

                            auto largest=std::max_element(data.begin(),data.end());
                            int secondLargest=data[0];

                            for(int val:data)
                            {
                                if(val<(*largest) && val>secondLargest)
                                {
                                    secondLargest=val;
                                }
                            }   

                            std::cout<<"Sum of "<<*largest<<" and "<<secondLargest<<" id : "<<*largest+secondLargest<<std::endl; 
                        });


    /* passed a tempory lambda function to find minimum element from a container */
    fnData.emplace_back([](Container data)
                        {
                            if (data.empty())
                            {
                                throw std::runtime_error("Empty data");
                            }

                            auto minimum=std::min_element(data.begin(),data.end());
                            std::cout<<"Minimum element is : "<<*minimum<<std::endl; 
                        });

    
    Operation(fnData, data);
}