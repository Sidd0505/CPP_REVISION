#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include<functional>
#include<array>
#include<vector>

using Container=std::array<int,5>;

using FnType=std::function<void(Container)>;
using FnContainer=std::vector<FnType>;

void OddNumbersFromContainer(Container data);

void CountOfElementDivisibleBy4(Container data);

void Operation(FnContainer fn,Container data);


#endif // FUNCTIONALITIES_H
