#include "Functionalities.h"
#include <algorithm>

void CreateObjects(Container &data)
{
    data.emplace_back(std::make_shared<FullTimeEmployee>("Adesh", "A101", 800000.0f, "BMW", "PUNE", Grade::A, 50));
    data.emplace_back(std::make_shared<FullTimeEmployee>("Aniket", "A102", 700000.0f, "Audi", "PUNE", Grade::B, 40));
    data.emplace_back(std::make_shared<FullTimeEmployee>("Parth", "P103", 900000.0f, "Honda", "PUNE", Grade::C, 30));
}

void InvokeCalculateBonus(Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("Empty data");
    }

    for (Pointer &ptr : data)
    {
        std::cout << "Calculated bonus is : " << ptr->CalculateBonus() << std::endl;
    }
}

void HighestSalary(Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("Empty data");
    }

    auto Max = std::max_element(data.begin(), data.end(), [](const Pointer &ptr1, const Pointer &ptr2)
                                { return ptr1->salary() < ptr2->salary(); });
    std::cout << *Max->get() << std::endl;
}

void DisplayEmployeeLocationByGrade(Container &data, std::future<Grade> &ft)
{
    if (data.empty())
    {
        throw std::runtime_error("Empty data");
    }

    auto Result = std::find_if(data.begin(), data.end(), [&](const Pointer &ptr)
                               { return ptr->grade() == ft.get(); });
    if (Result == data.end())
    {
        std::cout << "Grade not Found " << std::endl;
    }
    else
    {
        std::cout << "Employee Location By Grade is : " << Result->get()->employeeLocation() << std::endl;
    }
}

std::string ProjectNameById(Container &data, std::future<std::string> &ft)
{
    if (data.empty())
    {
        throw std::runtime_error("Empty data");
    }

    auto Result = std::find_if(data.begin(), data.end(), [&](const Pointer &ptr)
                               { return ptr->id() == ft.get(); });
    if (Result == data.end())
    {
        return "Id not found";
    }
    return Result->get()->projectName();
}
