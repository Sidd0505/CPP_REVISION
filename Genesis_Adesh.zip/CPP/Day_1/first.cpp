#include<iostream>
using namespace std;

class demo
{
    public : void display()
    {
        cout<<"Hello";
    }
};
int main()
{
    demo ob;
    ob.display();
     return 0;
}