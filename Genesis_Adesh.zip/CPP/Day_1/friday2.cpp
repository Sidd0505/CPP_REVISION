#include<iostream>



class Rectangle
{
    
    int length,width;
    public:
    Rectangle()
    {
        length=0;
        width=0;

    }
    Rectangle(int l,int w)
    {
        length=l;
        width=w;
    }   

    void show();
    Rectangle add(Rectangle r2);
    Rectangle substract(Rectangle r2);
    void compare(Rectangle r2);
};

Rectangle Rectangle :: add(Rectangle r2)
    {
        Rectangle sumobj;
        sumobj.length=this->length+r2.length;
        sumobj.width=this->width+r2.width;
        return sumobj;
    }

    Rectangle Rectangle :: substract(Rectangle r2)
    {
        Rectangle sumobj;
        sumobj.length=this->length-r2.length;
        sumobj.width=this->width-r2.width;
        return sumobj;
    }

void Rectangle::show()
{
    std::cout<<"The length value is:"<<length<<"\n";
    std::cout<<"The length value is:"<<length<<"\n";
}

void Rectangle :: compare(Rectangle r2)
{
    if(this->length==r2.length)
    {
        std::cout<<"True"<<std::endl;
    }
    else
    {
        std::cout<<"False"<<std::endl;
    }
}



int main()
{
    Rectangle obj1(10,10);
    Rectangle obj2(10,10);
    Rectangle obj3=obj1.add(obj2);
    obj3.show();
    obj3=obj1.substract(obj2);
    obj3.show();
    
    obj3.compare(obj2);
    return 0;
}
// Rectangle r1(2,3),r2(4,7)
// Rectangle r3=r1.add(r2);
// Rectangle r4=r1.subtract(r2)
// bool flag=r1.compare(r2);//length & width
// r1.calculateArea()
// r1.calculatePerimeter()