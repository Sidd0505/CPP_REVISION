#include<iostream>
#include<cstring>
using namespace std;
class Vehicle
{
    char model[20];
    char color[20];
    int year;
    int price;
    public:
    Vehicle()
    {
        strcpy(model,"base");
        strcpy(color,"black");
        year=1995;
        price=95000;
    }
    void display_details()
    {
        cout<<"vehical model: "<<model<<endl;
        cout<<"vehical color: "<<color<<endl;
        cout<<"vehical year: "<<year<<endl;
        cout<<"vehical price: "<<price<<endl;
    }

    void accept_details()
    {
        cout<<"Enter model name"<<endl;
        cin>>model;
        cout<<"Enter model color"<<endl;
        cin>>color;
        cout<<"Enter model year"<<endl;
        cin>>year;
        cout<<"Enter vehical price"<<endl;
        cin>>price;
    }
    
};

class Product
{
string name,Description;
int price,Quantity;

void display_product_details()
{

}

void update_price()
{

}


};
int main()
{
    Vehicle obj;
   // obj.accept_details();
    obj.display_details();
    return 0;
}

//constructer
//getter setter
// design patterns in c++