#include <iostream>
#include <cstring>
#include "header.h"

int main()
{
    int size = 0, ch;
    int search = 0;
    Account *AccountArray = new Account[5];
    int index = 0;
    std::cout << "Size: " << std::endl;
    std::cin >> size;

    while (1)
    {
        std::cout << "MENU 1> ACCEPT 2> DISPLAY 3> SEARCH 4> EXIT\n";
        std::cin >> ch;
        switch (ch)
        {
        case 1:
            if (index >= size)
            {
                std::cout << "Stack is full..\n";
            }
            else
            {
                AccountArray[index++].Accept();
            }

            break;

        case 2:
            if (index <= 0)
            {
                std::cout << "Stack is empty..\n";
            }
            else
            {
                for (int i = 0; i < index; i++)
                {
                    AccountArray[i].Display();
                }
            }
            break;
        case 3:

            std::cout << "Enter id to search\n";
            std::cin >> search;
            if (index <= 0)
            {
                std::cout << "Stack is empty..\n";
            }
            else
            {
                for (int i = 0; i < index; i++)
                {
                    if (AccountArray[i].Emp_id == search)
                    {
                        AccountArray[i].Display();
                    }
                }
            }
            break;
        case 4:
            return 0;
            break;
        }
    }
}