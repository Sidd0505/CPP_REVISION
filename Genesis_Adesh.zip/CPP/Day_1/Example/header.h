
#include <iostream>
#include <cstring>
class Account
{
public:
    int Emp_id;
    int Account_Number;
    char name[10];

    Account()
    {
        
    }

    Account(int Eid, int Acc_no, char n[]) : Emp_id(Eid), Account_Number(Acc_no)
    {
        strcpy(name, n);
    }
    void Display();
    void Accept();
};
