#include <iostream>
#include "header.h"

void Account::Display()
{
        std::cout << Emp_id << std::endl;
        std::cout << Account_Number << std::endl;
        std::cout << name << std::endl;
    
}


void Account::Accept()
{
    std::cout << "Enter emp id: ";
    std::cin >> Emp_id;
    std::cout << "Enter Account no: ";
    std::cin >> Account_Number;
    std::cout << "Enter Name: ";
    std::cin >> name;
}
