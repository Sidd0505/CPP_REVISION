#include <iostream>
#include <cstring>

class Account
{
public:
    int AccountNo;
    char name[20];

    Account() // Default Constructor
    {
    }
    Account(const int acno, const char *na) : AccountNo(acno) //  Constructor
    {
        strcpy(name, na);
    }

    Account(const Account &obj) : AccountNo(obj.AccountNo) // copy
    {

        strcpy(name, obj.name);
    }

    Account Accept();
};

int main()
{
    int accountno;
    char n[20];
    Account *AccountArray=new Account[5];
    int choice, i = 0;
    while (true)
    {
        std::cout << "MENU \n";
        std::cout << "1. Accept :\n";
        std::cout << "2. Display :\n";
        std::cout << "3. Search :\n";
        std::cout << "4. Exit :\n";
        std::cout << "Enter your choice\n";
        std::cin >> choice;

        switch (choice)
        {
        case 1:
            if (i < 5)
            {
                std::cout << "Enter Account No: \n";
                std::cin >> accountno;
                std::cout << "Enter Name: \n";
                std::cin >> n;
                Account useracc(accountno, n);
                AccountArray[i] = useracc;
                i++;
            }
            else
            {
                std::cout << "Stack is full\n";
            }
            break;

        case 2:
            if (i == 0)
            {
                std::cout << "No Account to display\n";
            }
            else
            {

                for (int j = 0; j < i; j++)
                {
                    std::cout << "Account NO : " << AccountArray[j].AccountNo << std::endl;
                    std::cout << "Name : " << AccountArray[j].name << std::endl;
                }
            }
            break;

        case 3:
            int search;
            int flag;
            std::cout << "ENter account no to search: " << std::endl;
            std::cin >> search;

            for (int j = 0; j < i; j++)
            {
                if (AccountArray[j].AccountNo == search)
                {
                    flag = 1;
                    std::cout << "found" << std::endl;
                    break;
                }
            }
            if (flag == 0)
            {
                std::cout << "Not found\n";
            }
            break;

        case 4:
        delete AccountArray;
            return 0;
            break;
        }
    }
    return 0;
}

//input (*p,index)->global

// create class stack
// int *ptr->5
// push and pop implement