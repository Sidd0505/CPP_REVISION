#include <iostream>

class Account
{
public:
    int AccountNumber;
    Account()
    {
    }
    Account(int acno)
    {
        AccountNumber=acno;
    }
    int getAccountNumber() 
    {
        return AccountNumber;
    }

};

int main()
{
    const int Acno = 3;
    Account obj[Acno];
    obj[0] = Account(1001);
    obj[1] = Account(1002);
    obj[2] = Account(1003);

    int accountfind = 1003;

    bool found = false;
    for (int i = 0; i < Acno; i++)
    {
        if (obj[i].getAccountNumber() == accountfind)
        {
            found = true;
            break;
        }
    }

    if (found)
    {
        std::cout << "Found";
    }
    else
    {
        std::cout << "not Found";
    }
    return 0;
}