#include <iostream>
class A
{
public:
    void print(double i)
    {
        std::cout << i;
    }
    void print(int i)
    {
        std::cout << i;
    }
    // void print(float i)
    // {
    //     std::cout << i;
    // }
};

int main()
{
    A obj;
    obj.print(9.0);
    return 0;
}