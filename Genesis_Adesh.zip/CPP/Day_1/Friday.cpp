#include<iostream>
#include<cstring>
class Product
{
    public:
    int product_id;
    int year;
    char *name;

    public:
    Product()
    {
        product_id=1001;
        name=new char[20];
        strcpy(name,"Adesh");
    }

    Product(int pid,const char na[],int y)
    {
        product_id=pid;
        year=y;
        name=new char[20];
        strcpy(name,na);
    }

    //  void accept()
    // {
    //     std::cout<<"Product Id :"<<std::endl;
    //     std::cin>>product_id;
    //     std::cout<<"Product Name:"<<std::endl;
    //     std::cin>>name;
    //     std::cout<<"Product Year:"<<std::endl;
    //     std::cin>>*year;
        
    // }

    void display()
    {
        std::cout<<"Product Id :"<<product_id<<std::endl;
        std::cout<<"Product Name:"<<name<<std::endl;
        std::cout<<"Product Year:"<<year<<std::endl;
    }
    ~Product()
    {
        //delete year;
         //std::cout<<"Destructer Called..."<<std::endl;
        //delete name;
        
        std::cout<<"Destructer Called..."<<std::endl;
    }

};
int main()
{
    
    Product obj(1001,"Adesh",2003);
    Product obj2(1001,"Adesh",2004);
    obj.display();
    obj2.display();
    
    if(obj.year==obj2.year)
    {
        std::cout<<"\nTrue";
    }
    return 0;
}
