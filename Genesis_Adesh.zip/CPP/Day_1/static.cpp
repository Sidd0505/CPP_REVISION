#include <iostream>
class addition
{
    public:
   
    void add(int a, int b=0)
    {
        std::cout << a + b;
    }
    
};

int main()
{
    addition obj;
    obj.add(10);
    return 0;
}