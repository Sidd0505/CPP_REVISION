#include<iostream>
using namespace std;

class student
{
int marks;
int cgpa;
student()
{}
 student(int i,int j)
 {
     marks=i;
     cgpa=j;
 }

};

int main()
{
    //student s[2]={s(10,20),s(30,40)};
    return 0;
    student obj;
    //class student {int rollno;char name[20];static int studentnp;}; size is 24
}