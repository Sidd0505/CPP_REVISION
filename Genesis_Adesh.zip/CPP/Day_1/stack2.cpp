#include<iostream>

class stack
{
    int top;
    int size;
    int *stackArray;
    public:

    stack(int *stackArray,int s):stackArray(stackArray),size(s),top(-1)
    {

    }

    void push(int value)
    {
        if(top<size-1)
        {
            stackArray[++top]=value;
        }
        else
        {
            std::cout<<"Stack is Full...!!"<<std::endl;
        }
        
    }
    
    void pop()
    {
         if(top>=size)
        {
            std::cout<<"Stack is Empty...!!"<<std::endl;
        }
        else
        {
            top--;
        }
    }
    void display()
    {
        for(int i=0;i<=top;i++)
        {
            std::cout<<stackArray[i]<<" ";
        }
        std::cout<<std::endl;
    }


};

int main()
{
    int *stackArray=new int[5];
    stack obj(stackArray,5);
    obj.push(5);
    obj.push(6);
    obj.push(7);
    obj.push(8);
    obj.push(9);
    obj.push(10);
    obj.push(11);
    obj.display();
    return 0;
}