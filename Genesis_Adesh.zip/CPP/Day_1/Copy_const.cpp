#include<iostream>

class A
{
    int a;
    public:
    A()
    {
        std::cout<<"Default Constructor called\n";
    }
    A(int a,int b)
    {
        std::cout<<"Parameterized Constructor called\n";
    }
    A(const A& )
    {
        std::cout<<"Copy Constructor called\n";
    }
};
int main()
{
    A obj;
    A a1=obj;
    A a2(10,20);
    A a2(obj);
    return 0;
}