#include <iostream>
#include <cstring>
class product
{
public:
    char p[5];
    product()
    {
        strcpy(p, "Adesh");
    }
    char &operator[](int index);
};
char &product::operator[](int index)
{
    return p[index];
}

int main()
{
    product obj;
    std::cout << obj[3] << std::endl;
    return 0;
}

// insertion operator
// member function
// non member function
// constructor overloading
// enum
// operator overloading
// function overloading
// destructor
// 
