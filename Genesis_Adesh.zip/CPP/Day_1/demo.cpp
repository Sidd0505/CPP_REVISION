#include<iostream>
class demo{
    int a;
    public:
    

}
int main()
{
    // myclass obj;
    obj.show();
    // int num1=10;
    // int *p1=&num1;
    // int &r=*p1;
    // r=100;
    // std::cout<<r<<" "<<num1;
    
    return 0;
}