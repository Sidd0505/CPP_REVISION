#include <iostream>

template <class T>
void exchage(T &a, T &b)
{
    T t;
    t = a;
    a = b;
    b = t;
}
int main()
{
    int n1 = 10, n2 = 20;
    exchage(n1, n2);
    std::cout << "n1 = " << n1 << " n2 = " << n2 << std::endl;

    double f1 = 10.50, f2 = 20.30;
    exchage(f1, f2);
    std::cout << "f1 = " << f1 << " f2 = " << f2 << std::endl;

    char c1 = 'A', c2 = 'B';
    exchage(c1, c2);
    std::cout << "c1 = " << c1 << " c2 = " << c2 << std::endl;
    return 0;
}