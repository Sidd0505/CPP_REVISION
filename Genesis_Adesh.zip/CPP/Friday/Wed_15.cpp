#include<iostream>












// class A 
// {
// int x;
// public : int y;
// protected : int z;
// };
// class B:protected A{
//     public:
//     void show()
//     {

//     }
// };
// class C:protected B{

// };
// int main()
// {
//     A obj1;
//     obj1.y;
//     B obj2;
//     //obj2.y;
//     C obj2;
//     //obj2.y;
//     return 0;
// }
//smart pointer
//dynamic_cast
//static cast
//inheritance
//pure virtual
//polymorphism 
//typeid()
//dimmond inheritance/ virtual mode of inheritance
//multilevel
//multiple
//obj.A::function_name()