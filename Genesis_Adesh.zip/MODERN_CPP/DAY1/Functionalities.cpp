#include "Functionalities.h"

void CreateObjects(vehicle **arr, const int size)
{
    // arr[0]=new vehicle(101,"Maruti Dzire",900000.00,VehicleType::PERSONAL);
    // arr[1]=new vehicle(101,"Maruti Dzire",900000.00,VehicleType::PERSONAL);
    // arr[2]=new vehicle(101,"Maruti Dzire",900000.00,VehicleType::PERSONAL);

    int id = 0;
    std::string name = "";
    float price = 0.0f;
    VehicleType type = VehicleType::PERSONAL;
    int choice = -1;

    for (int i = 0; i < size; i++)
    {
        std::cin >> id;
        std::cin >> name;
        std::cin >> price;
        std::cin >> choice;

        if (choice == 0)
        {
            type = VehicleType::PERSONAL;
        }

        else if (choice == 1)
        {
            type = VehicleType::SECURITY;
        }

        else if (choice == 2)
        {
            type = VehicleType::TRANSPORT;
        }

        else
        {
            type = VehicleType::PERSONAL;
        }

        arr[i] = new vehicle(id, name, price, type);
    }
}

float AveragePrice(vehicle **arr, const int size)
{
    try
    {
        if (size == 0)
        {
            throw "Empty array....!";
        }
        else
        {
            float total = 0.0f;

            for (int i = 0; i < size; i++)
            {
                total += arr[i]->Price();
            }
            std::cout << "Average Price : " << total / size;
            
        }
        return 0;
    }
    catch (const char *msg)
    {
        std::cout << msg << '\n';
        return 0;
    }
}

int LowestPrice_Id(vehicle **arr, const int size)
{
    int ans = arr[0]->Id();
    float lowest_price = arr[0]->Price();

    for (int i = 1; i < size; i++)
    {
        float current_price = arr[i]->Price();
        if (current_price < lowest_price)
        {
            lowest_price = current_price;
            ans = arr[i]->Id();
        }
    }

    return ans;
}

void display_details(vehicle **arr,const int size)
{
    for(int i=0;i<size;i++)
    {
        std::cout<<arr[i]->Id()<<std::endl;
        std::cout<<arr[i]->Price()<<std::endl;
        std::cout<<arr[i]->modelName()<<std::endl;
        switch(static_cast<int>(arr[i]->getType()))
        {
            case 0:
            std::cout<<"PERSONAL"<<std::endl;
            break;

            case 1:
            std::cout<<"SECURITY"<<std::endl;
            break;

            case 2:
            std::cout<<"TRANSPORT"<<std::endl;
            break;

            default:
            break;
        }
        
    }
   
    
}
