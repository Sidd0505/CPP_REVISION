#include "vehicle.h"
#include "Functionalities.h"

int main()
{
    const int size = 3;
    vehicle *arr[3] = {nullptr};

    CreateObjects(arr, size);
    AveragePrice(arr,size);

    // float ans = AveragePrice(arr, size);
    // std::cout << "Average price : " << ans << std::endl;

    float lowest = LowestPrice_Id(arr, size);
    std::cout << "Lowest price id : " << lowest << std::endl;

    display_details(arr,size);
}