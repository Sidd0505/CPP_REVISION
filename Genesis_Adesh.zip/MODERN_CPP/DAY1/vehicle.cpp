#include "vehicle.h"

vehicle::vehicle(int _id, std::string _model, float _price, VehicleType _type)
:id(_id),model_name(_model),price(_price),type(_type) { }