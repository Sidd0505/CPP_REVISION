#ifndef VEHICALTYPE_H
#define VEHICALTYPE_H

#include <iostream>
// enum VehicleType{};
enum class VehicleType
{
    PERSONAL,
    TRANSPORT,
    SECURITY
};

#endif // VEHICALTYPE_H
