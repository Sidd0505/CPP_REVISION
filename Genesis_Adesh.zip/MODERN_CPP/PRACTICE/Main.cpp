#include <iostream>
#include "Functionalities.h"

int main()
{
    Container obj;
    CreateObject(obj);

    /* <------- Functionality 1 -------> */
    try
    {
        std::cout << "Id of order whose discount is highest is : " << id_of_highest_discount(obj) << std::endl;
    }
    catch (const std::runtime_error e)
    {
        std::cerr << e.what() << '\n';
    }

    /* <------- Functionality 2 -------> */

    try
    {
        switch (static_cast<int>(type_of_order(obj, 103)))
        {
        case 0:
            std::cout << "Type of the given id is : PAID " << std::endl;
            break;

        case 1:
            std::cout << "Type of the given id is : COD " << std::endl;
            break;

        case 2:
            std::cout << "Type of the given id is : PROMOTION " << std::endl;
            break;

        default:
            break;
        }
    }
    catch (const std::runtime_error e)
    {
        std::cerr << e.what() << '\n';
    }

    /* <------- Functionality 3 -------> */

    try
    {
        std::cout << "Average is : " << average_value_of_all_orders(obj)<<std::endl;
    }
    catch (const std::runtime_error e)
    {
        std::cerr << e.what() << '\n';
    }

    /* <------- Functionality 4 -------> */

    try
    {
        Container result = n_instances(obj, 3);
        
        for (Pointer &ptr : result)
        {
            std::cout << *ptr << std::endl;
        }
    }
    catch (const std::runtime_error e)
    {
        std::cerr << e.what() << '\n';
    }

    return 0;
}