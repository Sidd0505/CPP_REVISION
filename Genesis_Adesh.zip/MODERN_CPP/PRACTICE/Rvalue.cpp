#include<iostream>

int magic(int&& a)
{
    return ++a;
}
int magic(int& a)
{
    return ++a;
}
// int main()
// {
//     int a=10;
//     std::cout<<magic(a)<<std::endl;
//     return 0;
// }