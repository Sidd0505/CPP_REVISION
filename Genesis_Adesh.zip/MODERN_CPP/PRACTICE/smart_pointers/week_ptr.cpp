#include<iostream>
#include<memory>

int main()
{
    return 0;
}