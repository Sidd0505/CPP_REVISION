#include<iostream>
#include<memory>

int magic_with_memory_leak()
{
    int *ptr=new int(15);
    int x=15;
    if(x==15)
    {
        return 1;//memory leak
    }
    delete ptr;
return 0;
}

int magic_without_memory_leak()
{
    std::unique_ptr<int>ptr(new int(15));
    int x=15;
    if(x==15)
    {
        return 1;
    }
    return 0;
}

int main()
{
    std::unique_ptr<int> ptr;//create unique pointer
    ptr.reset(new int(10));//assign value to pointer

    std::unique_ptr<int> ptr2(std::move(ptr));

    std::cout<<"ptr2 value "<<*ptr2<<std::endl;
    std::cout<<"ptr2 value "<<std::boolalpha<<static_cast<bool>(*ptr2)<<std::endl;
    return 0;
}

/* 
A unique_ptr can only be moved. 
This means that the owenership of the memory is transferred to another unique_ptr
and the original unique_ptr no longer owns it.
*/k