#include<iostream>
#include<memory>
//shared ptr mainly used with OOP

class Foo
{
    public: 
    void dosomething();
};
class Bar
{
    private:
    std::shared_ptr<Foo> pFoo;
    public:
    Bar()
    {
        pFoo=std::shared_ptr<Foo>(new Foo());
    }
    std::shared_ptr<Foo> getFoo()
    {
        return pFoo;
    }
};
int main()
{
    std::make_shared<Bar>()->getFoo()->dosomething();
    std::shared_ptr<int>ptr(new int(10));
    std::shared_ptr<int>ptr2=ptr;
    std::cout<<*ptr<<std::endl;
    std::cout<<*ptr2<<std::endl;
    // Bar obj;
    // obj.getFoo()->dosomething();
    return 0;
}


void Foo::dosomething()
{
    std::cout<<"dosomething()"<<std::endl;
}
