#include<iostream>
#include<thread>
#include<array>
#include<future>
#include<vector>
#include<mutex>

std::mutex m;
using Container=std::array<int,6>;

static int i=0;

void increment_i()
{
    m.lock();
    i=i+1;
    m.unlock();
}
int main()
{
    std::vector<std::thread> t;
    for(int i=0;i<100;i++)
    {
        t.push_back(std::thread(increment_i));
    }
    for(int i=0;i<100;i++)
    {
        t[i].join();
    }
    std::cout<<"Value of i "<<i<<"\n";
    return 0;
}