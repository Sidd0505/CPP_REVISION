#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>

std::mutex glock;
std::condition_variable gcondition;

int main()
{
    int result = 0;

    bool notify = false;

    std::thread reported([&]()
                         {
    std::unique_lock<std::mutex> lock(glock);
    if(!notify)
    {
        gcondition.wait(lock);
    }
    std::cout<<"Reported Result is :"<<result<<std::endl; });



    std::thread worker([&]()
                       {
                           std::unique_lock<std::mutex> lock(glock);
                           result = 42 * 1 + 7;
                           notify = true;
                           std::this_thread::sleep_for(std::chrono::seconds(5));
                           std::cout << "Work complete";
                           gcondition.notify_one();
                       });

    reported.join();
    worker.join();
    return 0;
}


void CalculateTaxPayable(const Container &data)
{
    for (const DataPointer &ptr : data)
    {
        const Vtype &val = ptr->instances();

        if (std::holds_alternative<BusinessPointer>(val))
        {
            const BusinessPointer &ptr = std::get<BusinessPointer>(val);
            std::cout << "Tax is : " << (ptr->revenue() - ptr->expense()) * 0.1 << "\n";
        }

        const EmployeePointer &emp = std::get<EmployeePointer>(val);
        if (emp->type() == EmployeeType::REGULAR)
        {
            std::cout << "Tax is : " << emp->salary() * 0.1 << "\n";
        }
        else
        {
            std::cout << "Tax is : " << emp->salary() * 0.2 << "\n";
        }
    }
}
