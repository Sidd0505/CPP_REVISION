#ifndef VEHICAL_H
#define VEHICAL_H

#include<iostream>
class Vehicle
{
private:

    int _vehicleId;
    std::string _vehicleName;

public:

    Vehicle(int _vehicleId,std::string _vehicleName);

    Vehicle() = default;

    Vehicle(Vehicle &) = delete;

    Vehicle &operator=(const Vehicle &) = delete;

    Vehicle(Vehicle &&) = delete;

    Vehicle &operator=(const Vehicle &&) = delete;

    ~Vehicle() = default;

    virtual void move()=0;

    friend std::ostream &operator<<(std::ostream &os, const Vehicle &rhs);
};
#endif // VEHICAL_H
