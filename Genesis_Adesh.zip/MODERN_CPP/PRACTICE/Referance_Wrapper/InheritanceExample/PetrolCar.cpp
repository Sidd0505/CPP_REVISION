#include "PetrolCar.h"

Petrol::Petrol(int _vehicleId, std::string _vehicleName, int capacity)
:Vehicle(_vehicleId,_vehicleName),capacity(capacity)
{
}
void Petrol::move()
{
    std::cout<<"Petrol Car move()"<<std::endl;
}
std::ostream &operator<<(std::ostream &os, const Petrol &rhs)
{
    os << static_cast<const Vehicle &>(rhs)
       << " capacity: " << rhs.capacity;
    return os;
}
