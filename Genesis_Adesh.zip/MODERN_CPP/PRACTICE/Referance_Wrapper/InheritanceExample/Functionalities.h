#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<memory>
#include<vector>
#include"Vehicle.h"
#include<functional>

using Pointer=std::shared_ptr<Vehicle>;
using Reference=std::reference_wrapper<Pointer>;
using Container=std::vector<Reference>;

void CreateObject(Container& data);
void displayDetails(Container& data);
#endif // FUNCTIONALITIES_H
