#include<iostream>
#include"Functionalities.h"
#include"PetrolCar.h"
#include"EvCar.h"

using Pointer1=std::shared_ptr<Vehicle>;
using Reference1=std::reference_wrapper<Pointer1>;
using Container1=std::vector<Reference1>;

int main()
{
    Container obj;
    CreateObject(obj);
    displayDetails(obj);

    return 0;
}