#include"Functionalities.h"
#include"PetrolCar.h"
#include"EvCar.h"

void CreateObject(Container& data)
{

    Pointer obj3=std::make_shared<Petrol>(101,"ABC",100);
    Reference refobj(obj3);

    Pointer obj2=std::make_shared<EvCar>(102,"PQR",19);
    Reference refobj1(obj2);

    data.emplace_back(refobj);
    data.emplace_back(refobj1);   
for(Pointer& ptr:data)
    {
        if(typeid(*ptr)==typeid(Petrol))
        {
            std::cout<<*(std::dynamic_pointer_cast<Petrol>(ptr))<<std::endl;
        }
        else if(typeid(*ptr)==typeid(EvCar))
        {
            std::cout<<*(std::dynamic_pointer_cast<EvCar>(ptr))<<std::endl;
        } 
    }
}

void displayDetails(Container &data)
{
     for(Pointer& ptr:data)
    {
        if(typeid(*ptr)==typeid(Petrol))
        {
            std::cout<<*(std::dynamic_pointer_cast<Petrol>(ptr))<<std::endl;
        }
        else if(typeid(*ptr)==typeid(EvCar))
        {
            std::cout<<*(std::dynamic_pointer_cast<EvCar>(ptr))<<std::endl;
        } 
    }
}
