#ifndef PETROLCAR_H
#define PETROLCAR_H
#include"Vehicle.h"
#include<iostream>
class Petrol:public Vehicle
{
private:
    int capacity;

public:

    Petrol(int _vehicleId,std::string _vehicleName,int capacity);

    Petrol() = default;

    Petrol(Petrol &) = delete;

    Petrol &operator=(const Petrol &) = delete;

    Petrol(Petrol &&) = delete;

    Petrol &operator=(const Petrol &&) = delete;

    ~Petrol() = default;

    void move() override;

    friend std::ostream &operator<<(std::ostream &os, const Petrol &rhs);
};

#endif // PETROLCAR_H
