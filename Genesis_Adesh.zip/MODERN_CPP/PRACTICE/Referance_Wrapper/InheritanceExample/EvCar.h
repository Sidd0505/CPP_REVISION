#ifndef EVCAR_H
#define EVCAR_H

#include"Vehicle.h"
#include<iostream>
class EvCar:public Vehicle
{
private:

    int percentage;

public:

    
    EvCar(int _vehicleId,std::string _vehicleName,int percentage);

    EvCar() = default;

    EvCar(EvCar &) = delete;

    EvCar &operator=(const EvCar &) = delete;

    EvCar(EvCar &&) = delete;

    EvCar &operator=(const EvCar &&) = delete;

    ~EvCar() = default;

    void move() override;

    friend std::ostream &operator<<(std::ostream &os, const EvCar &rhs);
};

#endif // EVCAR_H
