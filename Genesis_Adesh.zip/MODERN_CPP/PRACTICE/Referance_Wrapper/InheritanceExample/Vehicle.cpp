#include "Vehicle.h"

Vehicle::Vehicle(int _vehicleId, std::string _vehicleName)
:_vehicleId(_vehicleId),_vehicleName(_vehicleName)
{
}
std::ostream &operator<<(std::ostream &os, const Vehicle &rhs) {
    os << "_vehicleId: " << rhs._vehicleId
       << " _vehicleName: " << rhs._vehicleName;
    return os;
}
