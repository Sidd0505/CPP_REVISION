#include "EvCar.h"

EvCar::EvCar(int _vehicleId, std::string _vehicleName, int percentage)
:Vehicle(_vehicleId,_vehicleName),percentage(percentage)
{
}



void EvCar::move()
{
    std::cout<<"Ev Car move()"<<std::endl;
}
std::ostream &operator<<(std::ostream &os, const EvCar &rhs) {
    os << static_cast<const Vehicle &>(rhs)
       << " percentage: " << rhs.percentage;
    return os;
}
