
#include <iostream>	 
#include <functional> 
#include<vector>

void magic(std::reference_wrapper<int> n1)
{
    std::cout<<"Address of n1 "<<&n1<<std::endl;
    std::vector<std::reference_wrapper<int>>arr{n1};
    std::cout<<"Address of arr "<<&arr<<std::endl;
     std::cout<<"Address of data present in arr "<<(arr[0].get())<<std::endl;

     int& temp=n1;
     std::cout<<n1<<std::endl;
}
int main () 
{ 
    int a=10;
    int& ref=a;
    magic(a);
	return 0; 
} 
