#include "Car.h"
#include<functional>
Car::Car(int carId, std::string carName, float carPrice, CarType type, RefType engine)
:_carId(carId),_carName(carName),_carPrice(carPrice),_carType(type),_engine(engine)
{

}
std::ostream &operator<<(std::ostream &os, const Car &rhs) {
    os << "_carId: " << rhs._carId
       << " _carName: " << rhs._carName
       << " _carPrice: " << rhs._carPrice
       << " _carType: " << static_cast<int>(rhs._carType)
       << " _engine: " << *rhs._engine.get();
    return os;
}

