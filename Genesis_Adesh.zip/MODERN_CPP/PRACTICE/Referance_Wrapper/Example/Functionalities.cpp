#include "Functionalities.h"

// void CreateObject(carContainer& obj,EngineContainer& obj2)
// {
//     obj2[0]=std::make_shared<Engine>(101,EngineType::E1);
//     obj[0]=std::make_shared<Car>(101,"ABC",80000.0f,CarType::A1,obj2[0]);
// }

std::function<void(carContainer &, EngineContainer &)> CreateObject([](carContainer &obj, EngineContainer &obj2)
                                                                    {

obj2[0]=std::make_shared<Engine>(101,EngineType::E1);
obj[0]=std::make_shared<Car>(101,"ABC",80000.0f,CarType::A1,obj2[0]);

obj2[1]=std::make_shared<Engine>(99,EngineType::E2);
obj[1]=std::make_shared<Car>(102,"ABC",840000.0f,CarType::A2,obj2[1]);

obj2[2]=std::make_shared<Engine>(98,EngineType::E3);
obj[2]=std::make_shared<Car>(103,"XYZ",890000.0f,CarType::A3,obj2[2]); });

std::function<float(carContainer &)> AveragePrice([](carContainer &data)
                                                        {

float total=0.0f;

for(carPointer& ptr:data)
{
    total+=ptr.get()->carPrice();
}
return total/data.size(); });

std::function<float(carContainer &)> HighestPrice([](carContainer &data)
                                                        {

   float highest=data[0].get()->carPrice();

for(carPointer& ptr:data)
{
    if(ptr->carPrice()>highest)
    {
        highest=ptr->carPrice();
    }
}
return highest; });


