#include<iostream>
#include"Functionalities.h"
int main()
{
    carContainer obj;
    EngineContainer obj2;
    CreateObject(obj,obj2);
    for(carPointer& ptr:obj)
    {
        std::cout<<*ptr.get()<<std::endl;
    }
    std::cout<<"Average is : "<<AveragePrice(obj)<<std::endl;
    std::cout<<"Highest is : "<<HighestPrice(obj)<<std::endl;
    return 0;
}