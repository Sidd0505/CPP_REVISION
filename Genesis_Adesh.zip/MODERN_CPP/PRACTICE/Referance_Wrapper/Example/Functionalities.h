#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<vector>
#include<memory>
#include"Car.h"
#include<iostream>
#include<functional>
// using Pointer=std::shared_ptr<Car>;
// using Container=std::vector<Pointer>;


using carPointer=std::shared_ptr<Car>;
using carContainer=std::array<carPointer,3>;

using EnginePointer=std::shared_ptr<Engine>;
using EngineContainer=std::array<EnginePointer,3>;

// void CreateObject(carContainer& obj,EngineContainer& obj2);
extern std::function<void(carContainer&,EngineContainer&)> CreateObject;
extern std::function<float(carContainer&)> AveragePrice;
extern std::function<float(carContainer&)> HighestPrice;
#endif // FUNCTIONALITIES_H
