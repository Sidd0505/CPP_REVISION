#ifndef CAR_H
#define CAR_H

#include<string>
#include <ostream>
#include"Engine.h"
#include"CarType.h"
#include<memory>
#include<vector>

using Pointer=std::shared_ptr<Engine>;
using RefType=std::reference_wrapper<Pointer>;

class Car
{
private:

    int _carId;
    std::string _carName;
    float _carPrice;
    CarType _carType;

    RefType _engine;
public:


    Car(int carId,std::string carName,float carPrice, CarType type,RefType engine);

    Car() = default;

    Car(Car &) = delete;

    Car &operator=(const Car &) = delete;

    Car(Car &&) = delete;

    Car &operator=(const Car &&) = delete;

    ~Car() = default;

    int carId() const { return _carId; }

    std::string carName() const { return _carName; }

    float carPrice() const { return _carPrice; }

    CarType carType() const { return _carType; }

    RefType engine() const { return _engine; }

    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);
};

#endif // CAR_H
