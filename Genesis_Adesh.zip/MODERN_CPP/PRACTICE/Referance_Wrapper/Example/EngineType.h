#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType
{
    E1,E2,E3
};

#endif // ENGINETYPE_H
