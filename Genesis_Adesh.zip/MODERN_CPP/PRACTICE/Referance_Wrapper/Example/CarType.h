#ifndef CARTYPE_H
#define CARTYPE_H

enum class CarType
{
    A1,A2,A3
};

#endif // CARTYPE_H
