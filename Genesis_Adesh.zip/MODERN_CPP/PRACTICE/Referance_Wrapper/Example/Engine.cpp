#include "Engine.h"

Engine::Engine(int horsepower, EngineType type):horsepower(horsepower),_type(type)
{
}
std::ostream &operator<<(std::ostream &os, const Engine &rhs) {
    os << "horsepower: " << rhs.horsepower
       << " _type: " <<static_cast<int>(rhs._type);
    return os;
}
