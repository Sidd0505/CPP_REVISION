#include <iostream>
#include "Functionalities.h"
#include<thread>
#include<future>
#include<algorithm>
#include<numeric>

int main()
{
    Container data;
    // std::thread t1(&CreateObject,std::ref(data));
    CreateObject(data);

    for (auto &[k, v] : data)
    {
        std::cout<<k;
        std::visit([](auto&& val){std::cout<<*val;},v);
        std::cout<<"\n";
    }

    float total2 = std::accumulate(data.begin(), data.end(), 0, [](float sum_till_current_val, const std::pair<int, VType> &row)
                                   { return sum_till_current_val + std::visit([](auto& val){return val->price();},row.second) ;});
    std::cout << "Total price is : " << total2 << std::endl;

    auto result1=std::min_element(data.begin(),data.end(),[](const std::pair<int, VType> &row1,const std::pair<int, VType> &row2){

        return  std::visit([](const auto& val){return val->price();},row1.second)<
                std::visit([](const auto& val){return val->price();},row2.second);
    });

    auto result3=std::count_if(data.begin(),data.end(),[](const std::pair<int, VType> &row){
        return std::visit([](const auto& val){return val->type()==VehicleType::HATCHBACK;},row.second);
    });

    std::cout<<"count :"<<result3;

    // t1.join();
    // try
    // {   
    //     std::future<float> result1=std::async(std::launch::async,AveragePrice,std::ref(data));
    //     std::cout << "Average is : " << result1.get() << std::endl;
    // }
    // catch (const std::string *msg)
    // {
    //     std::cerr << msg << '\n';
    // }

    // /* ------------------------------------------------- */
    // try
    // {
    //     std::string id="C101";
    //     std::future<bool> result2=std::async(std::launch::async,IfIdExists,std::ref(data),std::ref(id));
    //     std::cout << "Id check status : " << IfIdExists(data, "C101") << std::endl;
    // }
    // catch (const std::string *msg)
    // {
    //     std::cerr << msg << '\n';
    // }

    // /* -------------------------------------------------- */
    // try
    // {
    //     VType result = MinimumPriceInstance(data);
    //     std::visit([](auto &&val)
    //                { std::cout << *val << std::endl; },
    //                result);
    // }
    // catch (const std::string *msg)
    // {
    //     std::cerr << msg << '\n';
    // }

    // /* -------------------------------------------------- */
    // try
    // {   
    //     std::cout<<"------Instances------"<<std::endl;
    //     std::optional<std::list<VType>> result = InstancesMatchingType(data, VehicleType::HATCHBACK);
        
    //     for(const VType v:result.value())
    //     {
    //          std::visit([](auto &&val)
    //                { std::cout << *val << std::endl; },
    //                v);
    //     }
    // }
    // catch (const std::string *msg)
    // {
    //     std::cerr << msg << '\n';
    // }

    return 0;
}