#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<memory>
#include<vector>
#include"Rectangle.h"
#include"Square.h"
#include<variant>

using RectanglePointer=std::shared_ptr<Rectangle>;
using SquarePointer=std::shared_ptr<Square>;
using v=std::variant<RectanglePointer,SquarePointer>;

void Create();

#endif // FUNCTIONALITIES_H
