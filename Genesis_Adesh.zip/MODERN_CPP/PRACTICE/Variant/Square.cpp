#include "Square.h"

Square::Square(int _side):side(_side)
{
}

void Square::Area()
{
    std::cout<<"Area of Square is : "<<side*side;
}
