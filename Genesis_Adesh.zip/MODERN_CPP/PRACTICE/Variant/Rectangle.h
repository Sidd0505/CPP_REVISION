#ifndef RECTANGLE_H
#define RECTANGLE_H
#include<iostream>
class Rectangle
{
private:
    int length;
    int width;
public:
    Rectangle(int _length,int _width);
    Rectangle()=default;
    Rectangle(const Rectangle&)=delete;
    Rectangle(Rectangle&&)=delete;
    Rectangle& operator=(const Rectangle&)=delete;
    Rectangle& operator=(Rectangle&&)=delete;
    ~Rectangle()=default; 

    void Area();

};

#endif // RECTANGLE_H
