// Online C++ compiler to run C++ program online
#include <iostream>
#include <memory>
#include <variant>
int main() {
    
    std::cout << "Hello world!";
    std::unique_ptr<int> uptr1=std::make_unique<int>(10);
    std::unique_ptr<std::string> uptr2=std::make_unique<std::string>("Adesh");
    
    std::shared_ptr<int> sptr1=std::make_shared<int>(10);
    std::shared_ptr<std::string> sptr2=std::make_shared<std::string>("Adesh");
    
    std::variant<std::unique_ptr<int>,std::unique_ptr<std::string>> v1=std::make_unique<int>(10);
    
    std::variant<std::unique_ptr<int>,std::unique_ptr<std::string>> v4(std::move(v1));
    
    
    
    
    
    std::variant<std::shared_ptr<int>,std::shared_ptr<std::string>> v2=sptr2;
    
    std::variant<std::shared_ptr<int>,std::shared_ptr<std::string>> v3(std::move(v2));
    
   
    return 0;
}