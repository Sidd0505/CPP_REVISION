#ifndef SQUARE_H
#define SQUARE_H

#include<iostream>

class Square
{
private:
    int side;
public:
    Square(int _side);
    Square()=default;
    Square(const Square&)=delete;
    Square(Square&&)=delete;
    Square& operator=(const Square&)=delete;
    Square& operator=(Square&&)=delete;
    ~Square()=default; 

    void Area();

};

#endif // SQUARE_H
