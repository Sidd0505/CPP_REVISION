#include "Rectangle.h"

Rectangle::Rectangle(int _length, int _width):length(_length),width(_width)
{
}

void Rectangle::Area()
{
    std::cout<<"Area of rectangle is : "<<length*width;
}
