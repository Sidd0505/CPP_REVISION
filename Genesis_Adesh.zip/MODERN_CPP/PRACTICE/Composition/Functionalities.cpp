#include "Functionalities.h"

// std::function<void(container& data)> Create_Objects([](container& data){

//   std::shared_ptr<DebitCard> db1= std::make_shared<DebitCard>(102, "Aniket Wable", "12/24", Debit_Card_Type::DOMESTIC);
//   data.emplace_back(std::make_shared<Customer>(102, "Aniket", 22, Customer_Type::REGULAR,
//            std::ref(db1)));

//             //   data.emplace_back(std::make_shared<Customer>(101, "Adesh", 22, Customer_Type::REGULAR, 
//             // std::make_shared<DebitCard>(102, "Adesh Narke", "12/24", Debit_Card_Type::DOMESTIC)));
// });

// void Create_Objects(container &data)
// {

//    data.emplace_back(std::make_shared<Customer>(102, "Aniket", 22, Customer_Type::REGULAR, 
//             std::make_shared<DebitCard>(102, "Aniket Wable", "12/24", Debit_Card_Type::DOMESTIC)));
// }

void CreateObject(container &data)
{
    db1= std::make_shared<DebitCard>(102, "Aniket Wable", "12/24", Debit_Card_Type::DOMESTIC);
  data.emplace_back(std::make_shared<Customer>(102, "Aniket", 22, Customer_Type::REGULAR,
           db1));

}

void Diaplay_Details(container &data)
{
   int size = data.size();
   for (int i = 0; i < size; i++)
   {
      std::cout << *data[i].get() << std::endl;
   }
}
