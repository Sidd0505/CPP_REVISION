#include "Customer.h"

std::ostream &operator<<(std::ostream &os, const Customer &rhs)
{
    os << "_customer_id: " << rhs._customer_id << "\n"
       << "_customer_name: " << rhs._customer_name << "\n"
       << "_customer_age: " << rhs._customer_age << "\n";
    switch (static_cast<int>(rhs.type))
    {
    case 1:
        os << "type: REGULAR "
           << "\n";
        break;
    case 2:
        os << "type: ELITE "
           << "\n";
        break;
    }

    os << "card : " << *rhs._card.get() << "\n";
    return os;
}

Customer::Customer(int customer_id, std::string customer_name, int customer_age, Customer_Type _type, std::reference_wrapper<std::shared_ptr<DebitCard>> _card)
    : _customer_id(customer_id), _customer_name(customer_name), _customer_age(customer_age), type(_type), _card(_card)
{
}

Customer::Customer(int customer_id, std::string customer_name, Customer_Type type, std::reference_wrapper<std::shared_ptr<DebitCard>> _card)
    : _customer_id(customer_id), _customer_name(customer_name), type(type), _card(_card)
{
}

