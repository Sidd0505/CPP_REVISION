#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<vector>
#include<memory>
#include<functional>
#include"Customer.h"

using pointer=std::shared_ptr<Customer>;
using reference=std::reference_wrapper<pointer>;
using container=std::vector<pointer>;


// extern std::function<void(container& data)> Create_Objects;

void CreateObject(container& obj);
void Diaplay_Details(container& data);
#endif // FUNCTIONALITIES_H
