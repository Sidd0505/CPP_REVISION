#include<iostream>
#include"Functionalities.h"
#include"Customer.h"
int main()
{
    container obj;
    CreateObject(obj);
    Diaplay_Details(obj);
    return 0;
}