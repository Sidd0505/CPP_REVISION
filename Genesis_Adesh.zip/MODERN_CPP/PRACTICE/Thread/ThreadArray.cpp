#include<iostream>
#include<thread>
#include<vector>

void AThread(int val)
{
    std::cout<<"Current Thread is :"<<std::this_thread::get_id();
    std::cout<<val<<std::endl;
}

int  main()
{
    std::vector<std::thread> ThreadArray;
    for(int i=0;i<10;i++)
    {
        ThreadArray.push_back(std::thread(&AThread,100)); 
    }

    for(std::thread &t:ThreadArray)
    {
        if(t.joinable())
        {
            t.join();
        }
    }
    
    return 0;
}