#include <iostream>
#include <vector>
#include <mutex>
#include <condition_variable>
#include <thread>
#include <future>

std::condition_variable cv;
std::mutex mt1, mt2, mt3;
bool nofity = false;
int input;
int number1;
int number2;

void cube(int n)
{
    std::cout << "Cube is : " << n * n * n << std::endl;
}

void square()
{
    std::unique_lock lock(mt1);
    cv.wait(lock, []
            { return nofity; });
    std::cout << "Square is : " << input * input << std::endl;
}

int addition()
{
    std::unique_lock lock1(mt2);
    cv.wait(lock1, []
            { return nofity; });

    return number1 + number2;
}

int main()
{
    std::thread t1(square);
    std::thread t2(cube, 10);

    std::future<int> result = std::async(std::launch::async, addition);

    std::unique_lock lock(mt1);
    std::cout << "Enter input : " << std::endl;
    std::cin >> input;
    nofity = true;
    lock.unlock();
    cv.notify_one();

    std::unique_lock lock1(mt2);
    std::cout << "Enter Number1 : " << std::endl;
    std::cin >> number1;

    std::cout << "Enter Number2 : " << std::endl;
    std::cin >> number2;

    nofity = true;
    lock1.unlock();
    cv.notify_one();
    std::cout << "Addition is :" << result.get() << std::endl;
    t1.join();
    t2.join();

    return 0;
}