#include <iostream>
#include <thread>
#include <condition_variable>
#include <mutex>

int number1;
int number2;


std::mutex mt;
std::condition_variable cv;
bool notify = false;
void addition(int num1,int num2)
{

    std::unique_lock<std::mutex> lock(mt);

    cv.wait(lock, []()
            { return notify; });

    std::cout << "Addition is : " << number1 + number2 << std::endl;
    std::cout << "Addition2 is : " << num1 + num2 << std::endl;
}
void substraction()
{
    std::unique_lock<std::mutex> lock(mt);
    cv.wait(lock, []()
            { return notify; });
    std::cout << "Substraction is : " << number1 - number2 << std::endl;
}

void multiplication()
{
    std::unique_lock<std::mutex> lock(mt);
    cv.wait(lock, []()
            { return notify; });
    std::cout << "Multiplication is : " << number1 * number2 << std::endl;
}

int main()
{
    
    std::thread t1(addition,std::ref(number1),std::ref(number2));
    std::thread t2(substraction);
    std::thread t3(multiplication);

    std::unique_lock<std::mutex> lock(mt);
    std::cout << "Enter number1 : " << std::endl;
    std::cin >> number1;

    std::cout << "Enter number2 : " << std::endl;
    std::cin >> number2;
    notify = true;
    lock.unlock();

    cv.notify_all();

    t1.join();
    t2.join();
    t3.join();
    return 0;
}