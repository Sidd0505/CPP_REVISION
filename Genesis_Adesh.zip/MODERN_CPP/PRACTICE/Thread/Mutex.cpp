#include<iostream>
#include<thread>

#include<mutex>
int Amount=1000;
std::mutex mt;

void Withdraw()
{
    std::lock_guard lock(mt);
    // mt.lock();
    Amount-=10;
    // mt.unlock();
}

void Deposit()
{
    // mt.lock();
    std::lock_guard lock(mt);
    Amount-=10;
    // mt.unlock();
}

int main()
{
    std::thread t1(Withdraw);
    std::thread t2(Deposit);

    t1.join();
    t2.join();

    std::cout<<Amount<<std::endl;
}