#include <iostream>
#include <vector>
#include <mutex>
#include <condition_variable>
#include <thread>

std::condition_variable cv;
std::mutex mt;
int balance = 0;

void Withdraw(int money)
{
    std::cout << "Withdraw started : " << std::endl;
    std::cout << "Wating for condition become true : " << std::endl;
    std::unique_lock lock(mt);

    cv.wait(lock, []()
            { return (balance != 0) ? true : false; });
    std::cout << "condition is true : " << std::endl;
    if (balance < money)
    {
        std::cout << "Avilable Balance is less :" << std::endl;
    }
    else
    {
        std::cout << "Transaction Sucessfull : " << std::endl;
        balance -= money;
        std::cout << "Available Amount :" << balance << std::endl;
    }
}

void Deposit()
{
    std::cout << "Deposit started : " << std::endl;
    std::lock_guard lock(mt);
    balance += 100;
    std::cout << "Notify to withdraw " << std::endl;
    cv.notify_one();
}

int main()
{
    std::vector<std::thread> ThreadArray;
    ThreadArray.emplace_back(std::thread(Withdraw, 200));
    ThreadArray.emplace_back(std::thread(Deposit));

    for (std::thread &t : ThreadArray)
    {
        if (t.joinable())
        {
            t.join();
        }
    }

    return 0;
}