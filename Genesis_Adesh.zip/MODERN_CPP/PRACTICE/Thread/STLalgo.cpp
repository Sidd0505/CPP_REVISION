#include<iostream>
#include<algorithm>
#include<list>
#include<numeric>
#include<vector>

int main()
{
    std::vector<int> lis{1,2,3,4,5,1};

    auto result=std::accumulate(lis.begin(),lis.end(),0);
    std::cout<<"Addition is : "<<result<<std::endl;

    auto result1=std::max_element(lis.begin(),lis.end());
    std::cout<<"Maximum is : "<<*result1<<std::endl;

    auto result2=std::min_element (lis.begin(),lis.end());
    std::cout<<"Minimum is : "<<*result2<<std::endl;

    auto result3=std::count(lis.begin(),lis.end(),1);
    std::cout<<"Count is : "<<result3<<std::endl;

    auto result4=std::count_if(lis.begin(),lis.end(),[](int i){return i%2==0;});
    std::cout<<"Count if is : "<<result4<<std::endl;

    auto Result5=std::find(lis.begin(),lis.end(),4);
    std::cout<<"find : "<<*Result5<<std::endl;

    auto Result6=std::find_if(lis.begin(),lis.end(),[](int val){return val%2==1;});
    std::cout<<"find if : "<<*Result6<<std::endl;

    
    std::sort(lis.begin(),lis.end());
    std::sort(lis.begin(),lis.end(),std::greater<int>());
    std::reverse(lis.begin(),lis.end());
    for(const auto& val:lis)
    {
        std::cout<<val<<" ";
    }


    return 0;
}


/* 

auto result =std::accumulate(data.begin(),data.end(),0,[](auto total,const auto& s(s is a variant stored in container)){
       return total+std::visit([](const auto& val){return val->price();},s);
    });

<---------------------------------------------------------------------------------->

auto result1=std::min_element(data.begin(),data.end(),[](const auto& var1,const auto& var2){

        return  std::visit([](const auto& val){return val->price();},var1)<
                std::visit([](const auto& val){return val->price();},var2);
    });

    std::cout<<std::visit([](const auto& val){return val->price();},*result1)<<" minimin stl"<<std::endl;

<---------------------------------------------------------------------------------->

auto result1=std::find_if(data.begin(),data.end(),[&](const auto& var1){

        return  std::visit([&](const auto& val){return val->id()=="C101";},var1);
    });


    std::cout<<std::visit([](const auto& val){return val->price();},*result1)<<" minimin stl"<<std::endl;

<---------------------------------------------------------------------------------->

  auto result1=std::count_if(data.begin(),data.end(),[&](const auto& var1){

        return  std::visit([&](const auto& val){return val->type()==VehicleType::HATCHBACK;},var1);
    });

    std::cout<<"count "<<result1<<std::endl;

<---------------------------------------------------------------------------------->

     using Container=std::unordered_map<int,VType>;
    data.emplace(std::make_pair(1,std::make_shared<Car>("C101", 700000.0f, VehicleType::HATCHBACK)));

        float total2 = std::accumulate(data.begin(), data.end(), 0, [](float sum_till_current_val, const std::pair<int, VType> &row)
                                   { return sum_till_current_val + std::visit([](auto& val){return val->price();},row.second) ;});
    std::cout << "Total price is : " << total2 << std::endl;



    auto result1=std::min_element(data.begin(),data.end(),[](const std::pair<int, VType> &row1,const std::pair<int, VType> &row2){

        return  std::visit([](const auto& val){return val->price();},row1.second)<
                std::visit([](const auto& val){return val->price();},row2.second);
    });

    std::cout<<"Mimimum price is :"<<std::visit([](auto&& val){return val->price();},result1->second);
<------------------------------------------------------------>
    // std::optional std::nullopt .value()

*/