#include<iostream>
#include<optional>
#include<set>

std::set<int> data{1,1,3,5,7,7};

std::optional<std::set<int>> UniqueEvenNumbers()
{
    std::set<int> result;
    for(int val:data)
    {
        if(val%2==0)
        {
            result.emplace(val);
        }
    }
    // if(result.empty())
    // {
    //     return std::nullopt;
    // }
    return result;
}

int main()
{
    std::optional<std::set<int>> result=UniqueEvenNumbers();
    for(int val:result.value())
    {
        std::cout<<val<<" ";
    }
    return 0;
}

