#include <iostream>
#include <thread>
#include <array>
#include <mutex>
#include <condition_variable>
#include<future>

int number;
bool notify = false;
std::mutex mt;
std::condition_variable cv;
void f1()
{
    std::cout << "f1" << std::endl;
}

void f2()
{
    std::cout << "f2" << std::endl;
}

void f3()
{
    std::cout << "f3" << std::endl;
}

int f4(std::future<int>& a,std::future<int>& b)
{
    return a.get()+b.get();
}
void f5()
{
    std::cout << "f5" << std::endl;
}

int main()
{
    int a,b;

    std::array<std::thread, 5> ThreadArray;

    std::promise<int> pr1;
    std::promise<int> pr2;

    std::future<int> f1=pr1.get_future();
    std::future<int> f2=pr2.get_future();

    ThreadArray[0] = std::thread(f1);
    ThreadArray[1] = std::thread(f2);
    ThreadArray[2] = std::thread(f3);
    ThreadArray[3] = std::thread(f5);

    std::future<int> result = std::async(std::launch::async,&f4,std::ref(f1),std::ref(f2));
    
    std::cout << "Enter a" << std::endl;
    std::cin >> a;
    std::cout << "Enter b" << std::endl;
    std::cin >> b;
    
    pr1.set_value(a);
    pr2.set_value(b);

    for (std::thread &t : ThreadArray)
    {
        if (t.joinable())
        {
            t.join();
        }
    }
}