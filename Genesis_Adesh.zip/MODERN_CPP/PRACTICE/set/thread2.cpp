#include<iostream>
#include<future>

int square(std::future<int>& ft1,std::future<int>& ft2)
{
    int number1=ft1.get();
    int number2=ft2.get();
    return ft1.get()*ft2.get();
}
int factorial(int a)
{
    if(a<=1)
    {
        return 1;
    }
    else
    {
        return a*factorial(a-1);
    }   
}

int main()
{
    // step 1: make a promise
    std::promise<int> pr1;
    std::promise<int> pr2;

    //step 2: step 2: A future linked to the promise
    std::future<int> ft1=pr1.get_future();
    std::future<int> ft2=pr2.get_future();

    std::future<int> result_ft=std::async(std::launch::async,&square,std::ref(ft1),std::ref(ft2));

    std::cout<<factorial(5);
    int val1=0,val2=0;
    std::cout<<"Enter number1";
    std::cin>>val1;
    std::cout<<"Enter number1";
    std::cin>>val2;
    pr1.set_value(val1);
    pr2.set_value(val2);
    std::cout<<"Result of Square is : "<<result_ft.get();


    return 0;
}


/* 
    client-server architecture
    future-promise model
    square calculation
    Main needs to delegate the task of square calculation

*/