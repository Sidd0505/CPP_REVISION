// #include<iostream>

// template<typename T>
// typename remove_reference<T>::type&&

// void move(T&& param)
// {
//     using ReturnType=typename remove_referance<T>::type&&;
// }