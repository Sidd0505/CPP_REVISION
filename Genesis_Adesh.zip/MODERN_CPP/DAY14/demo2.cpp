#include<iostream>
#include<vector>
#include<optional>

void TakeInput(std::vector<int>& data,int n)
{
    int val=-1;
    for(int i=0;i<data.size();i++)
    {
        std::cin>>val;
        data[i]=val;
    }
}
/* 
identify even numbers from data. store all of them in result
return result

scenario 1: there is at least 1 even number in data.
            you identify the numbers. store in result

scenario 2: data is empty. handle by raising exception

scenario 3: data is not empty. However, all numbers are ODD
*/
std::optional<std::vector<int>> ReturnEvenNumbers(std::vector<int>& data)
{
    std::vector<int> evenNum;
    for(int val:data)
    {
        if(val%2==0)
        {
            evenNum.push_back(val);
        }
    }
    if(evenNum.empty())
    {
        return std::nullopt; //nullopt is a symbol to indicate no value
    }
    return evenNum;
}

int main()
{
    int n=-1;
    std::cin>>n;
    std::vector<int>v1(n);//space for N integer is now reserved on the heap
    TakeInput(v1,n);
    std::optional<std::vector<int>> even_result=ReturnEvenNumbers(v1);
    if(even_result.has_value())
    {
        std::cout<<even_result.value().size();
    }
    else
    {
        std::cout<<"Vector returned no values\n"<<std::endl;
    }
    return 0;
}