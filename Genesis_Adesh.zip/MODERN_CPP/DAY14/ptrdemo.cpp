#include <iostream>
#include <thread>

void square1(int a)
{
    std::this_thread::sleep_for(std::chrono::seconds(3));
    std::cout << "square1 : " << a * a << "\n";
}
void square2(int a)
{
    std::cout << "square2 : " << a * a << "\n";
}
void square3(int a)
{
    std::cout << "square3 : " << a * a << "\n";
}
void square4(int a)
{
    std::cout << "square4 : " << a * a << "\n";
}
void square5(int a)
{
    std::cout << "square5 : " << a * a << "\n";
}
void square6(int a)
{
    std::cout << "square6 : " << a * a << "\n";
}
int main()
{
    std::cout << "Thread t1 start " << std::endl;
    std::thread t1(&square1, 10);
    
    std::cout << "Thread t1 end " << std::endl;

    std::cout << "Thread t2 start " << std::endl;
    std::thread t2(&square2, 9);
    
    std::cout << "Thread t2 end " << std::endl;

    std::cout << "Thread t3 start " << std::endl;
    std::thread t3(&square3, 8);
    
    std::cout << "Thread t3 end " << std::endl;

    t2.join();
    std::cout << "Thread t4 start " << std::endl;
    std::thread t4(&square4, 10);
    
    std::cout << "Thread t4 end " << std::endl;
 
    t3.join();
    std::cout << "Thread t5 start " << std::endl;
    std::thread t5(&square5, 10);
    
    std::cout << "Thread t5 end " << std::endl;

    t4.join();
    std::cout << "Thread t6 start " << std::endl;
    std::thread t6(&square6, 10);
    
    t5.join();
    std::cout << "Thread t6 end " << std::endl;
   
    t6.join();
    return 0;
}