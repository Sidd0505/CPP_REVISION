#include"Employee.h"
#include"BusinessOwner.h"
#include<variant>
#include<memory>

int main()
{
   
    std::variant<Employee,BusinessOwner> v1,v2;
    v1=Employee();
    
    

    /*
        visit needs at least 2 parameters

        first : Lambda function that explains what to do with item inside the variant
        second (and subsequent parameters) : objects of variant class. (object/s) on which visit
        lambda has to be applied 
    */
   int a=5;
    std::visit([](Employee&& val)mutable{val.PayTax();},v1);
    v2=BusinessOwner();
    
    std::visit([](auto&& val){val.PayTax();},v2);
    
    // std::shared_ptr<Employee> e1=std::make_shared<Employee>();
    // std::variant<std::shared_ptr<Employee>,std::shared_ptr<BusinessOwner>> v2;

    // std::visit([](auto&& val){val->PayTax();},v2);
    
    return 0;
}
