#ifndef BUSINESSOWNER_H
#define BUSINESSOWNER_H

#include<iostream>

class BusinessOwner
{
private:
    
public:
    BusinessOwner(/* args */) {}
    ~BusinessOwner() {}

    void PayTax()
    {
        std::cout<<"Business has to pay advance tax and GST based every month/quarter\n";
    }

    void print()
    {
        std::cout<<"ss"<<std::endl;
    }
};


#endif // BUSINESSOWNER_H
