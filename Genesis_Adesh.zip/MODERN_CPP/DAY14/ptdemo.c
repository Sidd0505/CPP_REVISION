#include<stdio.h>


int main()
{
    int a=10;
    int *ptr=&a;
    
    return 0;
}