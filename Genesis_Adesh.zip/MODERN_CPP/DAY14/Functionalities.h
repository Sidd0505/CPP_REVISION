#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<vector>
#include<memory>
#include<variant>

#include"Employee.h"
#include"BusinessOwner.h"

using EmpPointer=std::shared_ptr<Employee>;
using BusinessPointer=std::shared_ptr<BusinessOwner>;
using VType=std::variant<EmpPointer,BusinessPointer>;
using Container=std::vector<VType>;

void CreateObject(Container& data);

#endif // FUNCTIONALITIES_H
