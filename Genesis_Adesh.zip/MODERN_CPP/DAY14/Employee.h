#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include<iostream>

class Employee
{
private:
    
public:
    Employee(/* args */) {}
    ~Employee() {}

    void PayTax()
    {
        std::cout<<"Employee pays TDS based tax very year\n";
    }
};

#endif // EMPLOYEE_H
