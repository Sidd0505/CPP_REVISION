#include "BusinessOwner.h"

BusinessOwner::BusinessOwner(float expense, float revenue, std::string registeredBusinessName, BusinessOwnerType type)
:_expense(expense),_revenue(revenue),_registredBusinessName(registeredBusinessName),_type(type)
{
}
std::ostream &operator<<(std::ostream &os, const BusinessOwner &rhs) {
    os << "_expense: " << rhs._expense
       << " _revenue: " << rhs._revenue
       << " _registredBusinessName: " << rhs._registredBusinessName
       << " _type: " << (int)rhs._type;
    return os;
}
