#include<iostream>
#include<array>

// int main()
// {
//     std::array<int,3> arr{101,7000000,0};
//     /* 
//     AAM ZINDAGI
//     */

//    int id=arr[0];
//    int salary=arr[1];
//    int gender=arr[2];

//    /* 
//    MENTOS ZINDAGI
//     */

//    auto[id,salary,gender]=arr;
//     return 0;
// }

/*
Week 3 topics 

Regular Thread 
Copy_Elision
Variant visit holds_alternatives
mutex
lock gaurd
Async Thread
Unique_ptr
structured_binding

*/