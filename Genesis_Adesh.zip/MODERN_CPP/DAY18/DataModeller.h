#ifndef DATAMODELLER_H
#define DATAMODELLER_H

#include <variant>
#include "Employee.h"
#include "BusinessOwner.h"
#include <memory>
#include <vector>
#include <ostream>

using BusinessPointer = std::unique_ptr<BusinessOwner>;
using EmployeePointer = std::unique_ptr<Employee>;
using Vtype = std::variant<BusinessPointer, EmployeePointer>;

class DataModeller
{
private:
    Vtype _instances;
    std::vector<float> _goodsPrices;

public:
    DataModeller(Vtype& instances,const std::vector<float>& prices);
    void operator()();
    DataModeller() = default;
    DataModeller(const DataModeller &) = delete;
    DataModeller(DataModeller &&) = delete;
    DataModeller &operator=(const DataModeller &) = delete;
    DataModeller &operator=(DataModeller &&) = delete;
    ~DataModeller() = default;

    const Vtype& instances() const { return _instances; }

    std::vector<float> goodsPrices() const { return _goodsPrices; }

    friend std::ostream &operator<<(std::ostream &os, const DataModeller &rhs);
};

#endif // DATAMODELLER_H
