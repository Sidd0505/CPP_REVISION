#ifndef BUSINESSOWNERTYPE_H
#define BUSINESSOWNERTYPE_H

enum class BusinessOwnerType
{
SME,MMC
};

#endif // BUSINESSOWNERTYPE_H
