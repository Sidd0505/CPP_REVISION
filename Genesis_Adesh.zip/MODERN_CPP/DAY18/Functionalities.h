#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H
#include "DataModeller.h"
#include <future>
#include<vector>
using DataPointer=std::unique_ptr<DataModeller>;
using Container=std::vector<DataPointer>;

void CreateObjects(Container& data);

void CalculateTaxPayable(const Container &data);

int ReturnSalary(Container &data,std::future<std::string>& ft);

#endif // FUNCTIONALITIES_H
