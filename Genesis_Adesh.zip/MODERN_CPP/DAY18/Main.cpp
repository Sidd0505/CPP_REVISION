#include<iostream>
#include"Functionalities.h"
#include<future>

int main()
{
    Container data;
    CreateObjects(data);
    CalculateTaxPayable(data);

    std::promise<std::string> pr;
    std::future<std::string> ft = pr.get_future();

    std::future<int> result=std::async(std::launch::async, &ReturnSalary,std::ref(data),std::ref(ft));

    std::string input;
    std::cout << "Enter name : " << std::endl;
    std::cin >> input;
    pr.set_value(input);
    std::cout<<"Salary is : "<<result.get()<<std::endl;

    return 0;
}