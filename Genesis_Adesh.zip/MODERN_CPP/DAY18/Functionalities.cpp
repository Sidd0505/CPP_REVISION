#include "Functionalities.h"
#include<future>
void CreateObjects(Container &data)
{
    Vtype temp = std::make_unique<Employee>(
        "Nishant",
        EmployeeType::REGULAR,
        78000.0f);
        
    data.emplace_back(
        std::make_unique<DataModeller>(
            temp,
            std::vector<float>{19.21f, 20.4f, 24.8f}));
}

void CalculateTaxPayable(const Container &data)
{
    for (const DataPointer &ptr : data)
    {
        const Vtype &val = ptr->instances();

        if (std::holds_alternative<BusinessPointer>(val))
        {
            const BusinessPointer &ptr = std::get<BusinessPointer>(val);
            std::cout << "Tax is : " << (ptr->revenue() - ptr->expense()) * 0.1 << "\n";
        }

        const EmployeePointer &emp = std::get<EmployeePointer>(val);
        if (emp->type() == EmployeeType::REGULAR)
        {
            std::cout << "Tax is : " << emp->salary() * 0.1 << "\n";
        }
        else
        {
            std::cout << "Tax is : " << emp->salary() * 0.2 << "\n";
        }
    }
}

int ReturnSalary(Container &data,std::future<std::string>& ft)
{

    for (const DataPointer &ptr : data)
    {
        const Vtype &val = ptr->instances();
        
         if (std::holds_alternative<EmployeePointer>(val))
        {
            const EmployeePointer &ptr = std::get<EmployeePointer>(val);
            // std::string input=ft.get();
            if(ptr->name()==ft.get())
            {
                return ptr->salary();
            }
            
        }

    }

    return 0;
}

// void CallParenOperator(const Container& data)
// {
//     if(data.empty())
//     {
//         throw std::runtime_error("");
//     }

//     for(const DataPointer& ptr: data)
//     {
//         ptr->operator()();
//     }
// }
