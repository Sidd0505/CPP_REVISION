// /*
// std::decay()
// std::bind()
// std::thread()
// std::async()


// API's

// */

// #include <iostream>
// #include <string>
// #include <curl/curl.h>

// size_t WriteCallback(void *contents, size_t size, size_t nmemb, void *userp)
// {
//     ((std::string *)userp)->append((char *)contents, size * nmemb);
//     return size * nmemb;
// }

// int main()
// {
//     std::string url="https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=USD,JPY,EUR";
//     // CURLcode res;
//     std::string readBuffer; // response data to be stored here

//     auto curl = curl_easy_init(); // initializa curl session object

//     if (curl)
//     {
//         // curl_easy_setopt() used to tell libcurl how to behave

//         curl_easy_setopt(curl, CURLOPT_URL,url.c_str());
//         curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
//         curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
        
//         curl_easy_perform(curl);
//         std::cout << readBuffer << std::endl;
//         curl_easy_cleanup(curl);


//     }
//     return 0;
// }