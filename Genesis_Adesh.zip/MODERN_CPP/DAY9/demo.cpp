#include<iostream>
#include<functional>

// represent state by creating object
//Lambdas are callables like regular function (top-level functions/global functions)
//Lambdas have no name i.e they are anonymous functions 

/* 

WHY?
    They help us to pass, receive, store and utilize logic in the 
    form of an object with proper type system support

    They can be used for specifying a short term, one time or scope based
    logical process to be performed on some data

    CPP lamda have a concept of capture clause which allows them act like closures

    [n1] : capture n1 only by value
    [=]  : capture and use all variables from surrounding function by value

    [&n1] : capture reference by lvalue reference
    [&] :capture all variables from surrounding function by referance 
*/

/* 
lambda can be a
1) Predicate -> bool return lambdas are predicate
2) Binary operation -> takes 2 operands & perform binary operation
3) Comparator -> takes 2 operand and returns bool
 */

auto n1=10;//integer

using FnType=std::function<int(int)>;


int main()
{
    /* 
    lambda can be used as "Closures" 
    */
    auto lfn1=[](int number){return number*number;};
    //std::array<std::function<int>(int),1>{lfn1};
    int n1=10;
    auto lf1=[n1]()mutable{n1=99;std::cout<<n1*n1;};

    auto fn2=[n1](){int data=10;std::cout<<n1*data;};

    std::array<FnType,1>{lfn1};

    int n1=100;
    std::cout<<lfn1(n1)<<std::endl;
    return 0;
}