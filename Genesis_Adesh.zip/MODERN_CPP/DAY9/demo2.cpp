//referance wrapper demo
#include<iostream>
#include<functional>
#include<vector>
void magic(std::reference_wrapper<int> n1)
{
    std::cout<<"Address of n1 " <<&(n1.get())<<"\n";
    //if you are working on referance_wrapper you need to use get() function
    std::vector<std::reference_wrapper<int> >v1{n1};

    std::cout<<v1[0].get()<<std::endl;
    std::cout<<v1[0]<<std::endl;

    int& temp=n1;//temp takes reference of n1(which is already reference)
}
int main()
{
    int n1=10;
    std::cout<<"Address of n1 " <<&n1<<"\n";
    magic(n1);
    // int& ref1=n1;

    /* 
    arr is a array of size 1
    arr can store integer lvalue referance
    */

    //int& arr[1]{ref1}; array of referance is not allowed
    //cannot put referances in to a container

    // int & ref=ref1;//cannot put a referance into another referance 
    // if we tried we end up creating another name for original data
    
    return 0;
}

/* 

1) referance physically don't exist!
    - they have no storage
    - they won't have their own address

2) referances cannot be put in a container

3) Referance of a referance does not work as intended

*/