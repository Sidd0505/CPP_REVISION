/*

a container of 3 functions.
Then fun a loop over the container to execute the functions

DATA
|   |   |
f1  f2  f3
|   |   |
o1  o2  o3

*/
#include<iostream>
#include<functional>
#include<vector>

using FnType=std::function<void(int)>;
using FnContainer=std::vector<FnType>;

/*
accept a blank container
It will add 3 lambdas into the container
*/

void MakeLambdaFunctions(FnContainer& functions)
{
    functions.emplace_back([](int number){std::cout<<number*number<<std::endl;});
    functions.emplace_back([](int number){std::cout<<number*number*number<<std::endl;});
    functions.emplace_back([](int number){std::cout<<number*10<<std::endl;});
}

/*
run a for each loop on the function container
execute each function with given data
*/

void ApplyLogicOnData(FnContainer& functions,int data)
{
    // for each function called "fn" inside container called "functions"
    for(FnType & fn:functions)
    {
        fn(data);
    }
}
int main()
{
FnContainer functions;
MakeLambdaFunctions(functions);
ApplyLogicOnData(functions,5);
}