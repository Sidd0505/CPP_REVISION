#include<iostream>
#include<vector>
#include<functional>

using functions=std::function<void(int)>;
class State
{
private:
    /* data */
    std::vector<int>data;
    std::vector<functions>func;

public:
    State()=default;

    State(State&)=delete;

    State operator=(State&)=delete;

    State(State&&)=delete;

    State& operator=(State&&)=delete;

    ~State()=default;

    State(std::vector<int> data,std::vector<functions>funct);

    void operator()();
};