#include "State.h"


State::State(std::vector<int> data, std::vector<functions> funct)
:data(data),func(funct)
{
    
}

void State::operator()()
{
    
}
