#include<iostream>
#include<functional>
void operation(std::function<void(int)>logic,int data)
{
    logic(data);
}

// void operation(void(*logic)(int),int data)
// {
//     logic(data);
// }
void square(int number)
{
    std::cout<<number*number<<std::endl;
}
void cube(int number)
{
    std::cout<<number*number*number<<std::endl;
}
int factorial(int number)
{
    std::cout<<number-1*number-2*number-3<<std::endl;
    return 0;
}

void percent_10(int number)
{
    std::cout<<(int)(number*0.10f);
}
int main()
{
    // A function pointer which points to a functon
    // Type of ptr is signature of function

    // void(*ptr)(int)=&square;
    // ptr=&cube;

    // int(*ptr)(int)=&factorial;

    operation([](int number)
{
    std::cout<<number*number<<std::endl;
},5);
    operation(cube,5);
    operation(percent_10,5);
    //operation(factorial,5);

    return 0;
}

// a lambda function with nothing in the capture clause is implicitly convertible to a function pointer