#include <iostream>
#include <vector>
#include <functional>

using FunType = std::function<void(int)>;
using FunContainer = std::vector<FunType>;
using dataContainer = std::vector<int>;

class state
{
private:
FunContainer functions;
dataContainer data{10,20,30};
public:
    state() = default;
    state(FunContainer functions,dataContainer data)
    :functions(functions),data(data)
    {
        
    }
    void operator()();
    

    void ApplyLogicOnData(const FunContainer &functions, const dataContainer &data)
    {
        // for each function called "fn" inside container called "functions"
        for (const FunType &fn : functions)
        {
            for (const int n : data)
            {
                fn(n);
            }
        }
    }
    void MakeLambdaFunctions(FunContainer &functions)
    {
        functions.emplace_back([](int number)
                               { std::cout << number * number << std::endl; });
        functions.emplace_back([](int number)
                               { std::cout << number * number * number << std::endl; });
        functions.emplace_back([](int number)
                               { std::cout << number * 10 << std::endl; });
    }
};
int main()
{
    FunContainer functions;
    dataContainer data;
    

    state obj;
    obj.ApplyLogicOnData(functions, data);
    obj.MakeLambdaFunctions(functions);
    state obj2;

    dataContainer data1{40, 50, 60}; 
    obj2.MakeLambdaFunctions(functions);
    obj2.ApplyLogicOnData(functions, data1);
    return 0;
}

void state::operator()()
{
    for (const FunType &fn : functions)
        {
            for (const int n : data)
            {
                fn(n);
            }
        }
}
