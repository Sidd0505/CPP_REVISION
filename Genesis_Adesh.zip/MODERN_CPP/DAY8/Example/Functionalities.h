#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "FunctionProcessor.h"
#include <memory>
#include <vector>

using Pointer = std::shared_ptr<FunctionProcessor>;
using StateContainer = std::vector<Pointer>;

void CreateObjects(StateContainer& stateObjects);

void ExecuteOperation(const StateContainer& stateObjects);

#endif // FUNCTIONALITIES_H
