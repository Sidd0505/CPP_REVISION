// Custom Set

#include<iostream>
#include<set>

template<typename T>
void Display(std::set<T>& data)
{
    for(const T& val:data)
    {
        std::cout<<val<<"\n";
    }
}

struct Employee
{
    int _id;
    float _salary;

    Employee(int id,float salary)
    {
        _id=id;
        _salary=salary;
    }

    bool operator<(const Employee& rhs) const //
    {
        return (_salary < rhs._salary );//|| rhs._salary > _salary || _salary!=rhs._salary);
    }
};


int main()
{
    Employee e1(101,890000.0f), e2(202,780000.0f),e3(203,840000.0f),e4(203,840000.0f);
    std::set<Employee> s1 {e1,e2,e3,e4};
    if(e1<e2)
    {
        std::cout<<"TRUE"<<std::endl;
        
    }
    else
    {
        std::cout<<"FALSE"<<std::endl;
    }
    Display(s1);
    Display<Employee>;
    return 0;
}
    inline std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
        os << "_id: " << rhs._id
           << " _salary: " << rhs._salary;
        return os;
    }

/* 
unordered_map : hash table based data container
map : trees based 
unordered_set : hash table
set : red black tree
multimap : used when multiple values have to be stored with same key attached to them
multiset : same as multi map It gives a sorted storage of elements 

e.g 1,10,11,12,12 multiset={1,7,10,10,1

Data:: EmpId
       101,102,103,104,105 (associated )

        e1              e2          e3          e4          e5
[ 101  | Vaish ] [ 202 | Vai] [103 | Ajay] [104 | jay] [105 | vaishnavy]


option 1: {array} -- fixed size; memeory has to be reserved; size is unchangable, continuous storage
                    size cannot be varied;
                      continuous storage;
                      ele can be accessed via indx
                      constant time add(last), remove, read, update using indx

option 2 "{vector} -- size can be varied;
                      increase the number of ele at any pointe; 
                      continuous storage; if no space available adjacent to current memory the all ele must be shifted
                      adding the elements at the end of the vector , accessing the ele for red, 
                      updtaing can all be performed via indx positions in constant time
                      memory can be reserved in advance in some caess ie.. STL cpp

                
option 3 : {Linked List } -- storage is not continuous(not always atleast);
                        -for each ele to be added , a new node of data is created
                        _since memory is not supposed to be continuous , works well for large number of items
                        -operations have different time complexities (OBVIOUSLY!!)

option 4 : { a) Hash Table with key value pair, only one value per key} -- unordered map
               - hashing based on hash func applied on keys determines buckets(row) to store the value
               -Amortized cost of operation
            b)Hash Table with key value pair, multiple value per key --- unordered multimap
             -one key may be associated with multiple values
             -Amortized cost of operations

option 5 : {std::Set} with a custom camparison logic created via a comparator
        - duplicate will not be allowed 
        - duplication is determined using equivalence princoiple

option 6 : data n stcak based on some type of container (std::stack)
     - only one elements will be available for operation(Lifo)
     -underlying implementation can be decided prior to instantiation of stack
    - NO 



*/
