#include <algorithm>
#include <iostream>
#include <memory>
#include <numeric>
#include <unordered_map>
class Employee
{
public:
    Employee(std::string name, float salary)
    {
        _name = name;
        _salary = salary;
    }
    Employee() = default;
    Employee(Employee &&) = default;
    Employee(const Employee &) = default;
    Employee &operator=(Employee &&) = default;

    float salary() const { return _salary; }

    std::string name() const { return _name; }

private:
    std::string _name;
    float _salary;
};

using Pointer = std::shared_ptr<Employee>;
using Container = std::unordered_map<int, Pointer>;

void CreateObjects(Container &data)
{
    data.emplace(std::make_pair(101, std::make_shared<Employee>("Harshit", 700.0f)));
    data.emplace(std::make_pair(102, std::make_shared<Employee>("Adesh", 800000.0f)));
    data.emplace(std::make_pair(103, std::make_shared<Employee>("AniketWable", 900000.0f)));
}

void TotalSalary(Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("empty");
    }

    long int total = 0;
    for (auto &[k, v] : data)
    {
        total = total + v->salary();
    }

    /*
    for(const std::pair<int,pointer>& ptr:data)
    {
        total=total+ptr.second->salary();
    }
    */

    float total2 = std::accumulate(data.begin(), data.end(), 0, [](float sum_till_current_val, const std::pair<int, Pointer> &row)
                                   { return sum_till_current_val + row.second->salary(); });
    std::cout << "Total salary is : " << total2 << std::endl;
}

void CheckConditionAtLeastOne(const Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("data is empty");
    }

    bool flag = std::any_of(data.begin(), data.end(), [](const std::pair<int, Pointer> &ptr)
                            { return ptr.second->salary() > 80000.0f; });
    std::cout << "Any of : " << flag << "\n";

    bool flag1 = std::all_of(data.begin(), data.end(), [](const std::pair<int, Pointer> &ptr)
                             { return ptr.second->salary() > 80000.0f; });
    std::cout << "All of : " << flag1 << "\n";

    bool flag2 = std::none_of(data.begin(), data.end(), [](const std::pair<int, Pointer> &ptr)
                              { return ptr.second->salary() > 80000.0f; });
    std::cout << "None of : " << flag2 << "\n";
}

std::string findnamebylowestsalary(Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("empty");
    }

    auto itr = std::min_element(data.begin(), data.end(), [&](const std::pair<int, Pointer> &pair1, const std::pair<int, Pointer> &pair2)
                                { return pair1.second->salary() > pair2.second->salary(); });

    return itr->second->name();
}

void CountAbove50000Employee(const Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("data is empty");
    }

    int count = std::count_if(data.begin(), data.end(), [](const std::pair<int, Pointer> &ptr)
                              { return ptr.second->salary() > 80000.0f; });
    std::cout << "count if : " << count << "\n";
}

int countofname(const Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("data is empty");
    }

    int count = std::count_if(data.begin(), data.end(), [](const std::pair<int, Pointer> &ptr)
                              { return ptr.second->name().size() < 7; });
    return count;
}

/*
find the salary for the employee whose ID is received as a parameter (find_if)
*/

int findsalarybyid(Container &data, int ID)
{
    if (data.empty())
    {
        throw std::runtime_error("data is empty");
    }
    auto result = std::find_if(data.begin(), data.end(),

                               [&](const std::pair<int, Pointer> &ptr)
                               {
                                   return ptr.first == ID;
                               });
    if(result==data.end())
    {
        std::cout<<"Id not found"<<std::endl;
    }
    else
    {
        return result->second->salary();
    }
    
}

/*
find the average salary for ONLY THOSE EMPLOYEES WHOSE ID IS PASSED AS A VECTOR OF
INTEGERS TO THE FUNCTION
*/

void findAverage(Container& data,std::vector<int> container)
{
    if (container.empty())
    {
        throw std::runtime_error("data is empty");
    }
    int count=0;
   float total = std::accumulate(data.begin(), data.end(), 0, 

                            [&](float sum_till_current_val, const std::pair<int, Pointer> &row)
                                   { 

                                    for(int val:container)
                                    {
                                        if(val==row.first)
                                        {
                                            count+=1;
                                            return sum_till_current_val + row.second->salary();
                                        }
                                    }

                                    });
    std::cout<< "Average Salary For Given Employess : "<<total/count;
}

void findAverageBetter(Container& data,std::vector<int> container)
{
    float total=0.0f;
    int count=0;
    for(int id :container)
    {
         auto itr=data.find(id);
        if(itr!=data.end())
        {
            count++;
            total=total+itr->second->salary();
        }
    }
   std::cout<<"Average : "<<total/count<<std::endl;
}

int main()
{
    Container data;
    CreateObjects(data);
    TotalSalary(data);
    std::cout << "Lowest salary employee name is : " << findnamebylowestsalary(data) << std::endl;
    CheckConditionAtLeastOne(data);
    CountAbove50000Employee(data);
    std::cout << "Count of employees whose name contains more than 7 characters : " << countofname(data) << "\n";
    std::cout << "Salary of employee whose is given : " << findsalarybyid(data, 101);
    findAverage(data, std::vector<int>{101,102});
    return 0;
}

/*
scenario A : a function, i have input before creating thread I don't want return value

answer : std::thread should be enough

scenario 2 : A function, I have input before creating thread I WANT RETURN VALUE

answer : use std::async without FUTURE_INPUT before creating thread I don,t want return

scenario 3 : a function, I don't have input before creating thread i dont want return
answer : use std::async with future INPUT and future return type (could be )
*/
