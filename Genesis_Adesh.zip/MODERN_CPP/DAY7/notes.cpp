//keywords
// default
// delete
// override
// final
// nullptr
// noexcept
// auto

// concept

// enum class
// rvalue_references // move semantics
// uniform initialization
// Member-list initialization
// COnstructor deligation
// smart pointers -> stared_ptr 
// for each loop


#include<iostream>
#include<list>
#include"Employee.h"

int main()
{
    std::list<Employee> data;
    Employee e1(101);
    data.push_back(e1);
}

/*

Types of common logic building excercies

1) Total or algebric sum operations
    -1) create an initial total variable with initial value as 0
    -2) for each item to be added in the total, do the following
            a) fetch the item
            b) add the item to the sum
            c) update the sum
    -3) return the final sum

2) Find Min Value from a collection
    e.g find lowest (minimum) integer from an array
    1) Create an initial min value WHICH MUST BE EQUAL TO THE FIRST 
       ITEM FROM THE COLLECTION

    2) For each item in the collection, do the following
        a) fetch the item
        b) compare item with "MIN_VALUE" so far
            b1) if current item is larger then min_value, "igonre"
            b2) if current item is smaller, update min_value as "current_item"
    
    3) Finally, the min_value now holds "the global minimum value"

3) Find an attribute associated with the "min" value object
    e.g fiding the car with with the min value object
    1) Create an initial min value WHICH MUST BE EQUAL TO THE FIRST 
       ITEM FROM THE COLLECTION

    2) also save the attribute (of be retured )of the first item

    3) for each object , do the following
        a) compare and check whether current val is lower than min
            a1) if yes, update min, update associated value
            a1) if no, ignore
    4) return the associated value
*/