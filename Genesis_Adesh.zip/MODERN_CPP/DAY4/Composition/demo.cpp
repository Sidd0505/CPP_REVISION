#include<iostream>
#include"Customer.h"
#include"DebitCard.h"
#include<memory>
#include"_Customer_type.h"
#include"DebitCardType.h"

std::shared_ptr<Customer> dummy()
{
    auto ptr=std::make_shared<Customer>(101,"Adesh",27,Customer_Type::ELITE,std::make_shared<DebitCard>(111,"Adesh Narke","12/32",Debit_Card_Type::DOMESTIC));
return ptr;
}

int main()
{
    auto ans=dummy();
    return 0;
}

//increaing life of 
