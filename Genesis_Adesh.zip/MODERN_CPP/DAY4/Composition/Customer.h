#ifndef CUSTOMER_H
#define CUSTOMER_H

#include<iostream>
#include"_Customer_type.h"
#include"DebitCard.h"
#include<memory>
class Customer
{
private:
int _customer_id{0};
std::string _customer_name{""};
int _customer_age{0};
Customer_Type type{Customer_Type::REGULAR};
std::shared_ptr<DebitCard> _card;

public:

Customer(int customer_id,std::string customer_name,int customer_age,Customer_Type type,std::shared_ptr<DebitCard> card);

Customer(int customer_id,std::string customer_name,Customer_Type type,std::shared_ptr<DebitCard> card);

Customer()=delete;

Customer(Customer&)=delete;

Customer &operator=(const Customer&)=delete;

Customer(Customer&&)=delete;

Customer &operator=(const Customer&&)=delete;

~Customer()=default;

int customerId() const { return _customer_id; }

std::string customerName() const { return _customer_name; }

int customerAge() const { return _customer_age; }

Customer_Type getType() const { return type; }

std::shared_ptr<DebitCard> card() const { return _card; }

friend std::ostream &operator<<(std::ostream &os, const Customer &rhs);

};

#endif // CUSTOMER_H
//books efective modern cpp scott mayers 