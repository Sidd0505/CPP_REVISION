#ifndef _CUSTOMER_TYPE_H
#define _CUSTOMER_TYPE_H

#include<iostream>

enum class Customer_Type
{
REGULAR=1,
ELITE
};

#endif // _CUSTOMER_TYPE_H
