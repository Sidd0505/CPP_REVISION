#include<iostream>

int& magic(int& n1)
{
    std::cout<<"Address of data in magic : "<<&n1<<"\n";
    n1=n1*100;
    //int ans=n1*100;
    return n1;
    // do not return local variable // dangling referance

}
int main()
{
    //data variable initialized with value 20
    int data=20;
    //address of data can be determined because data in l value
    std::cout<<"Address of data in main : "<<&data<<"\n";
    //result stores the return "Value" from magic called with "data" passed by value
    int result=magic(data);
    std::cout<<result<<std::endl;
    // calling by referance means alternate name
    return 0;
}