#include<iostream>
#include"Functionalities.h"
#include"Customer.h"
int main()
{
    std::vector<std::shared_ptr<Customer>>obj;
    Create_Objects(obj);
    Diaplay_Details(obj);
    return 0;
}