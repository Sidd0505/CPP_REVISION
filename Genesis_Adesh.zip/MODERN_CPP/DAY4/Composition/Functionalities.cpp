#include "Functionalities.h"

void Create_Objects(container &data)
{
   data.emplace_back(std::make_shared<Customer>(101, "Adesh", 21, Customer_Type::ELITE,
            std::make_shared<DebitCard>(101, "Adesh Narke", "11/31", Debit_Card_Type::DOMESTIC)));

   data.emplace_back(std::make_shared<Customer>(102, "Aniket", 22, Customer_Type::REGULAR, 
            std::make_shared<DebitCard>(102, "Aniket Wable", "12/24", Debit_Card_Type::DOMESTIC)));
}

void Diaplay_Details(container &data)
{
   int size = data.size();
   for (int i = 0; i < size; i++)
   {
      std::cout << *data[i] << std::endl;
   }
}
