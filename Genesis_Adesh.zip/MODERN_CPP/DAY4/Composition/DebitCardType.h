#ifndef DEBITCARDTYPE_H
#define DEBITCARDTYPE_H

#include<iostream>

enum class Debit_Card_Type
{
DOMESTIC=1,
INTERNATIONAL
};

#endif // DEBITCARDTYPE_H
