#include "DebitCard.h"

std::ostream &operator<<(std::ostream &os, const DebitCard &rhs)
{
    os << "\n_cvv: " << rhs._cvv << "\n"
       << "_name: " << rhs._name << "\n"
       << "_expiry_date: " << rhs._expiry_date << "\n";
    switch (static_cast<int>(rhs.type))
    {
    case 1:
        os << "type : DOMESTIC"
           << "\n";
        break;
    case 2:
        os << "type : INTERNATIONAL"
           << "\n";
        break;
    }

    return os;
}

DebitCard::DebitCard(int cvv, std::string name, std::string expiry, Debit_Card_Type type)
    : _cvv(cvv), _name(name), _expiry_date(expiry), type(type)
{
}
