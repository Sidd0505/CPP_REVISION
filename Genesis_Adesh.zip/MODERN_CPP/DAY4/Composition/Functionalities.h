#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<vector>
#include<memory>
#include"Customer.h"

using pointer=std::shared_ptr<Customer>;
using container=std::vector<pointer>;

void Create_Objects(container& data);
void Diaplay_Details(container& data);
#endif // FUNCTIONALITIES_H
