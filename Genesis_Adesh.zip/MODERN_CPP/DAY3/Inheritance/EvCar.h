#ifndef EVCAR_H
#define EVCAR_H

#include "Vehicle.h"
//#include <ostream>

class EvCar : public Vehicle
{
private:
float battery_percentage;
public:

    EvCar(int id, std::string name, float price, VehicleType type,float percentage);
    EvCar(int id, std::string name, VehicleType type,float percentage);

    EvCar() = default;

    EvCar(const EvCar &) = delete;

    EvCar &operator=(const EvCar &) = delete;

    EvCar(EvCar &&) = delete;

    EvCar &operator=(const EvCar &&) = delete;

    ~EvCar() = default;
    // void CalculateRegistrationCharge() override;
    friend std::ostream &operator<<(std::ostream &os, const EvCar &rhs);
        void dummy()
    {
        std::cout<<"car";
    }
};

#endif // EVCAR_H
