#include"DieselCar.h"

std::ostream &operator<<(std::ostream &os, const DieselCar &rhs) {
    os << static_cast<const Vehicle &>(rhs)
       << " fuel_capacity: " << rhs.fuel_capacity;
    return os;
}

DieselCar::DieselCar(int id, std::string name, float price, VehicleType type, int capacity)
:Vehicle(id,name,price,type),fuel_capacity(capacity)
{
}

DieselCar::DieselCar(int id, std::string name, VehicleType type, int capacity)
:Vehicle(id,name,type),fuel_capacity(capacity)
{
}
