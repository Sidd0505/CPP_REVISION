#ifndef PETROL_H
#define PETROL_H
#include "Vehicle.h"
#include <ostream>

class PetrolCar : public Vehicle
{
private:
    int _fuel_tank_capacity;

public:

    PetrolCar(int id, std::string name, float price, VehicleType type, int capacity);
    PetrolCar(int id, std::string name, VehicleType type, int capacity);

    PetrolCar() = default;

    PetrolCar(const PetrolCar &) = delete;

    PetrolCar &operator=(const PetrolCar &) = delete;

    PetrolCar(PetrolCar &&) = delete;

    PetrolCar &operator=(const PetrolCar &&) = delete;

    ~PetrolCar() = default;
    void dummy()
    {
        std::cout<<"car";
    }
    friend std::ostream &operator<<(std::ostream &os, const PetrolCar &rhs);

    // void CalculateRegistrationCharge() override;
};
#endif // PETROL_H
