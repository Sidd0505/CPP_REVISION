#include "Functionalities.h"

void CreateObjects(Container &data)
{
    // step 1: make a constructor call to petrolCar
    // std::make_shared<PetrolCar>(101,"City",14000000.0f,VehicleType::PERSONAL,43);

    // step 2:

    // std::shared_ptr<Vehicle> ptr=std::marke_shared<PetrolCar>(101,"City",14000000.0f,VehicleType::PERSONAL,43);
    data.emplace_back(std::make_shared<PetrolCar>(101, "City", 1400000.0f, VehicleType::PERSONAL, 43));
    data.emplace_back(std::make_shared<PetrolCar>(105, "Honda", 1400000.0f, VehicleType::PERSONAL, 43));
    data.emplace_back(std::make_shared<EvCar>(102, "Thar", 800000.0f, VehicleType::PERSONAL, 50.0f));
    data.emplace_back(std::make_shared<HybridCar>(103, "Swift", 700000.0f, VehicleType::TRANSPORT, 40, 50.0f));
    data.emplace_back(std::make_shared<DieselCar>(104, "BMW", 7000000.0f, VehicleType::TRANSPORT, 40));
}

float AveragePrice(Container& data)
{
    int size=data.size();
    float total{0.0f};
    for (int i = 0; i < size; i++)
    {
        total += data[i]->getPrice();
    }

    return total / size;
}

void display_details(Container& data)
{
    int size=data.size(); 
    try{
        for(int i=0;i<size;i++)
        {
            if(typeid(*(data[i]))==typeid(DieselCar))
            {
                 std::cout<<*(std::dynamic_pointer_cast<DieselCar>(data[i]))<<std::endl;
            }
             if(typeid(*(data[i]))==typeid(PetrolCar))
            {
                 std::cout<<*(std::dynamic_pointer_cast<PetrolCar>(data[i]))<<std::endl;
            }
             if(typeid(*(data[i]))==typeid(HybridCar))
            {
                 std::cout<<*(std::dynamic_pointer_cast<HybridCar>(data[i]))<<std::endl;
            }
             if(typeid(*(data[i]))==typeid(EvCar))
            {
                 std::cout<<*(std::dynamic_pointer_cast<EvCar>(data[i]))<<std::endl;
            }
        }
    }
    catch(const char *msg)
    {
        std::cout<<"Error...!";
    }
    
}
