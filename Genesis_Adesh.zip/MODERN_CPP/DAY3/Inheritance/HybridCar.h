#ifndef HYBRIDCAR_H
#define HYBRIDCAR_H

#include <iostream>
#include "Vehicle.h"

class HybridCar : public Vehicle
{
private:
int fuel_capacity;
float battery_percentage;

public:
    HybridCar(int id, std::string name, float price, VehicleType type, int capacity, float percentage);
    HybridCar(int id, std::string name, VehicleType type, int capacity,float percentage);

    HybridCar() = default;

    HybridCar(const HybridCar &) = delete;

    HybridCar &operator=(const HybridCar &) = delete;

    HybridCar(HybridCar &&) = delete;

    HybridCar &operator=(const HybridCar &&) = delete;

    ~HybridCar() = default;
        void dummy()
    {
        std::cout<<"car";
    }
    friend std::ostream &operator<<(std::ostream &os, const HybridCar &rhs);
    // void CalculateRegistrationCharge() override;
};

#endif // HYBRIDCAR_H
