#include "HybridCar.h"

HybridCar::HybridCar(int id, std::string name, float price, VehicleType type, int capacity, float percentage) 
: Vehicle(id, name, price, type), fuel_capacity(capacity), battery_percentage(percentage)
{
}

HybridCar::HybridCar(int id, std::string name, VehicleType type, int capacity, float percentage)
    : Vehicle(id, name, type), fuel_capacity(capacity), battery_percentage(percentage)
{
}

// void HybridCar::CalculateRegistrationCharge()
// {
// }

std::ostream &operator<<(std::ostream &os, const HybridCar &rhs) {
    os << static_cast<const Vehicle &>(rhs)
       << " fuel_capacity: " << rhs.fuel_capacity
       << " battery_percentage: " << rhs.battery_percentage;
    return os;
}

