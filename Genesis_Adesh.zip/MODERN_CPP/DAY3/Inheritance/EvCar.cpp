#include "EvCar.h"

EvCar::EvCar(int id, std::string name, float price, VehicleType type, float percentage)
    : Vehicle(id, name, price, type), battery_percentage(percentage)
{
}

EvCar::EvCar(int id, std::string name, VehicleType type, float percentage)
    : Vehicle(id, name, type), battery_percentage(percentage)
{
}

// void EvCar::CalculateRegistrationCharge()
// {
//     std::cout<<"Tax on EvCar is 0%"<<std::endl;
// }

std::ostream &operator<<(std::ostream &os, const EvCar &rhs)
{
    os << static_cast<const Vehicle &>(rhs)
       << " battery_percentage: " << rhs.battery_percentage;
    return os;
}


