#ifndef DIESELCAR_H
#define DIESELCAR_H

#include "Vehicle.h"
#include <ostream>

class DieselCar : public Vehicle
{
private:
    int fuel_capacity;

public:
    DieselCar(int id, std::string name, float price, VehicleType type, int capacity);
    DieselCar(int id, std::string name, VehicleType type, int capacity);
    DieselCar() = default;
    DieselCar(const DieselCar &) = delete;
    DieselCar &operator=(const DieselCar &) = delete;
    DieselCar(DieselCar &&) = delete;
    DieselCar &operator=(const DieselCar &&) = delete;

    ~DieselCar() = default;
        void dummy()
    {
        std::cout<<"car";
    }
    friend std::ostream &operator<<(std::ostream &os, const DieselCar &rhs);
};

#endif // DIESELCAR_H
