#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H
#include"Vehicle.h"
#include<memory>
#include<vector>
#include "PetrolCar.h"
#include "EvCar.h"
#include "HybridCar.h"
#include "DieselCar.h"


// Step 1: Create a alias "Pointer" which is as alternate name
// for  std::shared_ptr to Vehicle
 using Pointer=std::shared_ptr<Vehicle>;

// Step 2: now specify alternate Container which indicates
// a standard vector of "Pointer" where Pointer is explained above
 using Container=std::vector<Pointer>;

// void CreateObjects(std::vector<std::shared_ptr<Vehicle>>& data);

void CreateObjects(Container& data);

float AveragePrice(Container& data);

void display_details(Container& data);
#endif // FUNCTIONALITIES_H
