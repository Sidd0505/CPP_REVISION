#include<iostream>
#include"Functionalities.h"
#include<memory>
#include<vector>
int main()
{
    std::vector<std::shared_ptr<Vehicle>> vsp;  //smart pointer
    CreateObjects(vsp);
    //vector<int> *v = new vector<int>(); basic/raw pointer

    float Average = AveragePrice(vsp);
    std::cout << "Average: " << Average << std::endl;

    display_details(vsp);
    //std::cout<<vsp[0];
    return 0;
}