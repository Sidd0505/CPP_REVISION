/*
Has A relationship-> one to one , one to many
association-> types 1) basic association 2) composition 3) aggregation


Is A relationship->
Inheritance-> done for generalization specialization
1)single
2)multiple(don't use)
3)Multilevel
4)Hybrid
5)Hierarchical

*/
/*
uniform initialization syntax


*/

#include <iostream>
#include<vector>
#include<list>
#include<memory>

struct empolyee
{
    int id;
    std::string name;
};

class car
{
private:
    int id;
    std::string name;

public:
    car()
    {
    }
    car(int _id, std::string _name) : id(_id), name(_name)
    {
    }
};
int main()
{
    int n1{20};
    int *ptr{&n1};
    struct employee e1
    {
        101, "Adesh"
    };
    int arr[5]{10,20,30,40,50};

    std::list<int>data{1,2,3};
    std::vector<int>values{1,2,3};
    std::shared_ptr<int>ptr2{1,2,3};
    return 0;
}
