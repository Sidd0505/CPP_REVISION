/*
I am creating a function magic
It needs to accept one integer "data"

scenario 1:
copy and create duplicated data value to preserve original value
inside data and yet perform operations on the copy

scenario 2:
I have "temporary" integer which needs to be passed to magic.
Magic would perform operations like modification on the integer
and return the modified value.

    -pass integer rvalue reference and returns modified data by value
    -pass integer by value and return by value

*/

int magic(int&& data)//pass integer rvalue reference and returns modified data by value
{

}
int main()
{
    magic(10);
}