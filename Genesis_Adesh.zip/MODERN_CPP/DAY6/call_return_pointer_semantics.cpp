#include <iostream>
#include "Employee.h"
void Magic(Employee *emp)
{
    emp->setId(100);
}

int main()
{
    Employee *e1 = new Employee(111);
    Magic(e1);
    delete e1;
}