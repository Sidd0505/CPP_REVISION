/*
Create an array of 5 threads that calculate the square
of ONE NUMBER FROM AN ARRAY OF 5 integers. store address in result container
*/

#include <array>
#include <thread>
#include <iostream>
#include <functional>

void InstantiateThreads(std::array<std::thread, 5> &threadarr,
                        std::function<void(int,int)> f1,
                        std::array<int, 5> data)
{
    auto itr = data.begin();
    for (int i = 0; i < 5; i++)
    {
        threadarr[i] = std::thread(f1, *itr++, i);
    }
}

void JoinThread(std::array<std::thread, 5> &threadArray)
{
    for (std::thread &t : threadArray)
    {
        if (t.joinable())
        {
            t.join();
        }
    }
}

void DisplayResult(std::array<int, 5> result, std::array<int, 5> data)
{
    auto itr = data.begin();
    for (int val : result)
    {
        if (itr != data.end())
        {
            std::cout << "Square of " << *itr << " is " << val << std::endl;
            itr++;
        }
    }
}
void StartApp()
{
    std::array<int, 5> result;
    std::array<int, 5> data{10, 20, 30, 40, 50};
    std::array<std::thread, 5> threadArray;

    int k = 0;

    auto f1 = [&](int number, int index)
    { result[index] = number * number; };

    InstantiateThreads(threadArray, f1, data);
    JoinThread(threadArray);
    DisplayResult(result,data);
}

int main()
{
   StartApp();

    return 0;
}