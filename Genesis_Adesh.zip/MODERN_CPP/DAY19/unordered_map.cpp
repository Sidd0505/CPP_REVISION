#include<iostream>
#include<unordered_map>

int main()
{
    std::unordered_map<int,std::string> umap{
        {101,"Adesh"},
        {102,"Aniket"},
        {103,"Parth"}
        };
    auto search=umap.find(104);
    std::cout<<"Employee with ID : 101 is : "<<search->second<<"\n";


    return 0;
}


/* 
HASH VALUE OR HASH : the answer of a mathematical operation applied on the key

HASH FUNCTION : THIS IS the operation applied e.g MODULUS 5 

HASH TABLE (ILLUSION) : This is the table of contents or a structure where position
                        position of each key is preserved. The key is linked with the 
                        actual value

[101 | Harshit | 6000.0f]
[102 | Adesh   | 8000.0f]
[103 | Aniket  | 9000.0f]
[104 | Parth   | 1000.0f]

step 1 : apply hash function on each key
    a) 101 % 3 = 2
    b) 102 % 3 = 0
    c) 103 % 3 = 1
    d) 104 % 3 = 2

HASH TABLE


row 0 --> [102 | [102 | Adesh | 8000.0f]
row 1 --> [101 | [101 | Harshit | 6000.0f]]
row 2 --> [103 | [103 | Aniket | 9000.0f]] --> [104|104|]

*/