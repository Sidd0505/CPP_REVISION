#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>

int main()
{
    int id=fork();

    if(id==0)  
    {
        printf("This statement is printed in the child\n");
        printf("Process ID: %d and my parent's ID is : %d ",getpid(),getppid());
    }
    else
    {
        printf("This statement is printed in the \n");
        printf("Process ID: %d and my parent's ID is : %d ",getpid(),getppid());
    }
    return 0;
}