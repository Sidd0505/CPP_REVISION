#include<iostream>
class MyClass
{
    private:
    int _id;
    public:
    MyClass()=default;
    MyClass(MyClass &&)=default;
    MyClass(const MyClass&){std::cout<<"Cpoy";}
    MyClass &operator=(MyClass&&)=default;
    MyClass &operator=(MyClass&)=default;
    ~MyClass()=default;
    MyClass(int id):_id(id)
    {

    }
    int id() const { return _id; }
};

MyClass Magic(MyClass& obj)
{
    MyClass temp(obj);
    std::cout<<"Address of temp : "<<&temp<<std::endl;
    return temp;
}

int main()
{
    MyClass obj(100);
    std::cout<<"Address of obj : "<<&obj<<std::endl;
    MyClass return_obj=Magic(obj);
    std::cout<<"Address of return_obj : "<<&return_obj<<std::endl;
}