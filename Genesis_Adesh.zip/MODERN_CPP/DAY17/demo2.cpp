#include<iostream>
#include<future>

int square(std::future<int>& ft1,std::future<int>& ft2)
{
    int number1=ft1.get();
    int number2=ft2.get();
    return number1*number2;
}

void print()
{
    std::cout<<"Execution complete"<<std::endl;
}


int main()
{
    // step 1: make a promise
    std::promise<int> pr1;
    std::promise<int> pr2;

    //step 2: step 2: A future linked to the promise
    std::future<int> ft1=pr1.get_future();
    std::future<int> ft2=pr2.get_future();
   
    std::future<int> result_ft=std::async(std::launch::async,&square,std::ref(ft1),std::ref(ft2));
     std::thread t1(&print);

    int val=0,val2;
    std::cout<<"Enter number";
    std::cin>>val;
    std::cout<<"Enter number";
    std::cin>>val2;
    t1.join();
    pr1.set_value(val);
    pr2.set_value(val2);
    std::cout<<"Result of Square is : "<<result_ft.get();
    
}