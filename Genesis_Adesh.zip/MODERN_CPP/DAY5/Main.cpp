#include<iostream>
#include"Functionalities.h"
#include"Customer.h"
int main()
{
    std::vector<std::shared_ptr<Customer>>obj;
    Create_Objects(obj);
    // Diaplay_Details(obj);
    
    // std::cout<<Average_Age(obj)<<std::endl;
    // std::cout<<Search_By_Age(obj,101);
    // std::cout<<Show_Object(obj,2);
    // std::cout<<Expiry_Date_DebitCard(obj,101)<<std::endl;
    // std::cout<<*Container_Of_Pointers_Age_Above_50(obj)[0];
    //std::cout<<*Debit_Card_Pointer(obj,101);
    try
    {
         std::cout<<CVV_Number_By_Customer_Id(obj,105);
    }
    catch(const std::runtime_error& e)
    {
        std::cerr << e.what() << '\n';
    }
    
   
    return 0;
}