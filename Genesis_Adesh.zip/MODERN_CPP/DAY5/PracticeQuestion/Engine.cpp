#include "Engine.h"

Engine::Engine(std::string _engineNumber, engineType _type, int _engineHorsepower, int _engineTorque)
:engineNumber(_engineNumber),type(_type),engineHorsepower(_engineHorsepower),engineTorque(_engineTorque)
{
}
std::ostream &operator<<(std::ostream &os, const Engine &rhs) {
    os << "engineNumber: " << rhs.engineNumber
       << " type: " << static_cast<int>(rhs.type)
       << " engineHorsepower: " << rhs.engineHorsepower
       << " engineTorque: " << rhs.engineTorque;
    return os;
}
