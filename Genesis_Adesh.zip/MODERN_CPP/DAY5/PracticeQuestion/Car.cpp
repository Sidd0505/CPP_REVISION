#include "Car.h"

Car::Car(std::string _carId, std::string _carBrand, carType _type, float _carPrice, std::shared_ptr<Engine> _carEngine)
:carId(_carId),carBrand(_carBrand),type(_type),carPrince(_carPrice),carEngine(_carEngine)
{
}
std::ostream &operator<<(std::ostream &os, const Car &rhs) {
    os << "carId: " << rhs.carId
       << " carBrand: " << rhs.carBrand
       << " type: " << static_cast<int>(rhs.type)
       << " carEngine: " << *rhs.carEngine
       << " carPrince: " << rhs.carPrince;
    return os;
}
