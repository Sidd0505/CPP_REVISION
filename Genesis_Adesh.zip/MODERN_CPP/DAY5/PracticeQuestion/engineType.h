#ifndef ENGINETYPE_H
#define ENGINETYPE_H

#include<iostream>

enum class engineType
{
    ICT,
    HYBRID
};

#endif // ENGINETYPE_H
