#include<iostream>
#include"Car.h"
#include"Functionalities.h"
int main()
{
    // std::vector<std::shared_ptr<Car>>obj;
    // std::vector<std::shared_ptr<Engine>>eng;
    container obj;
    container2 eng;
    createObject(obj);

    try
    {
        obj=Instances_Of_Car(obj);
        for(int i=0;i<obj.size();i++)
        {
            std::cout<<*obj[i]<<std::endl;
        }
    }
    catch(const std::runtime_error e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        eng=Instances_Of_Engine(obj,carType::HATCHBACK);
        
        for(int i=0;i<eng.size();i++)
        {
            std::cout<<*eng[i]<<std::endl;
        }
    }
    catch(const std::runtime_error e)
    {
        std::cerr << e.what() << '\n';
    }
    
    //std::cout<<eng.size();
    //display_Objects(obj);
    return 0;
}