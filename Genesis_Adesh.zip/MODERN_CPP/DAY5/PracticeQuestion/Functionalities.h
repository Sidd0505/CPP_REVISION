#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include<memory>
#include"Car.h"
#include<vector>

using pointer=std::shared_ptr<Car>;
using container=std::vector<pointer>;

using pointer2=std::shared_ptr<Engine>;
using container2=std::vector<pointer2>;

void createObject(container& data);//done

void display_Objects( container& data);//done

int engineHorsepower( container& data,std::string carid);//done

container Instances_Of_Car( container& data);//done

container2 Instances_Of_Engine( container& data,carType type);//done

float Average_Of_engineHorsepower( container& data);//done

std::string carIdFindofLowestPrice( container& data);//done

float Combine_price(container& data);//Done

#endif // FUNCTIONALITIES_H
