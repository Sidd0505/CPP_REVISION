#ifndef ENGINE_H
#define ENGINE_H

#include<iostream>
#include"engineType.h"
class Engine
{
private:
    std::string engineNumber{""};
    engineType type{engineType::HYBRID};
    int engineHorsepower{0};
    int engineTorque{0};
    
public:


    Engine(std::string _engineNumber,engineType _type,int _engineHorsepower,int _engineTorque);
    Engine(/* args */)=default; 
    ~Engine()=default;

    std::string getEngineNumber() const { return engineNumber; }

    engineType getType() const { return type; }

    int getEngineHorsepower() const { return engineHorsepower; }

    int getEngineTorque() const { return engineTorque; }

    friend std::ostream &operator<<(std::ostream &os, const Engine &rhs);
};

#endif // ENGINE_H
