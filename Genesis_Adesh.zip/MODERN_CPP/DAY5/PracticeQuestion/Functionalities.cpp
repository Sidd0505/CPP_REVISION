#include "Functionalities.h"

void createObject(container &data)
{
    data.emplace_back(std::make_shared<Car>("100A", "BMW", carType::SUV, 8000000.0f, std::make_shared<Engine>("1001", engineType::HYBRID, 9000, 80)));
    data.emplace_back(std::make_shared<Car>("200A", "THAR", carType::HATCHBACK, 1000000.0f, std::make_shared<Engine>("1002", engineType::ICT, 10000, 90)));
    data.emplace_back(std::make_shared<Car>("300A", "AUDI", carType::SEDAN, 5000000.0f, std::make_shared<Engine>("1003", engineType::ICT, 100000, 100)));
}

void display_Objects(container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("Enpty Data.");
    }
    for(pointer & ptr:data)
    {
        std::cout<<*ptr<<std::endl;
    }
    
}

int engineHorsepower(container &data, std::string carid)
{
    if (data.empty())
    {
        throw std::runtime_error("Enpty Data.");
    }
    for (const pointer &ptr : data)
    {
        if (ptr->getCarId() == carid)
        {
            return ptr->getCarEngine()->getEngineHorsepower();
        }
    }
    throw std::runtime_error("Data Not Found");
}

container Instances_Of_Car(container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("Enpty Data.");
    }
    container obj;
    for (const pointer &ptr : data)
    {
        if (ptr->getCarEngine()->getEngineTorque() > 80)
        {
            obj.emplace_back(ptr);
        }
    }
    return obj;
   
}

container2 Instances_Of_Engine(container &data, carType type)
{
    if (data.empty())
    {
        throw std::runtime_error("Enpty Data.");
    }
    container2 obj;
    for (pointer &ptr : data)
    {
        if (ptr->getType() == type)
        {
            obj.emplace_back(ptr->getCarEngine());
        }
    }
    if(obj.empty())
    {
        throw std::runtime_error("NO DATA FOUND");
    }
    return obj;
}

float Average_Of_engineHorsepower(container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("Enpty Data.");
    }
    float total{0};
    int count{0};
    for (pointer &ptr : data)
    {
        if ((ptr->getCarEngine())->getType() == engineType::ICT && ptr->getCarPrince() > 1000000)
        {
            total = total + ptr->getCarEngine()->getEngineHorsepower();
            count += 1;
        }
    }
    return total / count;
}

std::string carIdFindofLowestPrice(container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("Enpty Data.");
    }
    std::string lowest{""};
    float price{data[0]->getCarPrince()};
    for (pointer &ptr : data)
    {
        if (ptr->getCarPrince() < price)
        {
            price = ptr->getCarPrince();
            lowest = ptr->getCarId();
        }
    }
    return lowest;
}

float Combine_price(container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("Enpty Data.");
    }
    float total = data[0]->getCarPrince() + data[1]->getCarPrince();
    return total;
}
