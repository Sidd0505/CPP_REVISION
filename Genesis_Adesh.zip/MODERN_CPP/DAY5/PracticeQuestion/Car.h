#ifndef CAR_H
#define CAR_H

#include<iostream>
#include"carType.h"
#include"Engine.h"
#include<memory>
class Car
{
private:
std::string carId{""};
std::string carBrand{""};
carType type={carType::HATCHBACK};
std::shared_ptr<Engine> carEngine;

float carPrince{0.0f};    
public:

    Car(std::string _carId,std::string _carBrand,carType _type,float _carPrice, std::shared_ptr<Engine> _carEngine);
    Car()=default;
    Car(Car&)=delete;
    ~Car() {}

    std::string getCarId() const { return carId; }

    std::string getCarBrand() const { return carBrand; }

    carType getType() const { return type; }

    float getCarPrince() const { return carPrince; }

    std::shared_ptr<Engine> getCarEngine() const { return carEngine; }

    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);
};

#endif // CAR_H
