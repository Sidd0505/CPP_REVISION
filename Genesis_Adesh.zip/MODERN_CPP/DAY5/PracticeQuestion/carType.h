#ifndef CARTYPE_H
#define CARTYPE_H

#include<iostream>

enum class carType{
SEDAN,
SUV,
SPORTS,
HATCHBACK,
};

#endif // CARTYPE_H
