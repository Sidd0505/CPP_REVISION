#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<vector>
#include<memory>
#include"Customer.h"

using pointer=std::shared_ptr<Customer>;
using container=std::vector<pointer>;

void Create_Objects(container& data);
// void Diaplay_Details(container& data);

/*
a function to find average age of all customers
*/
float Average_Age(container& data);

/*
a function to return the Nth object from the container
*/
pointer Show_Object(container& data,int index);
/*
a function to find the age of the customer whose is is provided as a paramater
*/
int Search_By_Age(container& data,int id);

// A function to find cvv number of DebitCard whose id is provided by user
int CVV_Number_By_Customer_Id(const container& data,const int id);

// A function to return the expiry date of debit card whose cvv matches with given value by user
std::string Expiry_Date_DebitCard(const container& data,const int cvv);

// A function to return a container of all "Pointer"s which point to customer with age above 50
container Container_Of_Pointers_Age_Above_50(const container& data);

// A function to return the debit card pointer for a customer whose ID is given as input paramater
std::shared_ptr<DebitCard> Debit_Card_Pointer(const container& data,int id);



#endif // FUNCTIONALITIES_H
