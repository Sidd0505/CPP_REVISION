#include "Functionalities.h"

void Create_Objects(container &data)
{
   data.emplace_back(std::make_shared<Customer>(101, "Adesh", 21, Customer_Type::ELITE,
                                                std::make_shared<DebitCard>(1122, "Adesh Narke", "11/31", Debit_Card_Type::DOMESTIC)));

   data.emplace_back(std::make_shared<Customer>(102, "Aniket", 52, Customer_Type::REGULAR,
                                                std::make_shared<DebitCard>(2233, "Aniket Wable", "12/24", Debit_Card_Type::DOMESTIC)));
}

// void Diaplay_Details(container &data)
// {
//    int size = data.size();
//    for (int i = 0; i < size; i++)
//    {
//       std::cout << *data[i] << std::endl;
//    }
// }

float Average_Age(container &data)
{

   int total{0};
   if (data.empty())
   {
      throw std::runtime_error("Empty Data");
   }
   else
   {
      for (pointer &ptr : data)
      {
         total = total + ptr->customerAge();
      }
   }

   return total / data.size();
}

pointer Show_Object(container &data, int index)
{
   if (data.empty())
   {
      throw std::runtime_error("Empty Data");
   }
   if (index > data.size() && index < 1)
   {
      throw std::runtime_error("N is beyond available items");
   }
   auto itr = data.begin();
   while (index > 1)
   {
      itr++;
      index--;
   }
   return *itr;
}

int Search_By_Age(container &data, int id)
{

   if (data.empty())
   {
      throw std::runtime_error("Empty Data");
   }

   for (pointer &ptr : data)
   {
      if (id == ptr->customerId())
      {
         return ptr->customerAge();
      }
   }

   throw std::runtime_error("Id not found");
}

std::string Expiry_Date_DebitCard(const container &data, const int cvv)
{
   if (data.empty())
   {
      throw std::runtime_error("Empty Data");
   }

   for (const pointer &ptr : data)
   {
      if (cvv == ptr->card()->cvv())
      {
         return ptr->card()->expiryDate();
      }
   }

   throw std::runtime_error("CVV NOT FOUND");
}

container Container_Of_Pointers_Age_Above_50(const container &data)
{

   if (data.empty())
   {
      throw std::runtime_error("Empty Data");
   }
   container obj;
   for (const pointer &ptr : data)
   {
      if (ptr->customerAge() > 50)
      {

         obj.emplace_back(ptr);
      }
   }
   if (obj.empty())
   {
      throw std::runtime_error("Data not Found");
   }
   return obj;
}

std::shared_ptr<DebitCard> Debit_Card_Pointer(const container &data, const int id)
{
   if (data.empty())
   {
      throw std::runtime_error("Empty Data");
   }
   if (id < 1)
   {
      throw std::runtime_error("N is beyond available items");
   }

   for (const pointer &ptr : data)
   {
      if (ptr->customerId() == id)
      {
         return ptr->card();
      }
   }
   throw std::runtime_error("Details Not Found");
}

int CVV_Number_By_Customer_Id(const container &data, const int id)
{
   if (data.empty())
   {
      throw std::runtime_error("Empty Data");
   }
   if (id < 1)
   {
      throw std::runtime_error("N is beyond available items");
   }

   for (const pointer &ptr : data)
   {
      if (ptr->customerId() == id)
      {
         return ptr->card()->cvv();
      }
   }
   throw std::runtime_error("Details Not Found");
}
