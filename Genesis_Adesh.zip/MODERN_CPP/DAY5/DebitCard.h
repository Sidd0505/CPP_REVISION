#ifndef DEBITCARD_H
#define DEBITCARD_H

#include <iostream>
#include "DebitCardType.h"

class DebitCard //final//anything is final we cannot create child for that class
{
private:
    int _cvv{0};
    std::string _name{""};
    std::string _expiry_date{""};
    Debit_Card_Type type{Debit_Card_Type::DOMESTIC};

public:

    DebitCard(int cvv, std::string name, std::string expiry, Debit_Card_Type type);

    DebitCard() = delete;

    DebitCard(DebitCard &) = delete;

    DebitCard &operator=(const DebitCard &) = delete;

    DebitCard(DebitCard &&) = delete;

    DebitCard &operator=(const DebitCard &&) = delete;

    ~DebitCard() = default;

    int cvv() const { return _cvv; }

    std::string name() const { return _name; }

    std::string expiryDate() const { return _expiry_date; }

    Debit_Card_Type getType() const { return type; }

    friend std::ostream &operator<<(std::ostream &os, const DebitCard &rhs);

};

#endif // DEBITCARD_H
