#include <iostream>
#include "vehicle.h"
#include "VehicalType.h"

template <typename t>
class shared_ptr_demo
{
private:
    t *ptr;

public:
    shared_ptr_demo(t *p) : ptr(p)
    {
    }
    ~shared_ptr_demo()
    {
        delete ptr;
    }
};

int main()
{
    // step 1 -> shared_ptr_demo gets created
    // step 2 -> ptr goes out of scope
    //     ptr was a local variable of main function
    //     destructor called
    // step 3 -> 
    shared_ptr_demo<vehicle> ptr = new vehicle(101, "city", 140000.0f, VehicleType::PERSONAL);
}

/*
RAII: Resource Acquisition Is Initialization
1) When is acquired resource, something is initizalized 

2) if I want to acquire resource then I must acquire it 
while initializing "something"

*/