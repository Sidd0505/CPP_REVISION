/*
    file open
    database connection

*/

//#include <iostream>
#include "vehicle.h"
#include "VehicalType.h"
#include <memory>

int main()
{
    std::shared_ptr<vehicle> ptr = std::make_shared<vehicle>(101,"city",140000.0f, VehicleType::PERSONAL);
    //vehicle *ptr=new vehicle(101,"honda_city",140000.0f, VehicleType::PERSONAL);
    std::cout<<ptr->Id()<<std::endl;
    std::cout<<ptr->modelName()<<std::endl;
    std::cout<<ptr->Price()<<std::endl;
    
    return 0;
}