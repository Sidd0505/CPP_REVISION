#include<iostream>


/*

0x400
0x401
0x402
0x403


0x404
0x405
0x406
0x407


0x408
0x409
0x40a
0x40b


0x40c

*/

void magic(int* arr,int size)
{
 for(int i=0;i<size;i++)
    {
        std::cout<<*(arr+i)<<std::endl;
        /*
              *(arr+i) allows compiler to jump into memory location starting
              from an offset of "i" positions from the base address stored in "arr"
        */
       
    }
}
int main()
{
    /*
    to go to i location

    take the base address, add(size)*i

    eg:
    0x400H + (4*2) = 0x408H
    */

   //one * means one jump in memory loactions
    int arr[3]={10,20,30};
    int size=3;
    magic(arr,size);

   
    return 0;
}