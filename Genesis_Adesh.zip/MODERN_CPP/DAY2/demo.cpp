#include<iostream>

/*
   &                            (just name)   
Address          Name           Content
0x100H             n1               10
0x111H             ptr           0x100H
0x222H             sptr          0x111H

*/
int main()
{
    int n1=10;
    int* ptr=&n1;
    int** sptr=&ptr;//sptr is pointer to pointer

    std::cout<<"Address of n1 is : "<<&n1<<std::endl;
    std::cout<<"Content of ptr is : "<<ptr<<std::endl;

    std::cout<<"Address of ptr is : "<<&ptr<<std::endl;
    std::cout<<"Content of sptr is : "<<sptr<<std::endl;

    std::cout<<*sptr<<std::endl;
    std::cout<<**sptr<<std::endl;

}