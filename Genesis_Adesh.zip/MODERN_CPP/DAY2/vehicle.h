#ifndef VEHICALE_H
#define VEHICALE_H

#include <iostream>
#include "VehicalType.h"
// enum VehicleType{};
// enum class VehicleType
// {
//     PERSONAL,
//     TRANSPORT,
//     SECURITY
// };
class vehicle
{
private:

    int id;
    std::string model_name;
    float price;
    VehicleType type;

public:

    vehicle(int _id,std::string _model,float _price,VehicleType _type):id(_id),
    model_name(_model),price(_price),type(_type)
    {
        
    }
    // 1) Default Constructor (deleted default constructor)

    vehicle() = delete;

    // 2) Copy Constructor (deleted copy constructor)

    vehicle(const vehicle &) = default;

    // 3) Copy assignment operator

    vehicle &operator=(const vehicle &) = delete;

    // 4) Move Constructor

    vehicle(vehicle &&) = delete;

    // 5) Move Assignment

    vehicle &operator=(vehicle &) = delete;

    // 6) Destructor

    float Price(){ return price; }
    int Id() { return id; }
    void setId(int id_) { id = id_; }
    void setPrice(float price_) { price = price_; }
    
    ~vehicle()
    {
        std::cout<<"Bye...!"<<std::endl;
    }

    std::string modelName() const { return model_name; }
    void setModelName(const std::string &modelName) { model_name = modelName; }

    VehicleType getType() const { return type; }
    void setType(const VehicleType &type_) { type = type_; }

   
};

#endif // VEHICALE_H
