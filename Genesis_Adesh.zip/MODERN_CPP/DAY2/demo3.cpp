#include<iostream>
#include<memory>
int main()
{
    //int* ptr=(int*) malloc(16);
    std::shared_ptr<int[4]> ptr(new int[4]{10,20,30,40}); // shared ptr for array of 4 integers
    //ptr[0]=50;
    std::cout<<ptr[0]<<std::endl;
    return 0;
}