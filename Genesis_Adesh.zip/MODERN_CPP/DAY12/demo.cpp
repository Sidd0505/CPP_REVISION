#include <iostream>
#include <functional>
using namespace std::placeholders;

void print(int x, int y, int z)
{
    std::cout<<"Globel Function"<<std::endl;
    std::cout << x << " " << y << " " << z << std::endl;
}

class demo
{
public:
    void print(int x, int y, int z)
    {
        std::cout<<"Member Function"<<std::endl;
        std::cout << x << " " << y << " " << z << std::endl;
    }
};
int main()
{
    demo obj;
    auto func = std::bind(&demo::print,&obj, 100, _1, _3);
    func(10, 20, 30);
    return 0;
}

/* 
Container data;
auto fn=std::bind(SalaryGivenId,_1,100);
fn(data);
*/