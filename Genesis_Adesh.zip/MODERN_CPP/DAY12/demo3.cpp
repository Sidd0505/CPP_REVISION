#include<iostream>
#include<functional>

void demo(int x,int y)
{
    x++;
    y++;
}
using namespace std::placeholders;
int main()
{
    int a=10;
    int b=20;

    auto func=std::bind(&demo,a,b);
    func();
    std::cout<<"Value of a : "<<a<<std::endl;
    std::cout<<"Value of b : "<<b<<std::endl;
    return 0;
}



