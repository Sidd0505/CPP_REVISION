#include<array>
#include<iostream>

int main()
{
    std::array<int,3>arr1;
    arr1[0]=100;
    arr1[1]=200;
    arr1[2]=300;

    for(int i=0;i<3;i++)
    {
        arr1[i]=(1*i)+100;
    }

    for(int val:arr1)
    {
        std::cout<<val<<std::endl;
    }
    std::cout<<"First Number : "<<arr1.front()<<std::endl;
    std::cout<<"Last Number : "<<arr1.back()<<std::endl;

    std::array<std::array<int,3>,3>arr2{
        std::array<int,3>{1,2,3},
        std::array<int,3>{4,5,6},
        std::array<int,3>{7,8,9}};

    int arr4[3][3]{{1,2,3},{4,5,6},{7,8,9}};

    for(std::array<int,3> &row:arr2)
    {
        for(int element:row)
        {
            std::cout<<element<<" ";
        }
    }
    return 0;
}