#include"Student.h"
#include"Functionalities.h"
#include<memory>
int main()
{
   std::shared_ptr<Student> obj;
   CreateObject(*obj);
   
}