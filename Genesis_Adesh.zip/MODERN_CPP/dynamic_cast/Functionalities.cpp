#include "Functionalities.h"

void CreateObject(Student& obj)
{

}

void Average(Student& obj)
{
}
