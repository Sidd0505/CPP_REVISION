#ifndef STUDENT_H
#define STUDENT_H

#include <iostream>

class Student
{
private:
    int _Roll_No{0};
    std::string name{""};
    std::string city{""};
  

public:
    Student(int Roll_No, std::string name, std::string city);
    Student() = delete;
    Student(Student &) = delete;
    // Student &operator=(Student &) = delete;
    // Student &operator=(Student &&) = delete;
    // Student(Student &&) = delete;
    ~Student() = default;

    int rollNo() const { return _Roll_No; }
    void setRoll_No(int Roll_No) { _Roll_No = Roll_No; }

    std::string getName() const { return name; }
    void setName(const std::string &name_) { name = name_; }

    std::string getCity() const { return city; }
    void setCity(const std::string &city_) { city = city_; }

    friend std::ostream &operator<<(std::ostream &os, const Student &rhs);
};

#endif // STUDENT_H
