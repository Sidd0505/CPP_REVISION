#include"Student.h"
#include<memory>
#include<vector>
// using pointer=std::shared_ptr<Student>;
// using container=std::vector<pointer>;
//std::shared_ptr<Student> obj=std::make_shared<Student>();
std::shared_ptr<Student> obj;
void CreateObject(Student& obj);
void Average(Student& obj);