#include "Student.h"

Student::Student(int Roll_No, std::string name, std::string city)
    : _Roll_No(Roll_No), name(name), city(city)
{
    //arr = new int[3];
    // for (int i = 0; i < 3; i++)
    // {
    //     arr[i] = arr[i];
    // }
}
std::ostream &operator<<(std::ostream &os, const Student &rhs)
{
    os << "_Roll_No: " << rhs._Roll_No
       << " name: " << rhs.name
       << " city: " << rhs.city;
    //    << " arr: " << rhs.arr[0],
    //     rhs.arr[1], rhs.arr[2];
    return os;
}
