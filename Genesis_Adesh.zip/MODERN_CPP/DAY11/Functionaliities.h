#ifndef FUNCTIONALIITIES_H
#define FUNCTIONALIITIES_H

#include<memory>
#include<vector>
#include"Employee.h"
#include<functional>

using Pointer=std::shared_ptr<Employee>;
using Container=std::vector<Pointer>;



/*  
identifier AverageSalary is a veriable name(name of object)

If a veriable is declared in a file but has to be initialized
in a separate file, such variables must be marked as "extern"
*/


extern std::function<float(Container&)> AverageSalary;

#endif // FUNCTIONALIITIES_H
