#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <iostream>

/*
Class name in PASCALCASE
Enum
e.g Employee
e.g EmployeeData
*/

class Employee
{
private:
    /*
    data member names

    a) prefix with underscore e.g: _id
    b) camelcase : e.g : employeeOfficialName
    */
    int _id;
    std::string _name;
    float _salary;

public:
    Employee(int id, std::string name, float salary)
        : _id(id), _name(name), _salary(salary)
    {
    }
   
    /*
    member function in PascalCase
    */
    virtual float CalculateTax() = 0;

    ~Employee() {}

    int id() const { return _id; }

    std::string name() const { return _name; }

    float salary() const { return _salary; }
};

#endif // EMPLOYEE_H
