#ifndef ENGINE_H
#define ENGINE_H

#include"EngineType.h"
#include <ostream>

class Engine
{
private:
    int _hoursepower;
    EngineType _engineType;

public:

    Engine(int horsepower,EngineType type);
    ~Engine()=default;

    int hoursepower() const { return _hoursepower; }

    EngineType engineType() const { return _engineType; }

    friend std::ostream &operator<<(std::ostream &os, const Engine &rhs);
    
};

#endif // ENGINE_H
