#include "Functionalities.h"

void CreateObjects(carContainer &data,EngineContainer& enginedata)
{
     enginedata[0]=std::make_shared<Engine>(200, EngineType::PETROl);

     data[0]=std::make_shared<Car>(

        101, "Dzire", 750000.0f,enginedata[0]
      );
}