#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H
#include<memory>
#include<array>
#include"Car.h"


using carPointer=std::shared_ptr<Car>;
using carContainer=std::array<carPointer,3>;

using EnginePointer=std::shared_ptr<Engine>;
using EngineContainer=std::array<EnginePointer,3>;

void CreateObjects(carContainer& data,EngineContainer& enginedata);

#endif // FUNCTIONALITIES_H
