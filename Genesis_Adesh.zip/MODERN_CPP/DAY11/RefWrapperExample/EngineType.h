#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType
{
    PETROl,DIESEL,CNG
};

#endif // ENGINETYPE_H
