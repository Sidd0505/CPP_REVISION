#include "Engine.h"
std::ostream &operator<<(std::ostream &os, const Engine &rhs) {
    os << "_hoursepower: " << rhs._hoursepower
       << " _engineType: " << static_cast<int>(rhs._engineType);
    return os;
}
Engine::Engine(int horsepower, EngineType type):_hoursepower(horsepower),_engineType(type)
{
}
