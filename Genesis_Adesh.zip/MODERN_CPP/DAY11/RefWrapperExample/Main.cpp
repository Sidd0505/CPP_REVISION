#include<iostream>
#include"Functionalities.h"
int main()
{
    carContainer obj;
    EngineContainer engineobj;
    CreateObjects(obj,engineobj);
    std::cout<<*obj[0];

}