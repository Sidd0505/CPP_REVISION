#include "Bike.h"

std::ostream &operator<<(std::ostream &os, const Bike &rhs)
{
    os << "Bike { Id : " << rhs._id << " Price : " << rhs._price << " Type : " << static_cast<int>(rhs._type) << " }";
    return os;
}

Bike::Bike(std::string id, float price, VehicleType type)
    : _id(id), _price(price), _type(type)
{
}
