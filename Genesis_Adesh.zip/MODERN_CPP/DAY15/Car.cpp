#include "Car.h"

std::ostream &operator<<(std::ostream &os, const Car &rhs)
{
    os << "Car { Id : " << rhs._id << " Price : " << rhs._price << " Type : " << static_cast<int>(rhs._type) << " }";
    return os;
}

Car::Car(std::string id, float price, VehicleType type)
    : _id(id), _price(price), _type(type)
{
}
