#ifndef BIKE_H
#define BIKE_H

#include <iostream>
#include <string>
#include "VehicleType.h"

class Bike
{
private:
    std::string _id;
    float _price;
    VehicleType _type;

public:
    Bike(std::string id, float price, VehicleType type);

    Bike() = default;

    Bike(Bike &) = delete;

    Bike &operator=(Bike &) = delete;

    Bike &operator=(Bike &&) = delete;

    Bike(Bike &&) = delete;

    ~Bike() {}

    std::string id() const { return _id; }

    float price() const { return _price; }

    VehicleType type() const { return _type; }

    friend std::ostream &operator<<(std::ostream &os, const Bike &rhs);
};

#endif // BIKE_H
