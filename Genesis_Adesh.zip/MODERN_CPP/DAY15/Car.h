#ifndef CAR_H
#define CAR_H

#include <iostream>
#include <string>
#include "VehicleType.h"

class Car
{
private:
    std::string _id;
    float _price;
    VehicleType _type;

public:
    Car(std::string id, float price, VehicleType type);

    Car() = default;

    Car(Car &) = delete;

    Car &operator=(Car &) = delete;

    Car &operator=(Car &&) = delete;

    Car(Car &&) = delete;

    ~Car() {}

    std::string id() const { return _id; }

    float price() const { return _price; }

    VehicleType type() const { return _type; }

    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);
};

#endif // CAR_H
