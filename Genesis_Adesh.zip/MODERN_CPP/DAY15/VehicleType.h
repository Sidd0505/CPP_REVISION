#ifndef VEHICLETYPE_H
#define VEHICLETYPE_H

enum class VehicleType
{
    SEDAN,
    SUV,
    HATCHBACK,
    SPORTS,
    COMMUTE
};

#endif // VEHICLETYPE_H
