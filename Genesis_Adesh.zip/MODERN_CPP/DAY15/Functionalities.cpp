#include "Functionalities.h"
#include<algorithm>
#include<numeric>

void CreateObject(Container &data)
{
    data.emplace_back(std::make_shared<Car>("C101", 700000.0f, VehicleType::HATCHBACK));
    data.emplace_back(std::make_shared<Car>("C102", 900000.0f, VehicleType::HATCHBACK));
    data.emplace_back(std::make_shared<Car>("C103", 800000.0f, VehicleType::SUV));

    data.emplace_back(std::make_shared<Bike>("B101", 300000.0f, VehicleType::COMMUTE));
    data.emplace_back(std::make_shared<Bike>("B102", 200000.0f, VehicleType::SPORTS));
}

float AveragePrice(const Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY DATA");
    }
    float total = 0.0f;
    
    int count;
    for (const VType V : data)
    {
        std::visit([&](auto &&val)
                   { total = total + val->price();
                   count+=1; },
                   V);
    }

    return total/count;
}

VType MinimumPriceInstance(const Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY DATA");
    }

    VType result;
    
  




    float minimum;
    std::visit([&](auto &&val)
               { minimum = val->price(); },
               data.front());

    for (const VType V : data)
    {
        std::visit([&](auto &&val)
                   {
            if(val->price()<minimum)
            {
                minimum=val->price();
                result=val;
            } },
                   V);
    }

    return result;
}

bool IfIdExists(const Container &data, std::string id)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY DATA");
    }
    bool flag = 0;
    for (const VType V : data)
    {

        std::visit([&](auto &&val)
                   { 
                            if(val->id()==id)
                            {
                                flag= true;
                            }; },
                   V);
    }
    return flag;
}

std::optional<std::list<VType>> InstancesMatchingType(const Container &data, VehicleType type)
{
    if (data.empty())
    {
        throw std::runtime_error("data is empty");
    }

    Container result;
    for (VType v : data)
    {
        std::visit([&](auto&& val)
                                {
                                    if(val->type()==type)
                                    {
                                        result.emplace_back(v);
                                    } 
                                },
                 v);
    }

    if (result.empty())
    {
        return std::nullopt;
    }
    else
    {
        return result;
    }
}

/*

*/
// git config --global user.email "adesh.narke@gamil.com"