#ifndef BIKETYPE_H
#define BIKETYPE_H

enum class BikeType
{
    SPORTS,
    COMMUTE
};

#endif // BIKETYPE_H
