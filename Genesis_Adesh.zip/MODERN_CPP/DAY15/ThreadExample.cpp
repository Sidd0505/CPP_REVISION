#include <iostream>
#include <mutex>
#include <thread>
std::mutex mt;

void calculateSquare(std::array<int, 5> &arr)
{
    for (int val : arr)
    {
        std::lock_guard<std::mutex> lk(mt);
        std::cout << val * val << std::endl;
    }
}

void calculateCube(std::array<int, 5> &arr)
{
    for (int val : arr)
    {
        std::lock_guard<std::mutex> lk(mt);
        std::cout << val * val * val << std::endl;
    }
}

// int main()
// {
//     std::array<int, 5> arr{1, 2, 3, 4, 5};
//     std::thread t1(&calculateCube, std::ref(arr));
//     t1.join();
//     std::thread t2(&calculateSquare, std::ref(arr));
//     t2.join();
//     return 0;
// }