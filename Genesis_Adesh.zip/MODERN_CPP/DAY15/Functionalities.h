#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "Car.h"
#include "Bike.h"
#include <memory>
#include <list>
#include <variant>
#include <optional>

using CarPointer = std::shared_ptr<Car>;
using BikePointer = std::shared_ptr<Bike>;
using VType = std::variant<CarPointer, BikePointer>;
using Container = std::list<VType>;

void CreateObject(Container &data);

/*
Average price can be found using visit and total
*/

float AveragePrice(const Container &data);

/*
Find instance with minimum price (all vehicles have prices which are unique)
*/

VType MinimumPriceInstance(const Container &data);

/*
Check if given Id is present in any of the instance
*/

bool IfIdExists(const Container &data, std::string id);

/*
Return all instances whose type matches with type passed
*/

std::optional<std::list<VType>> InstancesMatchingType(const Container &data, VehicleType type);

#endif // FUNCTIONALITIES_H
