// #include<iostream>
// #include<condition_variable>
// #include<thread>
// std::condition_variable cv;
// std::mutex mt;

// bool flag=false;
// int number=0;
// void square()
// {
//     std::unique_lock<std::mutex> ul(mt);
//     cv.wait(ul,[](){return flag;});
//     std::cout<<"Square of Number is : "<<number*number<<std::endl;
// }
// void cube(int a)
// {
//     std::cout<<"Cube of Number is : "<<a*a<<std::endl;
// }
// void add(int a,int b)
// {
//     std::cout<<"Addition is : "<<a+b<<std::endl;
// }
// // int main()
// // {
// //     std::thread t1(&square);
// //      std::thread t2(&cube,10);
// //      std::thread t3(&add,10,20);
// //      t2.join();
// //      t3.join();
// //     std::cin>>number;
// //     flag=true;
// //     cv.notify_one();//send from main to os that condition according to me is satisfied
// //     t1.join();
    
// //     return 0;
// // }