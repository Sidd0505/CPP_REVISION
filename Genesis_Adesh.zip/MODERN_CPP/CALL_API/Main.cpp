#include<iostream>
#include"Request.h"

int main()
{

    auto api_ptr = std::make_shared<Request>("https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=USD,JPY,EUR");
    api_ptr->ExecuteApiCal();
    // std::cout<<*api_ptr<<"\n";
    
    return 0;
}