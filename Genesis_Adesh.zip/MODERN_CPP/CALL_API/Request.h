#ifndef REQUEST_H
#define REQUEST_H

#include<iostream>
#include<memory>
#include"Response.h"
#include<curl/curl.h>

class Request
{
    private:
    CURL* _curl;
    std::string url;
    std::shared_ptr<Response>_response;

    
public:
    Request( std::string url);
    void ExecuteApiCal();
    
    friend std::ostream &operator<<(std::ostream &os, const Request &rhs);
   ~Request()
   {
    curl_easy_cleanup(_curl);
   }
};

#endif // REQUEST_H
