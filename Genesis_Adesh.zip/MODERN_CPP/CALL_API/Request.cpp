#include "Request.h"

std::ostream &operator<<(std::ostream &os, const Request &rhs)
{
    os << "url: " << rhs.url
       << " _response: " << *rhs._response;
    return os;
}

Request::Request( std::string url):url(url),_curl(curl_easy_init()), _response(std::make_shared<Response>())
{
}

void Request::ExecuteApiCal()
{
  
    curl_easy_setopt(_curl, CURLOPT_URL, "https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=USD,JPY,EUR");

    curl_easy_setopt(_curl, CURLOPT_WRITEFUNCTION, [](void *contents, size_t size, size_t nmemb, std::string* output)
                     {
                        size_t total_size=size*nmemb;
                        output->append(static_cast<char*>(contents),total_size);
                        return total_size;
    });
 
    curl_easy_setopt(_curl, CURLOPT_WRITEDATA, &_response->getResponseData());
    
     curl_easy_perform(_curl);

  
}

