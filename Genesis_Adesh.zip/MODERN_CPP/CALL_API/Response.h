#ifndef RESPONSE_H
#define RESPONSE_H
#include <ostream>

class Response
{
private:
    std::string _response_string{""};
    
public:
    Response(); 
   
    const std::string& getResponseData() const;

    friend std::ostream &operator<<(std::ostream &os, const Response &rhs);
 ~Response()=default;
};

#endif // RESPONSE_H
