#include"Response.h"

std::ostream &operator<<(std::ostream &os, const Response &rhs) {
    os << "_response_string: " << rhs._response_string;
    return os;
}

Response::Response():_response_string()
{
}

const std::string &Response::getResponseData() const
{
    return _response_string;
    // TODO: insert return statement here
}
