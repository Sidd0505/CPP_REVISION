#include<memory>

/* 

variadic templates (templates that can accept variable number of arguments)
e.g make_shared function template

*/

// use concept of resurssion and base cause
//
//my base case in addition is: adding only 1 value

#include<iostream>

template<typename T>

T add(T n1)
{
    return n1;
}

template<typename T,typename... args>

T add(T n1,args... ar)
{
    return n1+add(ar...);
}

template<typename... T>

auto add(T... args)
{
    return (args + ...); //cpp 17
}

int main()
{
    std::cout<<add<int>(10)<<"\n";
    std::cout<<add<int>(10,20,30,40)<<"\n";
}