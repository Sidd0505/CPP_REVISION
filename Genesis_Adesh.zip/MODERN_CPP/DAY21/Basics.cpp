#include <iostream>

void f1(int n1) /* pass by value : accept both lvalue and rvalue. rvalue is assigned. lvalue is copied. n1 is also modifyable in the scope of f1 */
{
    std::cout << "Address of n1 in f1 function : " << &n1 << "\n";
    std::cout << "Value of n1 in f1 before modification : " << n1 << "\n";
    n1 = 100;
    std::cout << "value of n1 in f1 after modification : " << n1 << "\n";
}

/*
pass by non-const reference. Accepts only LVALUES. RVALUES CANNOT BE PASSED.
NO COPY CREATED. ORIGINAL VALUE IS ACCESSED BY REFERENCE
*/

void f2(int &n1)
{
    std::cout << "Address of n1 in f1 function : " << &n1 << "\n";
    std::cout << "Value of n1 in f1 before modification : " << n1 << "\n";
    n1 = 100;
    std::cout << "Value of n1 in f1 after modification : " << n1 << "\n";
}

/*
pass by const value : accepts both lvalues and rvalues but DOES NOT ALLOW ANY MODIFICATION
LVALUE IS COPIED. RVALUE IS ASSIGNED.
*/

void f3(const int n1)
{
    std::cout << "Address of n1 in f1 function : " << &n1 << "\n";
    std::cout << "Value of n1 in f1 before modification : " << n1 << "\n";
}

/*
accepts both lvalue and rvalue. lvalues will be taken by reference rvalue will be
assigned to n1. No modification.
*/

void f4(const int& n1)
{
    std::cout << "Address of n1 in f1 function : " << &n1 << "\n";
    std::cout << "Value of n1 in f1 before modification : " << n1 << "\n";
}

/*
ONLY ACCEPTS RAVLUES. rvalue "maps" itself to n1. n1 can be also be modified inside n1
*/

void f5(int &&n1)
{
    std::cout << "Address of n1 in f1 function : " << &n1 << "\n";
    std::cout << "Value of n1 in f1 before modification : " << n1 << "\n";
    n1 = 100;
    std::cout << "Value of n1 in f1 after modification : " << n1 << "\n";
}


void f6(const int&& n1)
{
  std::cout << "Address of n1 in f1 function : " << &n1 << "\n";
    std::cout << "Value of n1 in f1 before modification : " << n1 << "\n";
    // n1 = 100;
    std::cout << "Value of n1 in f1 after modification : " << n1 << "\n";
}
int main()
{
    int n1 = 10;
    f1(n1);
    std::cout << "----------------" << std::endl;
    f2(n1);
    std::cout << "----------------" << std::endl;
    f4(100);
    std::cout << "----------------" << std::endl;
    f5(10);
    f6(10);
    return 0;
}