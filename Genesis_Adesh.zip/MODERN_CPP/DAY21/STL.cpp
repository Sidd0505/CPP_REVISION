/*

copy     ->
copy_if  ->
all_of   ->
any_of   ->
none_of  ->
count_if ->
find_if  ->
accumulate ->
max_element ->
min_element ->
sort ->

*/

#include <set>
#include <iostream>
#include <memory>

class Employee
{
public:
    Employee(std::string name, float salary)
    {
        _name = name;
        _salary = salary;
    }
    Employee() = default;
    Employee(Employee &&) = default;
    Employee(const Employee &) = default;
    Employee &operator=(Employee &&) = default;

    float salary() const { return _salary; }

    std::string name() const { return _name; }

    friend std::ostream &operator<<(std::ostream &os, const Employee &rhs)
    {
        os << "_name: " << rhs._name
           << " _salary: " << rhs._salary;
        return os;
    }

    



private:
    std::string _name;
    float _salary;
};

using Pointer = std::shared_ptr<Employee>;
using pointer_container = std::set<Pointer>;
template <typename T>

void display(const T &container)
{
    for (const auto &val : container)
    {
        std::cout << val << "\n";
    }
}
template <>
void display(const pointer_container &data)
{
    for (const Pointer &val : data)
    {
        std::cout << *val << "\n";
    }
}

int main()
{
    std::set<int> s1{10, 20, 30, 40, 50, 10};
    display(s1);

    Pointer emp1 = std::make_shared<Employee>("Adesh", 100000.0f);
    Pointer emp2 = std::make_shared<Employee>("Aniket", 200000.0f);
    Pointer emp3 = std::make_shared<Employee>("Parth", 300000.0f);
    Pointer emp4 = std::make_shared<Employee>("Yash", 400000.0f);
    Pointer emp5 = std::make_shared<Employee>("Yash", 400000.0f);
    std::set<Pointer> e1{emp1, emp2, emp3, emp3, emp4,emp5};
    display(e1);
}