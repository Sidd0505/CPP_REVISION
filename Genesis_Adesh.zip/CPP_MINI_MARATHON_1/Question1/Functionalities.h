#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "Order.h"
#include <list>
#include <memory>

using Pointer = std::shared_ptr<Order>;
using Container = std::list<Pointer>;

/* 
Function to create objects on heap of order class
*/

void CreateObject(Container &data);

/* 
A function to return id of the order whose discount is highest
*/

int id_of_highest_discount(const Container &data);

/* 
A function to return type of the order whose id is passed in argument
*/

OrderType type_of_order(const Container &data, int id);

/* 
A function to return average of the all values
*/

float average_value_of_all_orders(const Container &data);

/* 
A function to return a container of n instances
*/

Container n_instances(const Container &data, int n);

#endif // FUNCTIONALITIES_H
