#include "Order.h"

Order::Order(int id, float value, OrderType type, float discount)
    : _id(id), _value(value), _type(type), _discount(discount)
{
}

std::ostream &operator<<(std::ostream &os, const Order &rhs)
{
    os << "id : " << rhs._id << std::endl;
    os << "value : " << rhs._value<< std::endl;
    switch (static_cast<int>(rhs._type))
    {
    case 0:
        os << "Type of the given id is : PAID " << std::endl;
        break;

    case 1:
        os << "Type of the given id is : COD " << std::endl;
        break;

    case 2:
        os << "Type of the given id is : PROMOTION " << std::endl;
        break;

    default:
        break;
    }
    os << "discount: " << rhs._discount << std::endl;
    return os;
}
