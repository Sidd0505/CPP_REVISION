#ifndef ORDERTYPE_H
#define ORDERTYPE_H

#include <iostream>

enum class OrderType
{
    PAID,
    COD,
    PROMOTION
};

#endif // ORDERTYPE_H
