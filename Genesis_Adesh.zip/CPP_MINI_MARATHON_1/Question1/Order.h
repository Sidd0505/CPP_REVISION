#ifndef ORDER_H
#define ORDER_H

#include <iostream>
#include "OrderType.h"

class Order
{

private:

    int _id{0};
    float _value{0};
    OrderType _type{OrderType::COD};
    float _discount{0.0f};

public:

    Order(int id, float value, OrderType type, float discount);

    Order() = default;

    Order(Order &) = delete;

    Order &operator=(Order &) = delete;

    Order(Order &&) = delete;

    Order &operator=(Order &&) = delete;

    ~Order() = default;

    int id() const { return _id; }

    float value() const { return _value; }

    OrderType type() const { return _type; }

    float discount() const { return _discount; }

    friend std::ostream &operator<<(std::ostream &os, const Order &rhs);
};

#endif // ORDER_H
