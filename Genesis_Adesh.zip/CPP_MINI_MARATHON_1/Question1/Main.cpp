#include <iostream>
#include "Functionalities.h"
#include<thread>
#include<future>
int main()
{
    Container obj;
    CreateObject(obj);


    /* <------- Functionality 1 -------> */
    try
    {
        std::future highest=std::async(std::launch::async,id_of_highest_discount,obj);
        std::cout << "Id of order whose discount is highest is : " << highest.get() << std::endl;
    }
    catch (const std::runtime_error e)
    {
        std::cerr << e.what() << '\n';
    }

    /* <------- Functionality 2 -------> */

    try
    {
        std::future type=std::async(std::launch::async,type_of_order,obj,103);
        switch (static_cast<int>(type.get()))
        {
        case 0:
            std::cout << "Type of the given id is : PAID " << std::endl;
            break;

        case 1:
            std::cout << "Type of the given id is : COD " << std::endl;
            break;

        case 2:
            std::cout << "Type of the given id is : PROMOTION " << std::endl;
            break;

        default:
            break;
        }
    }
    catch (const std::runtime_error e)
    {
        std::cerr << e.what() << '\n';
    }

    /* <------- Functionality 3 -------> */

    try
    {
        std::future average=std::async(std::launch::async,average_value_of_all_orders,obj);
        std::cout << "Average is : " << average.get()<<std::endl;
    }
    catch (const std::runtime_error e)
    {
        std::cerr << e.what() << '\n';
    }

    /* <------- Functionality 4 -------> */

    try
    {
        std::future result=std::async(std::launch::async,n_instances,obj,3);
        
        for (Pointer &ptr : result.get())
        {
            std::cout << *ptr << std::endl;
        }
    }
    catch (const std::runtime_error e)
    {
        std::cerr << e.what() << '\n';
    }

    return 0;
}