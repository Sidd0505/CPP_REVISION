#include<iostream>
#include<thread>
#include<future>

int add(int a,int b)
{
    return a+b;
}

int sub(int a,int b)
{
    return a-b;
}

int mul(int a,int b)
{
    return a*b;
}
// int main()
// {   
//     std::future result1=std::async(std::launch::async,add,10,20);
//     std::future result2=std::async(std::launch::async,sub,10,20);
//     std::future result3=std::async(std::launch::async,mul,10,20);

//     std::cout<<"Addition is : "<<result1.get()<<std::endl;
//     std::cout<<"Substraction is : "<<result2.get()<<std::endl;
//     std::cout<<"Multiplication is : "<<result3.get()<<std::endl;

//     return 0;
// }