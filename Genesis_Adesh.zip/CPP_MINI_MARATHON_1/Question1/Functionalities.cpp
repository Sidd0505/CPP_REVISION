#include "Functionalities.h"

void CreateObject(Container &data)
{
    data.emplace_back(std::make_shared<Order>(101, 500.0f, OrderType::PAID, 50.0f));
    data.emplace_back(std::make_shared<Order>(102, 700.0f, OrderType::COD, 100.0f));
    data.emplace_back(std::make_shared<Order>(103, 600.0f, OrderType::PROMOTION, 90.0f));
    data.emplace_back(std::make_shared<Order>(104, 900.0f, OrderType::PAID, 60.0f));
    data.emplace_back(std::make_shared<Order>(105, 800.0f, OrderType::COD, 90.0f));
}

int id_of_highest_discount(const Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY DATA");
    }

    int id = data.front()->id();
    float discount = data.front()->discount();

    for (const Pointer &ptr : data)
    {
        if (ptr->discount() > discount)
        {
            discount = ptr->discount();
            id = ptr->id();
        }
    }
    return id;
}

OrderType type_of_order(const Container &data, int id)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY DATA");
    }
    if (id < 1)
    {
        throw std::runtime_error("ID SHOULD BE NON NEGATIVE");
    }

    for (const Pointer &ptr : data)
    {
        if (ptr->id() == id)
        {
            return ptr->type();
        }
    }

    throw std::runtime_error("ID NOT FOUND");
}

float average_value_of_all_orders(const Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY DATA");
    }
    float total{0.0f};
    for(const Pointer& ptr:data)
    {
        total=total+ptr->value();
    }
    return total/data.size();
}

Container n_instances(const Container &data, int n)
{

    if (data.empty())
    {
        throw std::runtime_error("EMPTY DATA");
    }
    if (n < 1)
    {
        throw std::runtime_error("N SHOULD BE NON NEGATIVE");
    }
    Container Result;
    int count = 0;
    for (const Pointer &ptr : data)
    {

        if (count == n)
        {
            break;
        }
        Result.emplace_back(ptr);
        count++;
    }
    return Result;
}
