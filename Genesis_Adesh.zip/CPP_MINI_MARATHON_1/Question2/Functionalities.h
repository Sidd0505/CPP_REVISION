#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include <vector>
#include <memory>
#include "Device.h"

using Pointer = std::shared_ptr<Device>;
using Container = std::vector<Pointer>;

using DeviceDriverPointer = std::shared_ptr<DeviceDriver>;
using DeviceDiverContainer = std::vector<DeviceDriverPointer>;

/* 
A function to create instances of Device type
*/
void CreateObject(Container &data);

/* 
A function to return device id of instances which return _battery_drain_factor is above 0.3
*/
float average_of_size_in_bytes_instances(const Container &data);

/* 
A function to check if all devices instances are of type INFOTAINMENT
*/
std::vector<std::string> return_device_id_of_instances(const Container &data);

/* 
A Function to return average of size_in_bytes for instances 
    - whose _release_quarter in either Q1 and Q2
*/
DeviceDiverContainer find_device_driver_instances(const Container &data, DeviceType type);

/* 
A function to return _version_number of the DeviceDriver whose device id provided as parameter
*/
std::string find_version_number(const Container &data, const std::string device_id);

/* 
A Function to return DeviceDriver Container whose type matches as provided argument
*/
bool device_instances_type(const Container &data);

#endif // FUNCTIONALITIES_H
