
#include "DeviceDriver.h"

DeviceDriver::DeviceDriver(std::string version_number, Release_Quarter release_quarter, float size_in_bytes)
    : _version_number(version_number), _release_quarter(release_quarter), _size_in_bytes(size_in_bytes)

{
}

std::ostream &operator<<(std::ostream &os, const DeviceDriver &rhs)
{
    os << "_version_number: " << rhs._version_number << std::endl;
    switch ((int)rhs._release_quarter)
    {
    case 0:
        os << "_release_quarter: Q1" << std::endl;
        break;
    case 1:
        os << "_release_quarter: Q2" << std::endl;
        break;
    case 2:
        os << "_release_quarter: Q3" << std::endl;
        break;
    case 3:
        os << "_release_quarter: Q4" << std::endl;
        break;
    }
    os << " _size_in_bytes: " << rhs._size_in_bytes << std::endl;
    return os;
}
