#include "Device.h"

Device::Device(std::string device_id, DeviceType device_type, int device_battery_level, std::shared_ptr<DeviceDriver> device_driver)
    : _device_id(device_id), _device_type(device_type), _device_battery_level(device_battery_level), _device_driver(device_driver)
{
}

std::ostream &operator<<(std::ostream &os, const Device &rhs)
{
    os << "_device_id : " << rhs._device_id;
    switch ((int)rhs._device_type)
    {
    case 0:
        os << "_device_type : INFOTAINMENT" << std::endl;
        break;
    case 1:
        os << "_device_type : ACCESSORY" << std::endl;
        break;
    case 2:
        os << "_device_type : SAFETY" << std::endl;
        break;
    }

    os << "_device_battery_level : " << rhs._device_battery_level;
    os << "_device_driver : " << rhs._device_driver;
    return os;
}

float Device::_battery_drain_factor()
{
    if (deviceType() == DeviceType::INFOTAINMENT || deviceType() == DeviceType::ACCESSORY)
    {
        return 0.25f;
    }
    else if (deviceType() == DeviceType::SAFETY || deviceBatteryLevel() > 50)
    {
        return 0.5f;
    }
    else
    {
        return 0.4f;
    }
}
