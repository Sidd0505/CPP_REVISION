#ifndef DEVICE_H
#define DEVICE_H

#include <iostream>
#include "DeviceType.h"
#include <memory>
#include "DeviceDriver.h"

class Device
{
private:
    std::string _device_id{""};
    DeviceType _device_type{DeviceType::ACCESSORY};
    int _device_battery_level{1};
    std::shared_ptr<DeviceDriver> _device_driver;

public:
    
    Device(std::string device_id, DeviceType device_type, int device_battery_level, std::shared_ptr<DeviceDriver> device_driver);
    
    Device() = default;

    Device(Device &) = delete;

    Device &operator=(Device &) = delete;

    Device(Device &&) = delete;

    Device &operator=(Device &&) = delete;

    float _battery_drain_factor();

    ~Device() = default;

    std::string deviceId() const { return _device_id; }

    DeviceType deviceType() const { return _device_type; }

    int deviceBatteryLevel() const { return _device_battery_level; }

    std::shared_ptr<DeviceDriver> deviceDriver() const { return _device_driver; }

    friend std::ostream &operator<<(std::ostream &os, const Device &rhs);
};

#endif // DEVICE_H
