#ifndef DEVICETYPE_H
#define DEVICETYPE_H

#include <iostream>

enum class DeviceType
{
    INFOTAINMENT,
    ACCESSORY,
    SAFETY
};

#endif // DEVICETYPE_H
