#ifndef DEVICEDRIVER_H
#define DEVICEDRIVER_H

#include <iostream>
#include "Release_Quarter.h"

class DeviceDriver
{
private:
    std::string _version_number{""};
    Release_Quarter _release_quarter{Release_Quarter::Q1};
    float _size_in_bytes{0.0f};

public:
    DeviceDriver() = default;

    DeviceDriver(DeviceDriver &) = delete;

    DeviceDriver &operator=(DeviceDriver &) = delete;

    DeviceDriver(DeviceDriver &&) = delete;

    DeviceDriver &operator=(DeviceDriver &&) = delete;

    DeviceDriver(std::string version_number, Release_Quarter release_quarter, float size_in_bytes);

    std::string versionNumber() const { return _version_number; }

    Release_Quarter releaseQuarter() const { return _release_quarter; }

    float sizeInBytes() const { return _size_in_bytes; }

    friend std::ostream &operator<<(std::ostream &os, const DeviceDriver &rhs);

    ~DeviceDriver() = default;
};

#endif // DEVICEDRIVER_H
