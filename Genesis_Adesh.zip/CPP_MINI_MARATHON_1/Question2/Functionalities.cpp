#include "Functionalities.h"

void CreateObject(Container &data)
{
    data.emplace_back(std::make_shared<Device>
    ("101A", DeviceType::ACCESSORY, 90, std::make_shared<DeviceDriver>("0.1", Release_Quarter::Q1, 80.0f)));
    data.emplace_back(std::make_shared<Device>("102A", DeviceType::INFOTAINMENT, 80, std::make_shared<DeviceDriver>("0.2", Release_Quarter::Q2, 70.0f)));
    data.emplace_back(std::make_shared<Device>("103A", DeviceType::SAFETY, 70, std::make_shared<DeviceDriver>("0.5", Release_Quarter::Q4, 90.0f)));
    data.emplace_back(std::make_shared<Device>("104A", DeviceType::INFOTAINMENT, 88, std::make_shared<DeviceDriver>("0.4", Release_Quarter::Q3, 77.0f)));
    data.emplace_back(std::make_shared<Device>("105A", DeviceType::ACCESSORY, 100, std::make_shared<DeviceDriver>("0.7", Release_Quarter::Q4, 50.0f)));
}

float average_of_size_in_bytes_instances(const Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY DATA");
    }
    float total{0.0f};
    int count = 0;
    for (const Pointer &ptr : data)
    {
        if (0 == (int)(ptr->deviceDriver()->releaseQuarter()) || 3 == (int)(ptr->deviceDriver()->releaseQuarter()))
        {
            total = total + ptr->deviceDriver()->sizeInBytes();
            count++;
        }
    }
    return total / count;
}

std::vector<std::string> return_device_id_of_instances(const Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY DATA");
    }
    std::vector<std::string> Result;

    for (const Pointer &ptr : data)
    {
        if (ptr->_battery_drain_factor() > 0.3f)
        {
            Result.emplace_back(ptr->deviceId());
        }
    }
    return Result;
}

std::string find_version_number(const Container &data, const std::string device_id)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY DATA");
    }

    for (const Pointer &ptr : data)
    {
        if (ptr->deviceId() == device_id)
        {
            return ptr->deviceDriver()->versionNumber();
        }
    }

    throw std::runtime_error("DEVICE ID NOT FOUND");
}

bool device_instances_type(const Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY DATA");
    }
    int count = 0;
    for (const Pointer &ptr : data)
    {
        if (ptr->deviceType() == DeviceType::INFOTAINMENT)
        {
            count = count + 1;
            if (count == data.size())
            {
                return true;
            }
        }
    }

    return false;
}

DeviceDiverContainer find_device_driver_instances(const Container &data, DeviceType type)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY DATA");
    }

    DeviceDiverContainer Result;

    for (const Pointer &ptr : data)
    {
        if (type == ptr->deviceType())
        {
            Result.emplace_back(ptr->deviceDriver());
        }
    }
    return Result;
}