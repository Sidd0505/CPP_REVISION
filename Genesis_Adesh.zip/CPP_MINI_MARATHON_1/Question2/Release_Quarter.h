#ifndef RELEASE_QUARTER_H
#define RELEASE_QUARTER_H

#include <iostream>

enum class Release_Quarter
{
    Q1,
    Q2,
    Q3,
    Q4
};

#endif // RELEASE_QUARTER_H
