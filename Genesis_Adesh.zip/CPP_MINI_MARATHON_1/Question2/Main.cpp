#include <iostream>
#include "Functionalities.h"

int main()
{
    Container obj;
    CreateObject(obj);

    std::cout << "<----------------------Functionality 1---------------------->" << std::endl;
    try
    {
        for (std::string id : return_device_id_of_instances(obj))
        {
            std::cout << id << std::endl;
        }
    }
    catch (const std::runtime_error e)
    {
        std::cerr << e.what() << '\n';
    }
    std::cout << "<----------------------Functionality 2---------------------->" << std::endl;
    try
    {
        if (device_instances_type(obj))
        {
            std::cout << "Instances are of device_type INFOTAINMENT : TRUE " << std::endl;
        }
        else
        {
            std::cout << "Instances are of device_type INFOTAINMENT : FALSE " << std::endl;
        }
    }
    catch (const std::runtime_error &e)
    {
        std::cerr << e.what() << '\n';
    }
    std::cout << "<----------------------Functionality 3---------------------->" << std::endl;
    try
    {
        std::cout << "Average is : " << average_of_size_in_bytes_instances(obj) << std::endl;
    }
    catch (const std::runtime_error e)
    {
        std::cerr << e.what() << '\n';
    }
    std::cout << "<----------------------Functionality 4---------------------->" << std::endl;
    try
    {
        std::cout << "Version Number is : " << find_version_number(obj, "101A") << std::endl;
    }
    catch (const std::runtime_error e)
    {
        std::cerr << e.what() << '\n';
    }
    std::cout << "<----------------------Functionality 5---------------------->" << std::endl;
    try
    {

        DeviceDiverContainer Result = find_device_driver_instances(obj, DeviceType::ACCESSORY);

        for (DeviceDriverPointer &ptr : Result)
        {
            std::cout << *ptr << std::endl;
        }
    }
    catch (const std::runtime_error e)
    {
        std::cerr << e.what() << '\n';
    }

    return 0;
}