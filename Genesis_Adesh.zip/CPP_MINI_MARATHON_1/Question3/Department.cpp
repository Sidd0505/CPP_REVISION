#include "Department.h"

Department::Department(std::string id, int _size)
    :_id(id), _size(_size)
{
}
std::ostream &operator<<(std::ostream &os, const Department &rhs)
{
    os << "_id: " << rhs._id
       << " _size: " << rhs._size;
    return os;
}
