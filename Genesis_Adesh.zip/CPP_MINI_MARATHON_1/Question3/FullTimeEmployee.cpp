#include "FullTimeEmployee.h"


std::ostream &operator<<(std::ostream &os, const FullTimeEmployee &rhs)
{
    os << static_cast<const Employee &>(rhs)
       << " _project_name: " << rhs._project_name
       << " _emmployee_location: " << rhs._emmployee_location
       << " _grade: " << (int)rhs._grade
       << " _bonus_percentage: " << rhs._bonus_percentage;
    return os;
}


FullTimeEmployee::FullTimeEmployee(std::string _name, std::string _id, float _salary, std::shared_ptr<Department> department, std::string _project_name, std::string _emmployee_location, Grade _grade, int bonus_percentage)
:Employee(_name,_id,_salary,department),_project_name(_project_name),_emmployee_location(_emmployee_location),_grade(_grade),_bonus_percentage(bonus_percentage)
{
}

float FullTimeEmployee::CalculateBonus()
{
    if (grade() == Grade::A)
    {
        return _bonus_percentage * salary();
    }
    if (grade() == Grade::B)
    {
        return _bonus_percentage * (salary() / 2);
    }
    if (grade() == Grade::C)
    {
        return _bonus_percentage * (salary() * 0.14);
    }
    return 0.0f;
}