#include <iostream>
#include "Functionalities.h"

int main()
{
    Container obj;
    CreateObject(obj);
    display_calculate_bonus(obj);
    return 0;
}