#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <iostream>
#include <memory>
#include "Department.h"

class Employee
{
private:
    std::string _name{""};
    std::string _id{""};
    float _salary{0.0f};
    std::shared_ptr<Department> _department;

public:
    Employee(std::string _name, std::string _id, float _salary, std::shared_ptr<Department> department);

    Employee() = default;

    Employee(Employee &) = delete;

    Employee &operator=(Employee &) = delete;

    Employee(Employee &&) = delete;

    Employee &operator=(Employee &&) = delete;

    ~Employee() = default;

    std::string name() const { return _name; }

    std::string id() const { return _id; }

    float salary() const { return _salary; }

    std::shared_ptr<Department> department() const { return _department; }

    virtual float CalculateBonus() = 0;

    friend std::ostream &operator<<(std::ostream &os, const Employee &rhs);
};

#endif // EMPLOYEE_H
