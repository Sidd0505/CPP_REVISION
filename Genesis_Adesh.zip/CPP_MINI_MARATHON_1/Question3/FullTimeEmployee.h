#ifndef FULLTIMEEMPLOYEE_H
#define FULLTIMEEMPLOYEE_H

#include <iostream>
#include "Grade.h"
#include "Employee.h"

class FullTimeEmployee : public Employee
{

private:
    std::string _project_name{""};
    std::string _emmployee_location{""};
    Grade _grade{Grade::A};
    int _bonus_percentage{0};

public:

    FullTimeEmployee(std::string _name, std::string _id, float _salary,std::shared_ptr<Department> department, std::string _project_name, std::string _emmployee_location, Grade _grade, int bonus_percentage);
    
    FullTimeEmployee() = default;
   
    FullTimeEmployee(FullTimeEmployee &) = delete;

    FullTimeEmployee &operator=(FullTimeEmployee &) = delete;

    FullTimeEmployee(FullTimeEmployee &&) = delete;

    FullTimeEmployee &operator=(FullTimeEmployee &&) = delete;

    float _battery_drain_factor();

    ~FullTimeEmployee() = default;

    std::string projectName() const { return _project_name; }

    std::string emmployeeLocation() const { return _emmployee_location; }

    Grade grade() const { return _grade; }

    void setBonusPercentage(int bonus_percentage) { _bonus_percentage = bonus_percentage; }

    float CalculateBonus() override;

    friend std::ostream &operator<<(std::ostream &os, const FullTimeEmployee &rhs);
};

#endif // FULLTIMEEMPLOYEE_H
