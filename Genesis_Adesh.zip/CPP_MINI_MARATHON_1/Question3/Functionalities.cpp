#include "Functionalities.h"

void CreateObject(Container &data)
{
    data.emplace_back(std::make_shared<FullTimeEmployee>("ABC", "ID1", 90000.00f, std::make_shared<Department>("id", 5), "Adesh", "xyz", Grade::A, 9));

    // data.emplace_back(std::make_shared<FullTimeEmployee>("Aniket", "xyz", Grade::B, 90));
    // data.emplace_back(std::make_shared<FullTimeEmployee>("Ad", "xyz", Grade::A, 90));
}

void display_calculate_bonus(Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY DATA");
    }
    for (Pointer &ptr : data)
    {
        std::cout << ptr->CalculateBonus() << std::endl;
    }
}

void Display_All_Attributes(Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY DATA");
    }

    float highest = data[0]->salary();
    std::string id = data[0]->id();

    for (Pointer &ptr : data)
    {
        if (ptr->salary() > highest)
        {
            highest = ptr->salary();
            id = data[0]->id();
        }
        if (ptr->id() == id)
        {
            std::cout << *ptr << std::endl;
        }
    }
}

void display_employee_location(Container &data, Grade grade)
{

    if (data.empty())
    {
        throw std::runtime_error("EMPTY DATA");
    }

    for (Pointer &ptr : data)
    {
        if (ptr->grade() == grade)
        {
            std::cout << *ptr << std::endl;
        }
    }
}

std::string project_name_of_emp_id(Container &data, std::string id)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY DATA");
    }

    for (Pointer &ptr : data)
    {
        if (ptr->id() == id)
        {
            return ptr->projectName();
        }
    }
    throw std::runtime_error("NOT FOUND");
}
