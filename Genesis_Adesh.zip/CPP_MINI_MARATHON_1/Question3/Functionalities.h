#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include "FullTimeEmployee.h"

#include <memory>
#include <vector>

using Pointer = std::shared_ptr<FullTimeEmployee>;
using Container = std::vector<Pointer>;

void CreateObject(Container &data);

void display_calculate_bonus(Container &data);

void Display_All_Attributes(Container &data);

void display_employee_location(Container &data, Grade grade);

std::string project_name_of_emp_id(Container &data, std::string id);

#endif // FUNCTIONALITIES_H
