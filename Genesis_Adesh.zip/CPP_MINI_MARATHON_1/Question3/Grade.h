#ifndef GRADE_H
#define GRADE_H

#include <iostream>

enum class Grade
{
    A,
    B,
    C
};

#endif // GRADE_H
