#include<iostream>

int main()
{
    std::cout<<"second Hello Worold.";
    return 0;
}