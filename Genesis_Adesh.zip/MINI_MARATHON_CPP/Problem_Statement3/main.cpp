#include <iostream>
#include <cstring>
class student
{
    int roll_no;
    char* sname;
    int* arr;
    public:
    student()
    {
        arr=new int[3];
        arr[0]=0;
        arr[1]=0;
        arr[2]=0;
        sname=new char[strlen("Demo")+1];
        strcpy(sname, "Demo");
    }
    student(int roll_no, char *name)
    {
        roll_no=roll_no;
        sname=new char[strlen(name)+1];
        strcpy(sname, name);
        arr=new int[3];

    };

    student(const student &r3)
    {
        sname=new char[strlen(r3.sname)+1];
        roll_no=r3.roll_no;
        strcpy(sname, r3.sname);
        arr=new int[3];
        for(int i=0;i<3;i++)
        {
            arr[i]=r3.arr[i];
        }
    }
    int getrollNo() const { return roll_no; }
    void setRollNo(int rollNo) { roll_no = rollNo; }
    char *getSname() const { return sname; }


    void setSname(char *sname_) { sname=new char[strlen(sname_)+1];
        strcpy(sname, sname_); }

    int calculateAverageMarks();
    void accept();
    void display();
    char &operator[](int index);
    bool operator==(student &r3);
    bool operator<(student &r3);
    friend std::ostream &operator<<(std::ostream &, const student &);
    ~student()
    {
        std::cout<<"~student()"<<std::endl;
        delete[] arr;
        delete[] sname;
    }

    int* getArr() const { return arr; }
    void setArr(const int* arr_) { 
        
        for(int i=0;i<3;i++)
        {
            arr[i] = arr_[i]; 
        }
    }

};

int student:: calculateAverageMarks()
{
    int avg=(getArr()[0]+getArr()[1]+getArr()[2])/3;
    return avg;
}
void student::accept()
{
    int r;
    char name[20];
    int a[3];
    std::cout << "Enter Roll_No: ";
    std::cin >>r;
    student::setRollNo(r);
    std::cout << "Enter Name: ";
    std::cin >> name;
    student::setSname(name);
    std::cout << "Enter marks of three subject: ";
    for(int i=0;i<3;i++)
    {
        std::cin>>a[i];
    }
    setArr(a);
}

void student::display()
{
    std::cout<<"---------------------------------------------------"<<std::endl;
    std::cout << "Roll_No: " << student::getrollNo()<<std::endl;
    std::cout << "Name: " << student::getSname()<<std::endl;
    int* getmar=getArr();
    std::cout << "Marks of three subject are : " << getmar[0] <<" " << getmar[1] <<" " << getmar[2]<<std::endl;
}

char &student::operator[](int index)
{
    return sname[index];
}

std::ostream &operator<<(std::ostream &os, const student &r3)
{

    os << r3.roll_no;
    os << r3.sname;
    for(int i=0;i<3;i++)
    {
        os<<r3.arr[i]<<" "<<std::endl;
    }
    return os;
}

bool student::operator==(student &r3)
{
    student obj;
    if (strcmp(this->sname,r3.sname) && this->roll_no==r3.roll_no)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool student::operator<(student &r3)
{
    
    if(this->calculateAverageMarks()<r3.calculateAverageMarks())
    {
        return true;
    }
    return false;
}

int main()
{
    
    student obj[3];
    obj[0].accept();
    obj[1].accept();
    obj[2].accept();

    //obj.display();
    student copyobj(obj[0]);
    std::cout<<"Copy const : "<<std::endl; 
    copyobj.display();
    std::cout<<"--------operator[]-------"<<std::endl;
    copyobj.getSname()[0]='a';
    std::cout<<copyobj.getSname()[0]<<std::endl;
    std::cout<<"--------operator==-------"<<std::endl;
    int a=obj[0]==obj[1];
    std::cout<<a<<std::endl;
    std::cout<<"--------operator<-------"<<std::endl;
    int b=obj[0]<obj[2];
    std::cout<<b<<std::endl;
    std::cout<<"--------operator<<-------"<<std::endl;
    std::cout<<obj[2];
    std::cout<<"--------calculateMarks()-------"<<std::endl;
    std::cout<<obj[2].calculateAverageMarks()<<std::endl;
    return 0;
}