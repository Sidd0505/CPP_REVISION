#include<iostream>
#include<cstring>
class student
{
    private:
    int rollno;
    char* name;
    int* marks;
    public:
    student()
    {
        rollno=101;
        name=new char[strlen("Adesh")+1];
        strcpy(name,"XYZ");
        marks=new int[3];
        // marks[0]=0;
        // marks[1]=0;
        // marks[2]=0;
    }
    student(int rollno,char *n)
    {
        name=new char[strlen(n)+1];
        rollno=rollno;
        strcpy(name,n);
        marks=new int[3];
    }
    ~student()
    {
        std::cout<<"~student()"<<std::endl;
        delete[] name;
        delete[] marks;
    }

    void accept();
    void display();

    // int getRollno() const { return rollno; }
    // void setRollno(int rollno_) { rollno = rollno_; }

    // char* getName() const { return name; }
    // void setName(char* name_) { name = name_; }

    // int getRollno() const { return rollno; }
    // void setRollno(int rollno_) { rollno = rollno_; }

    // char* getName() const { return name; }
    // void setName(char* name_) { name = name_; }

};

void student::display()
{
    std::cout<<"name : "<<name<<std::endl;
    std::cout<<"roll no : "<<rollno<<std::endl;
    std::cout<<"marks : "<<std::endl;
    for(int i=0;i<3;i++)
    {
        std::cout<<marks[i]<<" ";
    }
}

void student::accept()
{
    std::cout<<"Enter name : "<<std::endl;
    std::cin>>name;
    std::cout<<"Enter roll no : "<<std::endl;
    std::cin>>rollno;
    std::cout<<"Enter three subject marks : "<<std::endl;
    for(int i=0;i<3;i++)
    {
        std::cin>>marks[i];
    }
    std::cout<<std::endl;
    
}

int main()
{
    student obj[2];

    obj[0].accept();
    obj[0].display();

    // obj[1].accept();
    // obj[1].display();
    return 0;
}