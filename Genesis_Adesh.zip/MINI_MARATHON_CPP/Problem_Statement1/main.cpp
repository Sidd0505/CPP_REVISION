#include "header.h"

int main()
{
    Electricity obj; // Creating class object
    obj.accept();
    obj.display();
    std::cout<<std::endl;
    std::cout<<"Electricity Bill is : "<<obj.calculateElectricityBill()<<std::endl;
    return 0;
}