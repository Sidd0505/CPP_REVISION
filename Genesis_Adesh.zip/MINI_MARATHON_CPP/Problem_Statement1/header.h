//Header Guard
#ifndef HEADER_H
#define HEADER_H

#include <iostream>
enum electricitySlabs
{
    E1 = 125,
    E2 = 150,
    E3 = 200
};


class Electricity
{
    // Data Members
    enum electricitySlabs e;
    int sanctionLoad;
    long int presentReading;
    long int previousReading;

public:
    Electricity()//default constructor
    {
        sanctionLoad = 0;
        presentReading = 0;
        previousReading = 0;
    }

    // getters and setters
    int getSanctionLoad() const 
    { 
        return sanctionLoad; 
    }

    void setSanctionLoad(int sanctionLoad_) 
    { 
        sanctionLoad = sanctionLoad_; 
    }

    long int getPresentReading() const 
    { 
        return presentReading; 
    }

    void setPresentReading(long int presentReading_) 
    { 
        presentReading = presentReading_; 
    }

    long int getPreviousReading() const 
    { 
        return previousReading; 
    }

    void setPreviousReading(long int previousReading_) 
    { 
        previousReading = previousReading_; 
    }

    //member functions
    int calculateElectricityBill();
    void accept();
    void display();

    ~Electricity()
    {
        //std::cout<<"Destructor Called..."<<std::endl;
    }
};

#endif // HEADER_H
