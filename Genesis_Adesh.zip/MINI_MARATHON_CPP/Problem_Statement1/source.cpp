#include "header.h" // header file included

int Electricity::calculateElectricityBill()
{
    if(Electricity::getPresentReading()<Electricity::getPreviousReading())
    {
        return 0;
    }
    int Consumption=Electricity::getPresentReading()-Electricity::getPreviousReading();
    long int bill = ((Consumption * e) + (Consumption * e / 100));
    return bill;
}

void Electricity::accept()
{
    int SL;
    long int PR;
    long int PVR;
    int es;
    while(1)
    {
    std::cout <<"Enter Sanction Load(1 or 3 or 5) : " << std::endl;
    std::cin >> SL;
    if(SL==1 || SL==3 || SL==5)
    {
        break;
    }
    }
    
    Electricity::setSanctionLoad(SL);
    std::cout <<"Enter Present Reading : " << std::endl;
    std::cin >> PR;
    Electricity::setPresentReading(PR);
    std::cout <<"Enter Previous Reading : " << std::endl;
    std::cin >> PVR;
    Electricity::setPreviousReading(PVR);
}

void Electricity::display()
{
    std::cout<<std::endl;
    std::cout << "Sanction Load : " << Electricity::getSanctionLoad() << std::endl;
    switch (Electricity::getSanctionLoad())
    {
    case 1:
        e=E1;
         std::cout << "Electricity Slab : " << e << std::endl;
        break;

    case 3:
        e=E2;
        std::cout << "Electricity Slab : " << e << std::endl;
        break;

    case 5:
        e=E3;
        std::cout << "Electricity Slab : " << e << std::endl;
        break;
    
    default:
        break;
    }
    std::cout << "Present Reading : " << Electricity::getPresentReading() << std::endl;
    std::cout << "Previous Reading : " << Electricity::getPreviousReading() << std::endl;
}