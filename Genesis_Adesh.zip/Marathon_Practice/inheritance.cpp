#include <iostream>
using namespace std;
class Account
{
    float salary;

public:
    float getSalary() const { return salary; }
    void setSalary(float salary_) { salary = salary_; }

public:
};
class Programmer : public Account
{
    float bonus;

public:
    float getBonus() const { return bonus; }
    void setBonus(float bonus_) { bonus = bonus_; }

public:
};
int main(void)
{
    Programmer p1;
    int sal, bon;
    cout << "Salary: " << endl;
    cin >> sal;
    p1.setSalary(sal);
    cout << "Bonus: " << endl;
    cin >> bon;
    p1.setBonus(bon);

    cout << "Salary : " << p1.getSalary() << endl;
    cout << "Bonus : " << p1.getBonus() << endl;
    return 0;
}