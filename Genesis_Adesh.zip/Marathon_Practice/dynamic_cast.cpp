#include <iostream>
using namespace std;
class Animal
{
public:
    virtual ~Animal() {}
};

class Dog : public Animal
{
public:
    void bark()
    {
        std::cout << "Woof woof!" << std::endl;
    }
};

class Cat : public Animal
{
public:
    void meow()
    {
        std::cout << "Meow meow!" << std::endl;
    }
};

int main()
{
    Animal *animalPtr = new Dog;
    Dog *dogPtr = dynamic_cast<Dog *>(animalPtr);
    
    if (dogPtr != nullptr)
    {
         dogPtr->bark();
     }
    delete animalPtr;
    return 0;
}