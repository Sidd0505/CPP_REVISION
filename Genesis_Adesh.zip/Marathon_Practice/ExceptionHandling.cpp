#include<iostream>
#include<exception>
using namespace std;

class MyException{
public:
const char* what() const throw()
{
    return "Attempted to devide by zero!\n";
}
};
int main()
{
    int a=10,b=0;
    
    try
    {
        if(b==0)
        {
            MyException e;
            throw e;
        }
        else
        {
            std::cout<<a/b;
        }
    }
    catch(MyException e)
    {
        std::cout<< e.what() << '\n';
    }
    

}