#include <iostream>  
using namespace std;  
template<class T,class F>  
class A   
{  
    public:  
    // T num1 = 5;  
    // T num2 = 6;  
    // void add(T num1,T num2)  
    // {  
    //     std::cout << "Addition of num1 and num2 : " << num1+num2<<std::endl;  
    // }  

    void add(T num1,F num2);
      
};  
  
int main()  
{  
    A<int,float> d;  
    d.add(10,20.00);  
    return 0;  
}

template <class T,class F>
void A<T,F>::add(T num1, F num2)
{
    std::cout << "Addition of num1 and num2 : " << num1<<" "<<num2<<std::endl;
}
