#include<iostream>
using namespace std;

template<class T> T add(T a,T b)
{
    T result=a+b;
    return result;
}
template<class T> T add(T a)
{
    T result=a;
    return result;
}
template<class X,class Y> void fun(X a,Y b)  
{  
    std::cout << "Value of a is : " <<a<< std::endl;  
    std::cout << "Value of b is : " <<b<< std::endl;  
}  

int main()
{
    std::cout<<add(10)<<std::endl;
    std::cout<<add(10,20)<<std::endl;
    fun(10,30.9);
}